"""
Copyright (c) 2012 Shotgun Software, Inc
----------------------------------------------------

A simple app to support unit tests.
"""

from tank.platform import Application
import tank

class TestApp(Application):
    
    def init_app(self):
        pass

