"""
Copyright (c) 2012 Shotgun Software, Inc
----------------------------------------------------

This module contains functionality relating to folder creation.

"""

from .schema import Schema, process_filesystem_structure