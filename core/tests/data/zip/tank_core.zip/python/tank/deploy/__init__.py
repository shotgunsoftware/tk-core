"""
Copyright (c) 2012 Shotgun Software, Inc
----------------------------------------------------

This module contains functionality relating to the deployment,
upgrading and installation of projects, apps and engines.


"""

