# Copyright (c) 2013 Shotgun Software Inc.
# 
# CONFIDENTIAL AND PROPRIETARY
# 
# This work is provided "AS IS" and subject to the Shotgun Pipeline Toolkit 
# Source Code License included in this distribution package. See LICENSE.
# By accessing, using, copying or modifying this work you indicate your 
# agreement to the Shotgun Pipeline Toolkit Source Code License. All rights 
# not expressly granted therein are reserved by Shotgun Software Inc.

"""
Encapsulates the pipeline configuration and helps navigate and resolve paths
across storages, configurations etc.
"""
import os
import sys
import glob

from tank_vendor import yaml

from .errors import TankError
from .deploy import util
from .platform import constants
from .platform.environment import Environment
from .util import shotgun
from .util import login
from . import hook
from . import template_includes

class PipelineConfiguration(object):
    """
    Represents a pipeline configuration in Tank.
    Use the factory methods below to construct this object, do not
    create directly via constructor.
    """

    def __init__(self, pipeline_configuration_path):
        """
        Constructor. Do not call this directly, use the factory methods
        at the bottom of this file.
        
        NOTE ABOUT SYMLINKS!
        
        The pipeline_configuration_path is always populated by the paths
        that were registered in shotgun, regardless of how the symlink setup
        is handled on the OS level.
        """
        self._pc_root = pipeline_configuration_path

        # validate that the current code version matches or is compatible with
        # the code that is locally stored in this config!!!!
        our_associated_api_version = self.get_associated_core_version()
        
        # and get the version of the API currently in memory
        current_api_version = get_core_api_version_based_on_current_code()
        
        if our_associated_api_version is not None and \
           util.is_version_older(current_api_version, our_associated_api_version):
            # currently running API is too old!
            current_api_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
            raise TankError("You are currently running Core API %s located in '%s'. "
                            "The Pipeline Configuration you are trying to create ('%s') is "
                            "associated with a more recent version of the API, "
                            "%s, located here: '%s'. Initialization cannot proceed at this point, "
                            "because the currently running Core API is too old. "
                            "To fix this, please import "
                            "the API located in '%s' and try again." % (current_api_version,
                                                                        current_api_path,
                                                                        self.get_path(),
                                                                        our_associated_api_version,
                                                                        self.get_install_location(),
                                                                        self.get_core_python_location()))


        self._roots = get_pc_roots_metadata(self._pc_root)

        # get the project tank disk name (Project.tank_name), stored in the PC metadata file.
        data = get_pc_disk_metadata(self._pc_root)
        if data.get("project_name") is None:
            raise TankError("Project name not defined in config metadata for config %s! "
                            "Please contact support." % self._pc_root)
        self._project_name = data.get("project_name")

        # cache fields lazily populated on getter access
        self._project_id = None
        self._pc_id = None
        self._pc_name = None
        self._published_file_entity_type = None
        self.execute_hook(constants.PIPELINE_CONFIGURATION_INIT_HOOK_NAME, parent=self)


    def __repr__(self):
        return "<Sgtk Configuration %s>" % self._pc_root

    ########################################################################################
    # data roots access

    def get_path(self):
        """
        Returns the master root for this pipeline configuration
        """
        return self._pc_root

    def _load_metadata_from_sg(self):
        """
        Caches PC metadata from shotgun.
        """
        sg = shotgun.create_sg_connection()
        platform_lookup = {"linux2": "linux_path", "win32": "windows_path", "darwin": "mac_path" }
        sg_path_field = platform_lookup[sys.platform]
        data = sg.find_one(constants.PIPELINE_CONFIGURATION_ENTITY,
                           [[sg_path_field, "is", self._pc_root]],
                           ["id", "project", "code"])
        if data is None:
            raise TankError("Cannot find a Pipeline configuration in Shotgun that has its %s "
                            "set to '%s'!" % (sg_path_field, self._pc_root))

        self._project_id = data.get("project").get("id")
        self._pc_id = data.get("id")
        self._pc_name = data.get("code")


    def get_name(self):
        """
        Returns the name of this PC.
        May connect to Shotgun to retrieve this.
        """
        if self._pc_name is None:
            # try to get it from the cache file
            data = get_pc_disk_metadata(self._pc_root)
            self._pc_name = data.get("pc_name")


            if self._pc_name is None:
                # not in metadata file on disk. Fall back on SG lookup
                self._load_metadata_from_sg()

        return self._pc_name

    def is_localized(self):
        """
        Returns true if this pipeline configuation has its own Core
        """
        return is_localized(self._pc_root)

    def get_shotgun_id(self):
        """
        Returns the shotgun id for this PC. 
        May connect to Shotgun to retrieve this.
        """
        if self._pc_id is None:
            # try to get it from the cache file
            data = get_pc_disk_metadata(self._pc_root)
            self._pc_id = data.get("pc_id")

            if self._pc_id is None:
                # not in metadata file on disk. Fall back on SG lookup
                self._load_metadata_from_sg()

        return self._pc_id

    def get_project_id(self):
        """
        Returns the shotgun id for the project associated with this PC. 
        May connect to Shotgun to retrieve this.
        """
        if self._project_id is None:
            # try to get it from the cache file
            data = get_pc_disk_metadata(self._pc_root)
            self._project_id = data.get("project_id")

            if self._project_id is None:
                # not in metadata file on disk. Fall back on SG lookup
                self._load_metadata_from_sg()

        return self._project_id

    def get_project_disk_name(self):
        """
        Returns the project name for the project associated with this PC.
        """
        return self._project_name

    def set_project_disk_name(self, project_disk_name):
        """
        Sets the internal project_name.  This is temporary and only available
        while this instance is in memory.  Will not affect the metadata on
        disk nor in Shotgun.
        """
        self._project_name = project_disk_name

    def get_published_file_entity_type(self):
        """
        Returns the type of entity being used
        for the 'published file' entity
        """
        if self._published_file_entity_type is None:
            # try to get it from the cache file
            data = get_pc_disk_metadata(self._pc_root)
            self._published_file_entity_type = data.get("published_file_entity_type")

            if self._published_file_entity_type is None:
                # fall back to legacy type:
                self._published_file_entity_type = "TankPublishedFile"

        return self._published_file_entity_type

    def get_local_storage_roots(self):
        """
        Returns local OS paths to all shotgun local storages used by toolkit. 
        """
        
        platform_lookup = {"linux2": "linux_path", "win32": "windows_path", "darwin": "mac_path" }

        # now pick current os and append project root
        proj_roots = {}
        for r in self._roots:
            proj_roots[r] = self._roots[r][ platform_lookup[sys.platform] ]
        return proj_roots
        

    def get_data_roots(self):
        """
        Returns a dictionary of all the data roots available for this PC,
        keyed by their storage name. Only returns paths for current platform.

        Returns for example:

        {"primary": "/studio/my_project", "textures": "/textures/my_project"}

        """
        platform_lookup = {"linux2": "linux_path", "win32": "windows_path", "darwin": "mac_path" }

        # now pick current os and append project root
        proj_roots = {}
        for r in self._roots:
            current_os_root = self._roots[r][ platform_lookup[sys.platform] ]
            if current_os_root is None:
                proj_roots[r] = None
            else:
                proj_roots[r] = self.__append_project_name_to_root(current_os_root, sys.platform)

        return proj_roots

    def get_all_data_roots(self):
        """
        Returns a dictionary containing dictionaries of all the data roots
        available for this PC, keyed by their storage name and {os}_path

        Returns for example:

        {
          "primary": {
                        "linux_path":"/studio/my_project",
                        "mac_path":"/studio/my_project",
                        "windows_path":"P:/studio/my_project"
          "textures": {
                        "linux_path":"/textures/my_project",
                        "mac_path":"/textures/my_project",
                        "windows_path":"P:/textures/my_project"
                      }
        }

        """
        
        # mapping from an entity dict 
        platform_lookup = {"linux_path": "linux2", 
                           "windows_path": "win32", 
                           "mac_path": "darwin" }

        # now pick current os and append project root
        proj_roots = {}
        for r in self._roots:
            proj_roots[r] = {}
            for p in self._roots[r]:
                current_root = self._roots[r][p]
                if current_root is None:
                    proj_roots[r][p] = None
                else:
                    os_name = platform_lookup[p]
                    proj_roots[r][p] = self.__append_project_name_to_root(current_root, os_name)

        return proj_roots

    def __append_project_name_to_root(self, root_value, os_name):
        """
        Multi-os method that creates a project root path.
        Note that this method does not use any of the os.path methods,
        since we may for example be evaulating a windows path on linux.
        
        :param root_value: A root path, for example /mnt/projects or c:\foo
        :param os_name: sys.platform name for the path's platform.
          
        :returns: the project disk name properly concatenated onto the root_value
        """
        
        # get the valid separator for this path
        separators = {"linux2": "/", "win32": "\\", "darwin": "/" }
        separator = separators[os_name] 
        
        # get rid of any slashes at the end
        root_value = root_value.rstrip("/\\")
        # now root value is "/foo/bar", "c:" or "\\hello" 
        
        # concat the full path.
        full_path = root_value + separator + self._project_name
        
        # note that project name may be "foo/bar/baz" even on windows.
        # now get all the separators adjusted.
        full_path = full_path.replace("\\", separator).replace("/", separator)
        
        return full_path
        
    def get_primary_data_root(self):
        """
        Returns the path to the primary data root for the current platform
        """
        return self.get_data_roots().get(constants.PRIMARY_STORAGE_NAME)


    def get_path_cache_location(self):
        """
        Returns the path to the path cache file.
        """
        return os.path.join(self.get_primary_data_root(), "tank", "cache", constants.CACHE_DB_FILENAME)


    ########################################################################################
    # paths, core info, apps and engines

    def get_associated_core_version(self):
        """
        Returns the version string for the core api associated with this config.
        This method is 'forgiving' and in the case no associated core API can be 
        found for this pipeline configuration, None will be returned rather than 
        an exception raised. 
        """
        associated_api_root = self.get_install_location()
        
        info_yml_path = os.path.join(associated_api_root, "install", "core", "info.yml")

        if os.path.exists(info_yml_path):
            try:
                info_fh = open(info_yml_path, "r")
                try:
                    data = yaml.load(info_fh)
                finally:
                    info_fh.close()
                data = data.get("version")
            except:
                data = None
        else:
            data = None

        return data
        

    def get_install_location(self):
        """
        Returns the core api install location associated with this pipeline configuration.
        
        This method will return the root point, so a pipeline config root if running 
        a localized API or a studio location root if running a bare API.
        
        The install location is where toolkit caches engines, apps, frameworks and is
        where it keeps the Core API.       
        
        Use this method whenever a pipeline configuration is available, since it is more
        sophisticated. In cases when no pipeline configuration is available, revert to  
        get_current_code_install_root() which will base the install location
        on the current code.
        
        When a pipeline configuration exists, a specific relationship between the core
        core and that configuration has also been established. This method will follow
        this connection to return the actual associated core API rather than the 
        running API. Usually these two are the same (or so they should be), but this is not
        guaranteed.
        """

        if is_localized(self._pc_root):
            # first, try to locate an install local to this pipeline configuration.
            # this would find any localized APIs.
            install_path = self._pc_root

        else:
            # this PC is associated with a shared API (studio install)
            # follow the links defined in the configuration to establish which 
            # setup it has been associated with.
            studio_linkback_files = {"win32": os.path.join(self._pc_root, "install", "core", "core_Windows.cfg"), 
                                     "linux2": os.path.join(self._pc_root, "install", "core", "core_Linux.cfg"), 
                                     "darwin": os.path.join(self._pc_root, "install", "core", "core_Darwin.cfg")}
            
            curr_linkback_file = studio_linkback_files[sys.platform]
            
            # this file will contain the path to the API which is meant to be used with this PC.
            install_path = None
            try:
                fh = open(curr_linkback_file, "rt")
                data = fh.read().strip() # remove any whitespace, keep text
                # expand any env vars that are used in the files. For example, you could have 
                # an env variable $STUDIO_TANK_PATH=/sgtk/software/shotgun/studio and your 
                # linkback file may just contain "$STUDIO_TANK_PATH" instead of an explicit path.
                data = os.path.expandvars(data)
                if data not in ["None", "undefined"] and os.path.exists(data):
                    install_path = data
                fh.close()                    
            except:
                pass
                
            if install_path is None:
                # no luck determining the location of the core API through our two 
                # established modus operandi. Fall back on the crude legacy
                # approach, which is to grab and return the currently running code.
                install_path = get_current_code_install_root()

                    
        return install_path


    def get_apps_location(self):
        """
        Returns the location where apps are stored
        """
        return os.path.join(self.get_install_location(), "install", "apps")

    def get_engines_location(self):
        """
        Returns the location where apps are stored
        """
        return os.path.join(self.get_install_location(), "install", "engines")

    def get_frameworks_location(self):
        """
        Returns the location where apps are stored
        """
        return os.path.join(self.get_install_location(), "install", "frameworks")

    def get_core_python_location(self):
        """
        returns the python root for this install.
        """
        return os.path.join(self.get_install_location(), "install", "core", "python")


    ########################################################################################
    # cache

    def get_cache_location(self):
        """
        Returns the pipeline config -centric cache location
        """
        return os.path.join(self._pc_root, "cache")


    ########################################################################################
    # configuration

    def get_core_hooks_location(self):
        """
        Returns the path to the core hooks location
        """
        return os.path.join(self._pc_root, "config", "core", "hooks")

    def get_schema_config_location(self):
        """
        returns the location of the schema
        """
        return os.path.join(self._pc_root, "config", "core", "schema")

    def get_config_location(self):
        """
        returns the config folder for the project
        """
        return os.path.join(self._pc_root, "config")

    def get_hooks_location(self):
        """
        returns the hooks folder for the project
        """
        return os.path.join(self._pc_root, "config", "hooks")

    def get_environments(self):
        """
        Returns a list with all the environments in this configuration.
        """
        env_root = os.path.join(self._pc_root, "config", "env")
        env_names = []
        for f in glob.glob(os.path.join(env_root, "*.yml")):
            file_name = os.path.basename(f)
            (name, _) = os.path.splitext(file_name)
            env_names.append(name)
        return env_names

    def get_environment(self, env_name, context=None):
        """
        Returns an environment object given an environment name.
        You can use the get_environments() method to get a list of
        all the environment names.
        """
        env_file = os.path.join(self._pc_root, "config", "env", "%s.yml" % env_name)
        if not os.path.exists(env_file):
            raise TankError("Cannot load environment '%s': Environment configuration "
                            "file '%s' does not exist!" % (env_name, env_file))

        return Environment(env_file, self, context)

    def get_templates_config(self):
        """
        Returns the templates configuration as an object
        """
        templates_file = os.path.join(self._pc_root, "config", "core", constants.CONTENT_TEMPLATES_FILE)

        if os.path.exists(templates_file):
            config_file = open(templates_file, "r")
            try:
                data = yaml.load(config_file) or {}
            finally:
                config_file.close()
        else:
            data = {}

        # and process include files
        data = template_includes.process_includes(templates_file, data)

        return data

    def execute_hook(self, hook_name, parent, **kwargs):
        """
        Executes a core level hook, passing it any keyword arguments supplied.

        Note! This is part of the private Sgtk API and should not be called from ouside
        the core API.

        :param hook_name: Name of hook to execute.
        :returns: Return value of the hook.
        """
        # first look for the hook in the pipeline configuration
        # if it does not exist, fall back onto core API default implementation.
        hook_folder = self.get_core_hooks_location()
        file_name = "%s.py" % hook_name
        hook_path = os.path.join(hook_folder, file_name)
        if not os.path.exists(hook_path):
            # no custom hook detected in the pipeline configuration
            # fall back on the hooks that come with the currently running version
            # of the core API.
            hooks_path = os.path.join(get_current_code_install_root(), "install", "core", "hooks")            
            hook_path = os.path.join(hooks_path, file_name)

        return hook.execute_hook(hook_path, parent, **kwargs)


class StorageConfigurationMapping(object):
    """
    Handles operation on the mapping from a data root to a pipeline config
    """

    def __init__(self, data_root):
        self._config_file = os.path.join(data_root, "tank", "config", constants.CONFIG_BACK_MAPPING_FILE)

    def clear_mappings(self):
        """
        Removes any content from the storage mappings file
        """
        # open the file without append to overwrite any previous content
        try:
            fh = open(self._config_file, "wt")
            fh.write("# this file is automatically created by the shotgun pipeline toolkit\n")
            fh.write("# please do not edit by hand\n\n")
            fh.close()
        except Exception, exp:
            raise TankError("Could not write to roots file %s. "
                            "Error reported: %s" % (self._config_file, exp))
        
    def add_pipeline_configuration(self, mac_path, win_path, linux_path):
        """
        Add pipeline configuration mapping to a storage
        """
        data = []

        if os.path.exists(self._config_file):
            # we have a config already - so read it in
            fh = open(self._config_file, "rt")
            try:
                data = yaml.load(fh)
                # if clear_mappings was run, data is None
                if data is None:
                    data = []
            except Exception, e:
                raise TankError("Looks like the config lookup file is corrupt. Please contact "
                                "support! File: '%s' Error: %s" % (self._config_file, e))
            finally:
                fh.close()

        # now add our new mapping to this data structure
        new_item = {"darwin": mac_path, "win32": win_path, "linux2": linux_path}
        if new_item not in data:
            data.append(new_item)

        # and write the file
        try:
            fh = open(self._config_file, "wt")
            yaml.dump(data, fh)
            fh.close()
        except Exception, exp:
            raise TankError("Could not write to roots file %s. "
                            "Error reported: %s" % (self._config_file, exp))


    def get_pipeline_configs(self):
        """
        Returns a list of current os paths to pipeline configs
        """
        data = []

        if os.path.exists(self._config_file):
            # we have a config already - so read it in
            fh = open(self._config_file, "rt")
            try:
                data = yaml.load(fh)
            except Exception, e:
                raise TankError("Looks like the config lookup file %s is corrupt. Please contact "
                                "support! File: '%s' Error: %s" % (self._config_file, e))
            finally:
                fh.close()

        # get all the registered pcs for the current platform
        # env variables are allowed in these paths so expand them if they exist
        current_os_paths = [ os.path.expandvars(x.get(sys.platform)) for x in data ]

        return current_os_paths


def from_entity(entity_type, entity_id):
    """
    Factory method that constructs a PC given a shotgun object
    """

    platform_lookup = {"linux2": "linux_path", "win32": "windows_path", "darwin": "mac_path" }

    sg = shotgun.create_sg_connection()

    e = sg.find_one(entity_type, [["id", "is", entity_id]], ["project", "name"])

    if e is None:
        raise TankError("Cannot resolve a pipeline configuration object from %s %s - this object "
                        "does not exist in Shotgun!" % (entity_type, entity_id))

    if entity_type == "Project":
        proj = {"type": "Project", "id": entity_id, "name": e.get("name")}

    else:
        if e.get("project") is None:
            raise TankError("Cannot resolve a pipeline configuration object from %s %s - this object "
                            "is not linked to a project!" % (entity_type, entity_id))
        proj = e.get("project")

    pipe_configs = sg.find(constants.PIPELINE_CONFIGURATION_ENTITY,
                           [["project", "is", proj]],
                           ["windows_path", "mac_path", "linux_path", "code"])

    if len(pipe_configs) == 0:
        raise TankError("Cannot resolve a pipeline configuration object from %s with id %s - looks "
                        "like its associated Shotgun Project '%s' has not yet been set up with "
                        "the Shotgun Pipeline Toolkit!" % (entity_type, entity_id, proj.get("name")))

    #############################################################################################
    # ok now we have all the PCs in Shotgun for this project.
    # apply the following logic:
    #
    # if this method was called from a generic tank command, just find the primary PC 
    # and use that.
    #
    # if this was called from a specific tank command, use that. 

    if "TANK_CURRENT_PC" not in os.environ:
        # we are running the generic tank command, the code that we are running
        # is not connected to any particular PC.
        # in this case, find the primary pipeline config and use that
        primary_pc = None
        for pc in pipe_configs:
            if pc.get("code") == constants.PRIMARY_PIPELINE_CONFIG_NAME:
                primary_pc = pc
                break
        if primary_pc is None:
            raise TankError("The Shotgun Project '%s' does not have a default Pipeline "
                            "Configuration! This is required by the Sgtk. It needs to be named '%s'. "
                            "Please double check by opening to the Pipeline configuration Page in "
                            "Shotgun for the given project." % (proj.get("name"), constants.PRIMARY_PIPELINE_CONFIG_NAME))

        # check that there is a path for our platform
        current_os_path = primary_pc.get(platform_lookup[sys.platform])
        if current_os_path is None:
            raise TankError("The Shotgun Project '%s' has a Primary pipeline configuration but "
                            "it has not been configured to work with the current "
                            "operating system." % proj.get("name"))

        # ok there is a path - now check that the path exists!
        if not os.path.exists(current_os_path):
            raise TankError("The Shotgun Project '%s' has a Primary pipeline configuration registered "
                            "to be located in '%s', however this path does cannot be "
                            "found!" % (proj.get("name"), current_os_path))

        # looks good, we got a primary pipeline config that exists
        return PipelineConfiguration(current_os_path)


    else:
        # we are running the tank command from a specific PC.
        # in this case we need to check that the entity actually belongs to the project
        curr_pc_path = os.environ["TANK_CURRENT_PC"]

        # do a bit of cleanup - windows paths can end with a space
        if curr_pc_path.endswith(" "):
            curr_pc_path = curr_pc_path[:-1]
        # windows tends to end with a backslash
        if curr_pc_path.endswith("\\"):
            curr_pc_path = curr_pc_path[:-1]

        # the path stored in the TANK_CURRENT_PC env var may be a symlink etc.
        # now we need to find which PC entity this corresponds to in Shotgun.
        # Once found, we can double check that the current Entity is actually
        # associated with the project that the PC is associated with.
        pc_registered_path = get_pc_registered_location(curr_pc_path)

        if pc_registered_path is None:
            raise TankError("Error starting from the configuration located in '%s' - "
                            "it looks like this pipeline configuration and tank command "
                            "has not been configured for the current operating system." % curr_pc_path)

        # now that we have the proper pc path, we can find which PC entity this is
        found_matching_path = False
        for sg_pc in pipe_configs:
            if sg_pc.get(platform_lookup[sys.platform]) == pc_registered_path:
                found_matching_path = True
                break

        if not found_matching_path:
            raise TankError("Error launching for %s with id %s (Belonging to the project '%s') "
                            "from the configuration located in '%s'. This config is not "
                            "associated with that project. For a list of which tank commands can be "
                            "used with this project, go to the Pipeline Configurations page in "
                            "Shotgun for the project." % (entity_type, entity_id, proj.get("name"), pc_registered_path))
        # ok we got a pipeline config matching the tank command from which we launched.
        # because we found the PC in the list of PCs for this project, we know that it must be valid!
        return PipelineConfiguration(pc_registered_path)




def from_path(path):
    """
    Factory method that constructs a PC object from a path:
    - data paths are being traversed and resolved
    - if the path is a direct path to a PC root that's fine too
    """

    if not isinstance(path, basestring):
        raise TankError("Cannot create a Configuration from path '%s' - "
                        "path must be a string!" % path)

    path = os.path.abspath(path)

    # make sure folder exists on disk
    if not os.path.exists(path):
        # there are cases when a PC is being created from a _file_ which does not yet
        # exist on disk. To try to be reasonable with this case, try this check on the
        # parent folder of the path as a last resort.
        parent_path = os.path.dirname(path)
        if os.path.exists(parent_path):
            path = parent_path
        else:
            raise TankError("Cannot create a Configuration from path '%s' - the path does "
                            "not exist on disk!" % path)


    ########################################################################################
    # first see if this path is a pipeline configuration

    pc_config = os.path.join(path, "config", "core", "pipeline_configuration.yml")
    if os.path.exists(pc_config):
        # done deal!

        # resolve the "real" location that is stored in Shotgun and 
        # cached in the file system
        pc_registered_path = get_pc_registered_location(path)

        if pc_registered_path is None:
            raise TankError("Error starting from the configuration located in '%s' - "
                            "it looks like this pipeline configuration and tank command "
                            "has not been configured for the current operating system." % path)
        return PipelineConfiguration(pc_registered_path)


    ########################################################################################
    # assume it is a data path.
    # walk up the file system until a tank folder is found, then find tank config directory

    cur_path = path
    config_path = None
    while True:
        config_path = os.path.join(cur_path, "tank", "config", constants.CONFIG_BACK_MAPPING_FILE)
        # need to test for something in project vs studio config
        if os.path.exists(config_path):
            break
        parent_path = os.path.dirname(cur_path)
        if parent_path == cur_path:
            # Topped out without finding config
            raise TankError("Cannot create a Configuration from path '%s' - this path does "
                            "not belong to an Sgtk Project!" % path)
        cur_path = parent_path

    # all right - now read the config and get all the registered pipeline configs.
    try:
        fh = open(config_path, "r")
        try:
            data = yaml.load(fh)
        finally:
            fh.close()
    except Exception, e:
        raise TankError("Looks like a config file is corrupt. Please contact "
                        "support! File: '%s' Error: %s" % (config_path, e))

    # get all the registered pcs for the current platform
    # env variables are allowed in these paths so expand them if they exist
    current_os_pcs = [ os.path.expandvars(x.get(sys.platform)) for x in data if x is not None]

    # Now if we are running a studio tank command, find the Primary PC and use that
    # if we are using a specific tank command, try to use that PC

    if "TANK_CURRENT_PC" not in os.environ:
        # we are running a studio level tank command - not associated with 
        # a particular PC. Out of the list of PCs associated with this location, 
        # find the Primary PC and use that.

        # try to figure out what the primary storage is by looking for a metadata 
        # file in each PC. 
        for pc_path in current_os_pcs:
            data = None
            try:
                data = get_pc_disk_metadata(pc_path)
            except TankError:
                # didn't find so just skip this pc
                continue
            pc_name = data.get("pc_name")
            if pc_name == constants.PRIMARY_PIPELINE_CONFIG_NAME:
                return PipelineConfiguration(pc_path)

        # no luck - this may be because some projects don't have this 
        # metadata cached. Now try by looking in Shotgun instead.

        # in the list of paths found in the inverse lookup table on disk, find the primary.
        sg = shotgun.create_sg_connection()
        platform_lookup = {"linux2": "linux_path", "win32": "windows_path", "darwin": "mac_path" }
        filters = [ platform_lookup[sys.platform], "in"]
        filters.extend(current_os_pcs)
        primary_pc = sg.find_one(constants.PIPELINE_CONFIGURATION_ENTITY,
                                 [filters, ["code", "is", constants.PRIMARY_PIPELINE_CONFIG_NAME]],
                                 ["windows_path", "mac_path", "linux_path", "project"])

        if primary_pc is None:
            raise TankError("Cannot find a Primary Pipeline Configuration for path '%s'. "
                            "The following Pipeline configuration are associated with the "
                            "path, but none of them is marked as Primary: %s" % (path, current_os_pcs))

        # check that there is a path for our platform
        current_os_path = primary_pc.get(platform_lookup[sys.platform])
        if current_os_path is None:
            raise TankError("The Shotgun Project '%s' has a Primary pipeline configuration but "
                            "it has not been configured to work with the current "
                            "operating system." % primary_pc.get("project").get("name"))

        # ok there is a path - now check that the path exists!
        if not os.path.exists(current_os_path):
            raise TankError("The Shotgun Project '%s' has a Primary pipeline configuration registered "
                            "to be located in '%s', however this path does cannot be "
                            "found!" % (primary_pc.get("project"), current_os_path))

        # looks good, we got a primary pipeline config that exists
        return PipelineConfiguration(current_os_path)

    else:
        # we are running a tank command coming from a particular PC!
        # make sure that this PC is actually associated with this project
        # and then use it.
        curr_pc_path = os.environ["TANK_CURRENT_PC"]

        # do a bit of cleanup - windows paths can end with a space
        if curr_pc_path.endswith(" "):
            curr_pc_path = curr_pc_path[:-1]
        # windows tends to end with a backslash
        if curr_pc_path.endswith("\\"):
            curr_pc_path = curr_pc_path[:-1]

        # the path stored in the TANK_CURRENT_PC env var may be a symlink etc.
        # now we need to find which PC entity this corresponds to in Shotgun.        
        pc_registered_path = get_pc_registered_location(curr_pc_path)

        if pc_registered_path is None:
            raise TankError("Error starting from the configuration located in '%s' - "
                            "it looks like this pipeline configuration and tank command "
                            "has not been configured for the current operating system." % curr_pc_path)

        # now if this tank command is associated with the path, the registered path should be in 
        # in the list of paths found in the tank data backlink file
        if pc_registered_path not in current_os_pcs:
            raise TankError("You are trying to start using the configuration and tank command "
                            "located in '%s'. The path '%s' you are trying to load is not "
                            "associated with that configuration. The path you are trying to load "
                            "is associated with the following configurations: %s. "
                            "Please use the tank command or Sgtk API in any of those "
                            "locations in order to continue. This error can occur if you "
                            "have moved a Configuration on disk without correctly updating "
                            "it. It can also occur if you are trying to use a tank command "
                            "associated with Project A to try to operate on a Shot or Asset that "
                            "that belongs to a project B." % (curr_pc_path, path, current_os_pcs))

        # okay so this PC is valid!
        return PipelineConfiguration(pc_registered_path)






################################################################################################
# generic methods 

def get_current_code_install_root():
    """
    Returns the root location of the currently executing code, assuming that this code is 
    located inside a standard toolkit install setup. If the code that is running is part
    of a localized pipeline configuration, its root path will be returned, otherwise 
    a 'studio' root will be returned.

    For example, if __file__ is:
        /shotgun/studio/install/core/python/tank/pipelineconfig.py
    or:
        /shotgun/studio/install/core/python/tank.zip/tank/pipelineconfig.py
    then the root directory returned will be:
        /shotgun/studio
    
    This method may not return valid results if there has been any symlinks set up as part of
    the install structure.
    """
    
    # first, find the location of the info.yml file that can be found in:
    #   /shotgun/studio/install/core
    # this handles the different structure when using a zipped core:
    core_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    while core_dir and not os.path.exists(os.path.join(core_dir, "info.yml")):
        # move up the directory tree until we find the file:
        core_dir = os.path.dirname(core_dir)    
    
    # root directory is then two levels above the core directory:
    root_dir = os.path.abspath(os.path.join(core_dir, "..", ".."))
    
    if not os.path.exists(root_dir):
        raise TankError("Cannot resolve the install location from the location of the Core Code! "
                        "This can happen if you try to move or symlink the Sgtk API. "
                        "Please contact support.")
    return root_dir


def get_core_api_version_based_on_current_code():
    """
    Returns the version number string for the core API, based on the code that is currently
    executing.
    """
    # read this from info.yml
    info_yml_path = os.path.join(get_current_code_install_root(), "install", "core", "info.yml")
    
    try:
        info_fh = open(info_yml_path, "r")
        try:
            data = yaml.load(info_fh)
        finally:
            info_fh.close()
        data = str(data.get("version", "unknown"))
    except:
        data = "unknown"

    return data


def get_pc_registered_location(pipeline_config_root_path):
    """
    Loads the location metadata file from install_location.yml
    This contains a reflection of the paths given in the pc entity.

    Returns the path that has been registered for this pipeline configuration 
    for the current OS.
    This is the path that has been defined in shotgun. It is also the path that is being
    used in the inverse pointer files that exist in each storage.
    
    This is useful when drive letter mappings or symlinks are being used - in these
    cases get_path() may not return the same value as get_registered_location_path().
    
    This may return None if no path has been registered for the current os.
    """
    # now read in the pipeline_configuration.yml file
    cfg_yml = os.path.join(pipeline_config_root_path, "config", "core", "install_location.yml")

    if not os.path.exists(cfg_yml):
        raise TankError("Location metadata file '%s' missing! Please contact support." % cfg_yml)

    fh = open(cfg_yml, "rt")
    try:
        data = yaml.load(fh)
    except Exception, e:
        raise TankError("Looks like a config file is corrupt. Please contact "
                        "support! File: '%s' Error: %s" % (cfg_yml, e))
    finally:
        fh.close()

    # return the pc location for the current platform
    # env variables are allowed in these paths so expand them if they exist
    if sys.platform == "linux2":
        return os.path.expandvars(data.get("Linux"))
    elif sys.platform == "win32":
        return os.path.expandvars(data.get("Windows"))
    elif sys.platform == "darwin":
        return os.path.expandvars(data.get("Darwin"))
    else:
        raise TankError("Unsupported platform '%s'" % sys.platform)


def get_pc_disk_metadata(pipeline_config_root_path):
    """
    Loads the config metadata file from disk.    
    """

    # now read in the pipeline_configuration.yml file
    cfg_yml = os.path.join(pipeline_config_root_path, "config", "core", "pipeline_configuration.yml")

    if not os.path.exists(cfg_yml):
        raise TankError("Configuration metadata file '%s' missing! Please contact support." % cfg_yml)

    fh = open(cfg_yml, "rt")
    try:
        data = yaml.load(fh)
        if data is None:
            raise Exception("File contains no data!")
    except Exception, e:
        raise TankError("Looks like a config file is corrupt. Please contact "
                        "support! File: '%s' Error: %s" % (cfg_yml, e))
    finally:
        fh.close()

    return data


def _sanitize_path(path, separator):
    """
    Sanitize and clean up paths that may be incorrect.
    
    The following modifications will be carried out:
    
    None returns None
    
    Trailing slashes are removed:
    1. /foo/bar      - unchanged
    2. /foo/bar/     - /foo/bar
    3. z:/foo/       - z:\foo
    4. z:/           - z:\
    5. z:\           - z:\
    6. \\foo\bar\    - \\foo\bar

    Double slashes are removed:
    1. //foo//bar    - /foo/bar
    2. \\foo\\bar    - \\foo\bar
    
    :param path: the path to clean up
    :param separator: the os.sep to adjust the path for. / on nix, \ on win.
    :returns: cleaned up path
    """
    if path is None:
        return None
    
    # first, get rid of any slashes at the end
    # after this step, path value will be "/foo/bar", "c:" or "\\hello"
    path = path.rstrip("/\\")
    
    # add slash for drive letters: c: --> c:/
    if len(path) == 2 and path.endswith(":"):
        path += "/"
    
    # and convert to the right separators
    # after this we have a path with the correct slashes and no end slash
    local_path = path.replace("\\", separator).replace("/", separator)

    # now weed out any duplicated slashes. iterate until done
    while True:
        new_path = local_path.replace("//", "/")
        if new_path == local_path:
            break
        else:
            local_path = new_path
    
    # for windows, remove duplicated backslashes, except if they are 
    # at the beginning of the path
    while True:
        new_path = local_path[0] + local_path[1:].replace("\\\\", "\\")
        if new_path == local_path:
            break
        else:
            local_path = new_path

    return local_path

def get_pc_roots_metadata(pipeline_config_root_path):
    """
    Loads and validates the roots metadata file.
    
    The roots.yml file is a reflection of the local storages setup in Shotgun
    at project setup time and may contain anomalies in the path layout structure.
    
    The roots data will be prepended to paths and used for comparison so it is 
    critical that the paths are on a correct normalized form once they have been 
    loaded into the system.    
    """
    # now read in the roots.yml file
    # this will contain something like
    # {'primary': {'mac_path': '/studio', 'windows_path': None, 'linux_path': '/studio'}}
    roots_yml = os.path.join(pipeline_config_root_path, "config", "core", "roots.yml")

    if not os.path.exists(roots_yml):
        raise TankError("Roots metadata file '%s' missing! Please contact support." % roots_yml)

    fh = open(roots_yml, "rt")
    try:
        data = yaml.load(fh)
    except Exception, e:
        raise TankError("Looks like the roots file is corrupt. Please contact "
                        "support! File: '%s' Error: %s" % (roots_yml, e))
    finally:
        fh.close()

    # sanity check that there is a primary root
    if constants.PRIMARY_STORAGE_NAME not in data:
        raise TankError("Could not find a primary storage in roots file "
                        "for configuration %s!" % pipeline_config_root_path)

    # now use our helper function to process the paths    
    for s in data:
        data[s]["mac_path"] = _sanitize_path(data[s]["mac_path"], "/")
        data[s]["linux_path"] = _sanitize_path(data[s]["linux_path"], "/")
        data[s]["windows_path"] = _sanitize_path(data[s]["windows_path"], "\\")

    return data

def is_localized(pipeline_config_path):
    """
    Returns true if the pipeline configuration contains a localized API
    """
    # look for a localized API by searching for a _core_upgrader.py file
    api_file = os.path.join(pipeline_config_path, "install", "core", "_core_upgrader.py")
    return os.path.exists(api_file)

