# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46 = NOT_SET

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal, Optional, Union

from .model_base import NOT_SET, Base, NotSetType

Boolean = bool
"""
The `Boolean` scalar type represents `true` or `false`.
"""


DateTime = str
"""
A string representing a date and time in the UTC format.

**Example:** `"2025-01-01T00:00:00Z"`
"""


Filters = str
"""
A generic filter criteria used to narrow down the results of a query. This is either an RSQL-style query string or a JSON query object.

> **Note:** The input field name varies by endpoint, some use `filter` while others use `filters`. Refer to the specific query documentation for the correct field name.

#### ────────────────────────────

**Example 1: RSQL-style query string (e.g., `assetsBySearch` using `filter`):**
```json
{
  "filter": "attribute.someAttribute=='value'"
}
```

#### ────────────────────────────

**Example 2: JSON query object (e.g., `assetsBySearch` using `filter`):**
```json
{
  "filter": {
    "attribute.someAttribute": "value",
  }
}
```

#### ────────────────────────────

**Example 3: RSQL-style query string (e.g., `assetsByProjectId`, `assetsByTraversal` using `filters`):**
```json
{
  "filters": "has.component.type==autodesk.me:components.someType-1.0.0;attribute.deletionState==NOT_DELETED"
}
```
"""


Float = float
"""
The `Float` scalar type represents signed double-precision fractional values as specified by [IEEE 754](https://en.wikipedia.org/wiki/IEEE_floating_point).
"""


ID = str
"""
The `ID` scalar type represents a unique identifier, often used to refetch an object or as key for a cache. The ID type appears in a JSON response as a String; however, it is not intended to be human-readable. When expected as an input type, any string (such as `"4"`) or integer (such as `4`) input value will be accepted as an ID.
"""


Int = int
"""
The `Int` scalar type represents non-fractional signed whole numeric values. Int can represent values between -(2^31) and 2^31 - 1.
"""


JSONObject = dict
"""
Arbitrary JSON object.

**Example:**
```json
{
  "name": "John Doe",
  "age": 30,
}
```
"""


SchemaTypeId = str
"""
A string representing an Autodesk schema type ID.

#### ────────────────────────────

**Example:** `"autodesk.me:type.shot-1.1.0"`

The format is `<organization>.<group>:<schema_type_name>-<schema_version>`.
"""


String = str
"""
The `String` scalar type represents textual data, represented as UTF-8 character sequences. The String type is most often used by GraphQL to represent free-form human-readable text.
"""


class AppTypeEnum(Enum):
    SHOTGRID = 'shotgrid'


class AssetDeletionState(Enum):
    """
    An enum representing a deletion state of an asset
    """

    DELETION_FINALIZED = 'DELETION_FINALIZED'
    DELETION_INITIATED = 'DELETION_INITIATED'
    DELETION_PURGING = 'DELETION_PURGING'
    NOT_DELETED = 'NOT_DELETED'
    SOFT_DELETED = 'SOFT_DELETED'


class InternalAssetHardDeletionState(Enum):
    """
    An enum representing the state of an asset hard deletion
    """

    DELETION_FINALIZED = 'DELETION_FINALIZED'
    DELETION_INITIATED = 'DELETION_INITIATED'
    DELETION_PURGING = 'DELETION_PURGING'


class ListAction(Enum):
    """
    Specifies how to update containers, such as whether to replace the entire list or add data to it.
    Most commonly used for the assets' components management.
    """

    ADD = 'add'
    REPLACE = 'replace'


class NamedVersionChangeEnum(Enum):
    """
    The enum defining the possible versioning strategies for the `updateAsset` mutation.

    #### ────────────────────────────

    It is up to API consumers to define the versioning strategy. The simple approach would be placing small fixups
    (name changes, description updates, etc.) in a new revision, without creating a new numbered version. However, for more
    substantial changes (e.g., binary component data updates), you could consider creating a new numbered version.
    """

    CREATE_NEW = 'CREATE_NEW'
    UPDATES_LATEST = 'UPDATES_LATEST'


class PermissionActionEnum(Enum):
    """
    Available actions that can be used in permission policies.
    """

    CREATE_ONLY = 'CREATE_ONLY'
    DELETE_ONLY = 'DELETE_ONLY'
    READ_ONLY = 'READ_ONLY'
    UPDATE_ONLY = 'UPDATE_ONLY'


class PrimitiveType(Enum):
    """
    Autodesk Media and Entertainment built-in primitive types.
    """

    BINARY = 'Binary'
    BOOL = 'Bool'
    ENUM = 'Enum'
    FLOAT32 = 'Float32'
    FLOAT64 = 'Float64'
    INT16 = 'Int16'
    INT32 = 'Int32'
    INT64 = 'Int64'
    INT8 = 'Int8'
    NAMED_PROPERTY = 'NamedProperty'
    NODE_PROPERTY = 'NodeProperty'
    REFERENCE = 'Reference'
    RELATIONSHIP = 'Relationship'
    STRING = 'String'
    UINT16 = 'Uint16'
    UINT32 = 'Uint32'
    UINT64 = 'Uint64'
    UINT8 = 'Uint8'


class ProductTypeEnum(Enum):
    FLOWDATA = 'flowdata'


class ProjectState(Enum):
    """
    An enum representing the state of a MEDM project.
    """

    ACTIVE = 'ACTIVE'
    DELETED = 'DELETED'
    DELETING = 'DELETING'
    DELETING_STAGE_2 = 'DELETING_STAGE_2'


class PublishTransferStatus(Enum):
    """
    An enum representing the state of the binary transfer for the particular asset revision.
    """

    ACTIVE = 'ACTIVE'
    CANCELED = 'CANCELED'
    FAILED = 'FAILED'
    NOT_AVAILABLE = 'NOT_AVAILABLE'
    READY = 'READY'
    SUCCEEDED = 'SUCCEEDED'


class RoleAccessLevelEnum(Enum):
    """
    An enum that holds the possible access levels for a role.
    """

    ADMIN = 'ADMIN'
    MEMBER = 'MEMBER'


class RoleStatus(Enum):
    """
    An enum that holds the possible statuses for a role.
    """

    ACTIVATING = 'ACTIVATING'
    ACTIVE = 'ACTIVE'
    INACTIVE = 'INACTIVE'


class SchemaKind(Enum):
    """
    An enum that describes the kind of schema to create.
    """

    COMPONENT = 'component'
    PROPERTY = 'property'
    TYPE = 'type'


class SchemaStatus(Enum):
    """
    MEDM Schema available statuses
    """

    DRAFT = 'draft'
    PUBLISHED = 'published'


class SortOrderEnum(Enum):
    """
    Available sort orders for the `SortInput.order` field.

    #### ────────────────────────────
    """

    ASC = 'ASC'
    DESC = 'DESC'


class TraverseDirectionEnum(Enum):
    """
    An enumeration of the possible directions for a traversal.
    """

    INCOMING = 'INCOMING'
    OUTGOING = 'OUTGOING'


class UserAccessLevelEnum(Enum):
    """
    An enum that holds the possible access levels for a user.
    """

    ADMIN = 'ADMIN'
    MEMBER = 'MEMBER'


class UserStatusEnum(Enum):
    """
    User status enum
    """

    ACTIVE = 'ACTIVE'
    DELETED = 'DELETED'
    DISABLED = 'DISABLED'
    INACTIVE = 'INACTIVE'
    PENDING = 'PENDING'


class VersionTypeFilterEnum(Enum):
    """
    An enumeration of the possible types of versions to filter by.
    """

    ANY = 'ANY'
    NAMED = 'NAMED'
    NUMBERED = 'NUMBERED'


@dataclass
class AsyncJob(Base):
    """
    A common interface for all asynchronous jobs. The async job represents a long-running operation that is executed in the background.
    Users can query the state of the async job to check if the operation has been completed.
    """

    description: String = NOT_SET
    id: ID = NOT_SET
    state: String = NOT_SET
    updated_on: DateTime = NOT_SET
    typename__: Optional[Literal['AsyncJob']]= 'AsyncJob'  # type: ignore[assignment]


@dataclass
class AssetStorageUsage(Base):
    asset_id: ID = NOT_SET
    usage_bytes: Float = NOT_SET
    typename__: Optional[Literal['AssetStorageUsage']]= 'AssetStorageUsage'  # type: ignore[assignment]


@dataclass
class AssetUsageByAssetIdsResponse(Base):
    assets: list[AssetStorageUsage] = NOT_SET
    typename__: Optional[Literal['AssetUsageByAssetIdsResponse']]= 'AssetUsageByAssetIdsResponse'  # type: ignore[assignment]


@dataclass
class AssetVersionTraversalEdge(Base):
    """
    Represents an edge in the asset version traversal.
    """

    from_id: ID = NOT_SET
    to_id: ID = NOT_SET
    typename__: Optional[Literal['AssetVersionTraversalEdge']]= 'AssetVersionTraversalEdge'  # type: ignore[assignment]


@dataclass
class AssetsByTraversalEdge(Base):
    """
    Represents an edge in the assets by traversal response.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "fromId": "urn:medm:asset:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags",
      "toId": "urn:medm:asset:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags"
    }
    ```
    """

    from_id: ID = NOT_SET
    to_id: ID = NOT_SET
    typename__: Optional[Literal['AssetsByTraversalEdge']]= 'AssetsByTraversalEdge'  # type: ignore[assignment]


@dataclass
class AsyncJobsByIdsResponse(Base):
    """
    Represents a success response for the `asyncJobsByIds` query.
    """

    jobs: list[Union[ActivateProductJob, AddUserJob, ContainerJob, CreateProjectJob, CreateRoleJob, HardDeleteAssetAsyncJob, UploadFileJob]]= NOT_SET
    typename__: Optional[Literal['AsyncJobsByIdsResponse']]= 'AsyncJobsByIdsResponse'  # type: ignore[assignment]


@dataclass
class AuditInfo(Base):
    """
    User or service that changed the state of a collection
    """

    date: DateTime = NOT_SET
    service_id: Optional[ID]= NOT_SET
    user_id: Optional[ID]= NOT_SET
    typename__: Optional[Literal['AuditInfo']]= 'AuditInfo'  # type: ignore[assignment]


@dataclass
class BinaryComponentUrl(Base):
    """
    A URL representation of a binary blob URN.
    """

    url: String = NOT_SET
    urn: String = NOT_SET
    typename__: Optional[Literal['BinaryComponentUrl']]= 'BinaryComponentUrl'  # type: ignore[assignment]


@dataclass
class BinaryComponentUrlsByUrnsResponse(Base):
    """
    Represents a success response for the `binaryComponentUrlsByUrns` query.
    """

    urls: list[BinaryComponentUrl] = NOT_SET
    typename__: Optional[Literal['BinaryComponentUrlsByUrnsResponse']]= 'BinaryComponentUrlsByUrnsResponse'  # type: ignore[assignment]


@dataclass
class CollectionAttributeData(Base):
    """
    A supplementary type that describes `Collection` attributes.
    """

    category: String = NOT_SET
    name: String = NOT_SET
    type: String = NOT_SET
    value: String = NOT_SET
    typename__: Optional[Literal['CollectionAttributeData']]= 'CollectionAttributeData'  # type: ignore[assignment]


@dataclass
class CollectionAttributes(Base):
    """
    Collection attributes.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "id": "LcRmpkOzWwJk1QjHNQx9dA_L2C",
      "url": "/collections/LcRmpkOzWwJk1QjHNQx9dA_L2C/attributes",
      "data": [
        {
          "category": "system",
          "name": "medm.accessControl",
          "value": "ASSET",
          "type": "String"
        },
        {
          "category": "system",
          "name": "cpa.hubId",
          "value": "f70619c6-409c-466a-9c0d-17b741f6b9c7",
          "type": "String"
        },
        {
          "category": "system",
          "name": "asr.organizationId",
          "value": "medm17332059",
          "type": "String"
        },
        {
          "category": "system",
          "name": "cpa.tenantUrn",
          "value": "urn:adsk.identity:us.stg:tenant:17332059",
          "type": "String"
        },
        {
          "category": "application",
          "name": "description",
          "value": "MEDM Hub for testing and experimentation",
          "type": "String"
        },
        {
          "category": "system",
          "name": "cpa.adminGroupUrn",
          "value": "urn:adsk.identity:us.stg:group:17332059.286976659",
          "type": "String"
        },
        {
          "category": "system",
          "name": "medm.collectionType",
          "value": "provisioned",
          "type": "String"
        },
        {
          "category": "system",
          "name": "cpa.userGroupUrn",
          "value": "urn:adsk.identity:us.stg:group:17332059.286976658",
          "type": "String"
        },
        {
          "category": "system",
          "name": "asr.sharedGroupId",
          "value": "shared",
          "type": "String"
        },
        {
          "category": "application",
          "name": "name",
          "value": "Test Hub",
          "type": "String"
        },
        {
          "category": "system",
          "name": "medm.collectionOwner",
          "value": "CPA",
          "type": "String"
        },
        {
          "category": "system",
          "name": "cpa.appModuleType",
          "value": "asmgt",
          "type": "String"
        },
        {
          "category": "system",
          "name": "cpa.hubUrn",
          "value": "urn:adsk.ace:beta.hub:1584dbfb-9637-4ecf-8d57-d4ea9d2ad168",
          "type": "String"
        },
        {
          "category": "system",
          "name": "cpa.appModuleUrn",
          "value": "urn:adsk.ace:beta.module:e1e23da5-7c65-4492-a605-d845b24e566e",
          "type": "String"
        },
        {
          "category": "system",
          "name": "aum.tenantUrn",
          "value": "urn:adsk.aum:stg:tenant.oxygenId:7427133",
          "type": "String"
        }
      ]
    }
    ```
    """

    id: ID = NOT_SET
    url: String = NOT_SET
    data: Optional[list[CollectionAttributeData]]= NOT_SET
    typename__: Optional[Literal['CollectionAttributes']]= 'CollectionAttributes'  # type: ignore[assignment]


@dataclass
class CollectionConfig(Base):
    """
    Represents a collection config response.
    """

    collection_id: ID = NOT_SET
    data: JSONObject = NOT_SET
    typename__: Optional[Literal['CollectionConfig']]= 'CollectionConfig'  # type: ignore[assignment]


@dataclass
class ComponentData(Base):
    """
    A common type representing entity components. Most commonly used to describe components stored on assets and assets revisions.
    """

    data: JSONObject = NOT_SET
    name: String = NOT_SET
    parent_type_ids: list[String] = NOT_SET
    type_id: SchemaTypeId = NOT_SET
    typename__: Optional[Literal['ComponentData']]= 'ComponentData'  # type: ignore[assignment]


@dataclass
class ConfigByCollectionIdResponse(Base):
    """
    Represents a success response for the `configByCollectionId` query.
    """

    collection_id: ID = NOT_SET
    data: JSONObject = NOT_SET
    typename__: Optional[Literal['ConfigByCollectionIdResponse']]= 'ConfigByCollectionIdResponse'  # type: ignore[assignment]


@dataclass
class ConfigByProjectIdResponse(Base):
    """
    Represents a success response for the `configByProjectId` query.
    """

    data: JSONObject = NOT_SET
    project_id: ID = NOT_SET
    typename__: Optional[Literal['ConfigByProjectIdResponse']]= 'ConfigByProjectIdResponse'  # type: ignore[assignment]


@dataclass
class CreateUpdateConfigInCollectionResponse(Base):
    """
    Represents a success response for the `createUpdateConfigInCollection` mutation.
    """

    config: CollectionConfig = NOT_SET
    typename__: Optional[Literal['CreateUpdateConfigInCollectionResponse']]= 'CreateUpdateConfigInCollectionResponse'  # type: ignore[assignment]


@dataclass
class DeletePermissionPolicyResponse(Base):
    """
    Represents a success response from the `deletePermissionPolicy` mutation.
    """

    message: String = NOT_SET
    success: Boolean = NOT_SET
    typename__: Optional[Literal['DeletePermissionPolicyResponse']]= 'DeletePermissionPolicyResponse'  # type: ignore[assignment]


@dataclass
class DeleteSchemaDisplayDataResponse(Base):
    """
    Represents a success response for the `deleteSchemaDisplayData` mutation.
    """

    message: String = NOT_SET
    typename__: Optional[Literal['DeleteSchemaDisplayDataResponse']]= 'DeleteSchemaDisplayDataResponse'  # type: ignore[assignment]


@dataclass
class FlowData(Base):
    collection_id: Optional[String]= NOT_SET
    component_name: Optional[String]= NOT_SET
    local_file_path: Optional[String]= NOT_SET
    path: Optional[String]= NOT_SET
    storage_key: Optional[String]= NOT_SET
    urn: Optional[String]= NOT_SET
    typename__: Optional[Literal['FlowData']]= 'FlowData'  # type: ignore[assignment]


@dataclass
class GetUploadFilePartResponse(Base):
    """
    Represents a success response for the `getUploadFilePart` mutation.
    """

    num_bytes: Float = NOT_SET
    send_url: String = NOT_SET
    upload_file_async_job_id: ID = NOT_SET
    typename__: Optional[Literal['GetUploadFilePartResponse']]= 'GetUploadFilePartResponse'  # type: ignore[assignment]


@dataclass
class HardDeleteAssetAsyncJob(AsyncJob):
    """
    An asynchronous job that tracks the hard deletion process of an asset. This job monitors the permanent removal
    of the asset and all its associated data including binaries, components, relationships, versions, revisions,
    permissions, and metadata.
    """

    description: String = NOT_SET
    id: ID = NOT_SET
    state: String = NOT_SET
    updated_on: DateTime = NOT_SET
    typename__: Optional[Literal['HardDeleteAssetAsyncJob']]= 'HardDeleteAssetAsyncJob'  # type: ignore[assignment]


@dataclass
class HardDeleteAssetResponse(Base):
    """
    Represents a success response from the `hardDeleteAsset` mutation.
    """

    job: HardDeleteAssetAsyncJob = NOT_SET
    typename__: Optional[Literal['HardDeleteAssetResponse']]= 'HardDeleteAssetResponse'  # type: ignore[assignment]


@dataclass
class InternalCollection(Base):
    """
    An internal `Collection` type, representing a just created collection via the `activateProduct` mutation.
    """

    attributes: CollectionAttributes = NOT_SET
    created_by: AuditInfo = NOT_SET
    id: ID = NOT_SET
    last_modified_by: AuditInfo = NOT_SET
    description: Optional[String]= NOT_SET
    name: Optional[String]= NOT_SET
    typename__: Optional[Literal['InternalCollection']]= 'InternalCollection'  # type: ignore[assignment]


@dataclass
class InternalDeleteProjectResponse(Base):
    """
    Represents a success response from the `internalDeleteProject` mutation.
    """

    message: String = NOT_SET
    typename__: Optional[Literal['InternalDeleteProjectResponse']]= 'InternalDeleteProjectResponse'  # type: ignore[assignment]


@dataclass
class InternalHardDeleteAssetResponse(Base):
    """
    Represents a success response from the `internalHardDeleteAsset` mutation.
    """

    message: String = NOT_SET
    typename__: Optional[Literal['InternalHardDeleteAssetResponse']]= 'InternalHardDeleteAssetResponse'  # type: ignore[assignment]


@dataclass
class InternalUpdateProjectStateResponse(Base):
    """
    Represents a success response from the `internalUpdateProjectState` mutation.
    """

    project_state: ProjectState = NOT_SET
    typename__: Optional[Literal['InternalUpdateProjectStateResponse']]= 'InternalUpdateProjectStateResponse'  # type: ignore[assignment]


@dataclass
class JobFlowData(Base):
    """
    Flow metadata associated with the `ContainerJob` type.
    """

    collection_id: ID = NOT_SET
    typename__: Optional[Literal['JobFlowData']]= 'JobFlowData'  # type: ignore[assignment]


@dataclass
class PaginationStandard(Base):
    """
    Common pagination response object that is used in all paginated queries.
    """

    page_size: Int = NOT_SET
    cursor: Optional[String]= NOT_SET
    typename__: Optional[Literal['PaginationStandard']]= 'PaginationStandard'  # type: ignore[assignment]


@dataclass
class PermissionPolicy(Base):
    """
    `PermissionPolicy` type represents a container type, specifying which actions are allowed for certain locations.

    This policy applies to users who are assigned the role associated with this policy.

    Example:

    ```json
    {
        name: 'Animations_full_access', = NOT_SET
        action: [ = NOT_SET
          PermissionActionEnum.READ_ONLY,
          PermissionActionEnum.CREATE_ONLY,
          PermissionActionEnum.UPDATE_ONLY,
          PermissionActionEnum.DELETE_ONLY,
        ],
        location: ["urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea"] = NOT_SET
    }
    ```
    """

    action: list[PermissionActionEnum] = NOT_SET
    location: list[ID] = NOT_SET
    name: String = NOT_SET
    typename__: Optional[Literal['PermissionPolicy']]= 'PermissionPolicy'  # type: ignore[assignment]


@dataclass
class ProjectConfig(Base):
    """
    Represents a project config response.
    """

    data: JSONObject = NOT_SET
    project_id: ID = NOT_SET
    typename__: Optional[Literal['ProjectConfig']]= 'ProjectConfig'  # type: ignore[assignment]


@dataclass
class ProjectUsageByProjectIdResponse(Base):
    """
    Represents a success response from the `projectUsageByProjectId` query.
    """

    project_id: ID = NOT_SET
    limit_bytes: Optional[Float]= NOT_SET
    usage_bytes: Optional[Float]= NOT_SET
    typename__: Optional[Literal['ProjectUsageByProjectIdResponse']]= 'ProjectUsageByProjectIdResponse'  # type: ignore[assignment]


@dataclass
class PropertyDisplayData(Base):
    """
    A supplementary type that describes the display data for a schema property.
    """

    display_name: String = NOT_SET
    property_id: String = NOT_SET
    typename__: Optional[Literal['PropertyDisplayData']]= 'PropertyDisplayData'  # type: ignore[assignment]


@dataclass
class PropertyLevelDisplayData(Base):
    """
    A supplementary type that describes the display data for a property level.
    """

    display_name: String = NOT_SET
    typename__: Optional[Literal['PropertyLevelDisplayData']]= 'PropertyLevelDisplayData'  # type: ignore[assignment]


@dataclass
class RemoveUserFromCollectionResponse(Base):
    """
    Represents a success response from the `removeUserFromCollection` mutation.
    """

    success: Boolean = NOT_SET
    typename__: Optional[Literal['RemoveUserFromCollectionResponse']]= 'RemoveUserFromCollectionResponse'  # type: ignore[assignment]


@dataclass
class RemoveUserFromProjectResponse(Base):
    """
    Represents a success response from the `removeUserFromProject` mutation.
    """

    success: Boolean = NOT_SET
    typename__: Optional[Literal['RemoveUserFromProjectResponse']]= 'RemoveUserFromProjectResponse'  # type: ignore[assignment]


@dataclass
class Role(Base):
    """
    A type represntng MEDM role that is associated with a project and holds a list of policies.

    Any changes made to the roles are reflected in the CPA UI.

    #### ────────────────────────────

    **Example:**
    ```json
      {
        "id": "JQbdxs17yBArQ23EbI3psK_L2C::GeWJet2dJeHeaIWyelpROg_ags::ohUUPDn9rVwLEJThfDplIj_aga",
        "roleName": "Artists-general",
        "policies": [
          {
            "name": "assets_r_w_u",
            "action": [
              "READ_ONLY",
              "CREATE_ONLY",
              "UPDATE_ONLY",
            ],
            "location": [
              "urn:medm:asset:JQbdxs17yBArQ23EbI3psK_L2C:GeWJet2dJeHeaIWyelpROg_ags:R883bYp915wU6LXvuHZ29a_mea"
            ]
          },
          {
            "name": "experiments_r_w_u_d",
            "action": [
              "READ_ONLY",
              "CREATE_ONLY",
              "UPDATE_ONLY",
              "DELETE_ONLY",
            ],
            "location": [
              "urn:medm:asset:JQbdxs17yBArQ23EbI3psK_L2C:GeWJet2dJeHeaIWyelpROg_ags:pAlcntaU0ST69Su0Xv0R27_mea"
            ]
          }
        ],
        "status": "ACTIVE",
        "defaultAccessLevel": "MEMBER"
      }
    ```
    """

    default_access_level: RoleAccessLevelEnum = NOT_SET
    id: ID = NOT_SET
    policies: list[PermissionPolicy] = NOT_SET
    role_name: String = NOT_SET
    status: RoleStatus = NOT_SET
    typename__: Optional[Literal['Role']]= 'Role'  # type: ignore[assignment]


@dataclass
class RolesByProjectIdResponse(Base):
    """
    Represents a success response from the `rolesByProjectId` query.
    """

    pagination: PaginationStandard = NOT_SET
    roles: list[Role] = NOT_SET
    typename__: Optional[Literal['RolesByProjectIdResponse']]= 'RolesByProjectIdResponse'  # type: ignore[assignment]


@dataclass
class SchemaDisplayData(Base):
    """
    A type that describes the display data for a schema.
    """

    properties_display_data: list[PropertyDisplayData] = NOT_SET
    schema_type_id: SchemaTypeId = NOT_SET
    display_name: Optional[String]= NOT_SET
    typename__: Optional[Literal['SchemaDisplayData']]= 'SchemaDisplayData'  # type: ignore[assignment]


@dataclass
class SchemaDisplayDataResponse(Base):
    """
    Represents a success response for the `schemaDisplayData` query.
    """

    schema_display_data: SchemaDisplayData = NOT_SET
    typename__: Optional[Literal['SchemaDisplayDataResponse']]= 'SchemaDisplayDataResponse'  # type: ignore[assignment]


@dataclass
class SchemaLevelDisplayData(Base):
    """
    A supplementary type that describes the display data for a schema level.
    """

    display_name: String = NOT_SET
    typename__: Optional[Literal['SchemaLevelDisplayData']]= 'SchemaLevelDisplayData'  # type: ignore[assignment]


@dataclass
class SchemaLibrary(Base):
    """
    M&E Schema Library. Schema library serves as a container for schemas.
    """

    create_time: DateTime = NOT_SET
    created_by: ID = NOT_SET
    description: String = NOT_SET
    last_modified_by: ID = NOT_SET
    last_modified_time: DateTime = NOT_SET
    name: String = NOT_SET
    title: String = NOT_SET
    typename__: Optional[Literal['SchemaLibrary']]= 'SchemaLibrary'  # type: ignore[assignment]


@dataclass
class SchemaRegistryInfo(Base):
    """
    Schema registry information containing various metadata about the schema registry that the current Project belongs to.
    """

    group_id: ID = NOT_SET
    organization_id: ID = NOT_SET
    typename__: Optional[Literal['SchemaRegistryInfo']]= 'SchemaRegistryInfo'  # type: ignore[assignment]


@dataclass
class SchemasBySuperTypeResponse(Base):
    """
    Represents a success response for the `schemasBySuperType` query.
    """

    pagination: PaginationStandard = NOT_SET
    schema_types: list[SchemaTypeId] = NOT_SET
    typename__: Optional[Literal['SchemasBySuperTypeResponse']]= 'SchemasBySuperTypeResponse'  # type: ignore[assignment]


@dataclass
class SoftDeleteAssetResponse(Base):
    """
    Represents a success response from the `softDeleteAsset` mutation.
    """

    message: String = NOT_SET
    typename__: Optional[Literal['SoftDeleteAssetResponse']]= 'SoftDeleteAssetResponse'  # type: ignore[assignment]


@dataclass
class UpdatePermissionPolicyResponse(Base):
    """
    Represents a success response from the `updatePermissionPolicy` mutation.
    """

    policy: PermissionPolicy = NOT_SET
    typename__: Optional[Literal['UpdatePermissionPolicyResponse']]= 'UpdatePermissionPolicyResponse'  # type: ignore[assignment]


@dataclass
class UpdateRoleResponse(Base):
    """
    Represents a success response from the `updateRole` mutation.
    """

    role: Role = NOT_SET
    typename__: Optional[Literal['UpdateRoleResponse']]= 'UpdateRoleResponse'  # type: ignore[assignment]


@dataclass
class UpdateSchemaDisplayDataResponse(Base):
    """
    Represents a success response for the `updateSchemaDisplayData` mutation.
    """

    display_data: SchemaDisplayData = NOT_SET
    typename__: Optional[Literal['UpdateSchemaDisplayDataResponse']]= 'UpdateSchemaDisplayDataResponse'  # type: ignore[assignment]


@dataclass
class UploadFileJob(AsyncJob):
    """
    Represents a job that tracks the upload process for the given blob URN.
    """

    description: String = NOT_SET
    id: ID = NOT_SET
    state: String = NOT_SET
    updated_on: DateTime = NOT_SET
    typename__: Optional[Literal['UploadFileJob']]= 'UploadFileJob'  # type: ignore[assignment]


@dataclass
class User(Base):
    """
    A user that is part of a MEDM collection (Hub) or a project.
    """

    id: ID = NOT_SET
    access_level: Optional[UserAccessLevelEnum]= NOT_SET
    account_id: Optional[ID]= NOT_SET
    email: Optional[String]= NOT_SET
    first_name: Optional[String]= NOT_SET
    last_modified_on: Optional[DateTime]= NOT_SET
    last_name: Optional[String]= NOT_SET
    roles: Optional[list[Role]]= NOT_SET
    status: Optional[UserStatusEnum]= NOT_SET
    user_name: Optional[String]= NOT_SET
    typename__: Optional[Literal['User']]= 'User'  # type: ignore[assignment]


@dataclass
class UsersByCollectionIdResponse(Base):
    """
    Represents a success response from the `usersByCollectionId` query.
    """

    pagination: PaginationStandard = NOT_SET
    users: list[User] = NOT_SET
    typename__: Optional[Literal['UsersByCollectionIdResponse']]= 'UsersByCollectionIdResponse'  # type: ignore[assignment]


@dataclass
class UsersByProjectIdResponse(Base):
    """
    Represents a success response from the `usersByProjectId` query.
    """

    pagination: PaginationStandard = NOT_SET
    users: list[User] = NOT_SET
    typename__: Optional[Literal['UsersByProjectIdResponse']]= 'UsersByProjectIdResponse'  # type: ignore[assignment]


@dataclass
class AddUserByEmailToCollectionInput(Base):
    collection_id: ID = NOT_SET
    email: String = NOT_SET
    access_level: Optional[UserAccessLevelEnum]= NOT_SET
    first_name: Optional[String]= NOT_SET
    last_name: Optional[String]= NOT_SET
    suppress_emails: Optional[Boolean]= NOT_SET
    typename__: Optional[Literal['AddUserByEmailToCollectionInput']]= 'AddUserByEmailToCollectionInput'  # type: ignore[assignment]


@dataclass
class AddUserByEmailToProjectInput(Base):
    email: String = NOT_SET
    project_id: ID = NOT_SET
    access_level: Optional[UserAccessLevelEnum]= NOT_SET
    first_name: Optional[String]= NOT_SET
    last_name: Optional[String]= NOT_SET
    role_ids: Optional[list[ID]]= NOT_SET
    suppress_emails: Optional[Boolean]= NOT_SET
    typename__: Optional[Literal['AddUserByEmailToProjectInput']]= 'AddUserByEmailToProjectInput'  # type: ignore[assignment]


@dataclass
class AssetParentInput(Base):
    """
    Input parameters for the `assetParent` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "assetId": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea"
    }
    ```
    """

    asset_id: ID = NOT_SET
    typename__: Optional[Literal['AssetParentInput']]= 'AssetParentInput'  # type: ignore[assignment]


@dataclass
class AssetRevisionsByIdsInput(Base):
    """
    Input parameters for the `assetRevisionsByIds` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "ids": [
        "urn:medm:assetRevision:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea:ver:4",
        "urn:medm:assetRevision:xtLamgbDTWb5fpoIQE4IV8_L2C:HmIvdp43Tta74T3dylklbe_ags:fOCzH9pQBmJQTIyTl5TZ55_mea:latest"
      ]
    }
    ```
    """

    ids: list[ID] = NOT_SET
    typename__: Optional[Literal['AssetRevisionsByIdsInput']]= 'AssetRevisionsByIdsInput'  # type: ignore[assignment]


@dataclass
class AssetUsageByAssetIdsInput(Base):
    asset_ids: list[ID] = NOT_SET
    typename__: Optional[Literal['AssetUsageByAssetIdsInput']]= 'AssetUsageByAssetIdsInput'  # type: ignore[assignment]


@dataclass
class AssetVersionsByIdsInput(Base):
    """
    Input parameters for the `assetVersionsByIds` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "ids": [
         "urn:medm:assetVersion:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea:ver:4",
         "urn:medm:assetVersion:xtLamgbDTWb5fpoIQE4IV8_L2C:HmIvdp43Tta74T3dylklbe_ags:fOCzH9pQBmJQTIyTl5TZ55_mea:latest"
      ]
    }
    ```
    """

    ids: list[ID] = NOT_SET
    typename__: Optional[Literal['AssetVersionsByIdsInput']]= 'AssetVersionsByIdsInput'  # type: ignore[assignment]


@dataclass
class AssetsByIdsInput(Base):
    """
    Input parameters for the `assetsByIds` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "ids": [
        "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea"
        "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:fOCzH9pQBmJQTIyTl5TZ55_mea"
      ]
    }
    ```
    """

    ids: list[ID] = NOT_SET
    typename__: Optional[Literal['AssetsByIdsInput']]= 'AssetsByIdsInput'  # type: ignore[assignment]


@dataclass
class AsyncJobsByIdsInput(Base):
    """
    Input parameters for the `asyncJobsByIds` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "ids": ["urn:asyncjob:3:project:yn2F9RNBjaBmuXqyyhcHra_L2C:dXJuOm1lZG06cHJvamVjdDp5bjJGOVJOQmphQm11WHF5eWhjSHJhX0wyQzozbUZmRVM2YkJUYXJ4aGFESGJCV1ZBX2Fncw=="]
    }
    ```
    """

    ids: list[ID] = NOT_SET
    typename__: Optional[Literal['AsyncJobsByIdsInput']]= 'AsyncJobsByIdsInput'  # type: ignore[assignment]


@dataclass
class BinaryComponentUrlsByUrnsInput(Base):
    """
    Input parameters for the `binaryComponentUrlsByUrns` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "projectId": "urn:medm:project:JQbdxs17yBArQ23EbI3psK_L2C:GeWJet2dJeHeaIWyelpROg_ags",
      "urns": ["urn:medm:binaryComponent:JQbdxs17yBArQ23EbI3psK_L2C:GeWJet2dJeHeaIWyelpROg_ags:R883bYp915wU6LXvuHZ29a_mea:rev:2:0:TestObject:98765432-abcd-efgh-ijkl-mnopqrstuvwx:sample_file.txt:Test_File_Name.txt:DOCUMENT:UNCLASSIFIED:type=document&version=1.0:0:a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"]
    }
    ```
    """

    project_id: ID = NOT_SET
    urns: list[String] = NOT_SET
    context: Optional[JSONObject]= NOT_SET
    typename__: Optional[Literal['BinaryComponentUrlsByUrnsInput']]= 'BinaryComponentUrlsByUrnsInput'  # type: ignore[assignment]


@dataclass
class CloseUploadFileInput(Base):
    """
    Input parameters for the `closeUploadFile` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "asyncJobId": "urn:asyncjob:4:upload:85A2QvKcasyVu1M7vhHInM_L2C:2f56aaa7-03bd-444a-b4ab-194978c113a9:f5b496a6-5fc0-498a-bbd7-0349485fd243:urn%253Amoxion%253Av5%253A85A2QvKcasyVu1M7vhHInM_L2C%253Aurn%25253Amedm%25253Aproject%25253A85A2QvKcasyVu1M7vhHInM_L2C%25253A9Q2ZGx1JnrasKSZALTQgjw_ags%253A0027de11-12b3-08b6-204d-168b5132b826%253A1%253AGitHub_Logo%253A9972fbd4-6037-401f-9f0c-befd4b772f83%253AGitHub_Logo.png%253AGitHub_Logo.png%253AIMAGE%253ANOTWATERMARKED%253A%253A-1%253Afalse%253A3f0e337a90dd8d3d4157e435f4627a8f",
      "etags": ["cefc20232703e5e3c24efd5f50d75e26"],
      "state": "SUCCEEDED"
    }
    ```
    """

    async_job_id: ID = NOT_SET
    state: String = NOT_SET
    context: Optional[JSONObject]= NOT_SET
    etags: Optional[list[String]]= NOT_SET
    typename__: Optional[Literal['CloseUploadFileInput']]= 'CloseUploadFileInput'  # type: ignore[assignment]


@dataclass
class ComponentDataInput(Base):
    """
    A common input type that is used to create or update components on various MEDM entities.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "typeId": "autodesk.me:component.binary.video-1.0.0"
      "name": "water_binary_1",
      "data": {
          "data": [
              {
                  "uri": "https://d1dgv2k5zpmitw.cloudfront.net/dsc-data/135658-764361528_tiny.mp4",
                  "mimeType": "video/mp4",
                  "path": "water.mp4",
              }
          ],
          "purpose": "thumbnail"
      },
    }
    ```
    """

    name: String = NOT_SET
    type_id: SchemaTypeId = NOT_SET
    data: Optional[JSONObject]= NOT_SET
    typename__: Optional[Literal['ComponentDataInput']]= 'ComponentDataInput'  # type: ignore[assignment]


@dataclass
class ConfigByCollectionIdInput(Base):
    """
    Input parameters for the `configByCollectionId` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "collectionId": "yn2F9RNBjaBmuXqyyhcHra_L2C"
    }
    ```
    """

    collection_id: ID = NOT_SET
    typename__: Optional[Literal['ConfigByCollectionIdInput']]= 'ConfigByCollectionIdInput'  # type: ignore[assignment]


@dataclass
class ConfigByProjectIdInput(Base):
    """
    Input parameters for the `configByProjectId` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "projectId": "urn:medm:project:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags",
      "doMerge": true
    }
    ```
    """

    project_id: ID = NOT_SET
    do_merge: Optional[Boolean]= NOT_SET
    typename__: Optional[Literal['ConfigByProjectIdInput']]= 'ConfigByProjectIdInput'  # type: ignore[assignment]


@dataclass
class CreatePermissionPolicyInRoleInput(Base):
    """
    Input parameters for the `createPermissionPolicyInRole` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "roleId": "JQbdxs17yBArQ23EbI3psK_L2C::GeWJet2dJeHeaIWyelpROg_ags::ohUUPDn9rVwLEJThfDplIj_aga",
      "name": "Read and Write access to the Animation folder",
      "policyAction": [PermissionActionEnum.ReadOnly, PermissionActionEnum.WriteOnly],
      "policyLocation": ["urn:medm:asset:JQbdxs17yBArQ23EbI3psK_L2C:GeWJet2dJeHeaIWyelpROg_ags:R883bYp915wU6LXvuHZ29a_mea"]
    }
    ```
    """

    name: String = NOT_SET
    policy_action: list[PermissionActionEnum] = NOT_SET
    role_id: ID = NOT_SET
    policy_location: Optional[list[ID]]= NOT_SET
    typename__: Optional[Literal['CreatePermissionPolicyInRoleInput']]= 'CreatePermissionPolicyInRoleInput'  # type: ignore[assignment]


@dataclass
class CreateProjectInput(Base):
    """
    Input parameters for the `createProject` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "collectionId": "yn2F9RNBjaBmuXqyyhcHra_L2C",
      "name": "My VFX Project",
      "suppressEmails": true
    }
    ```
    """

    collection_id: ID = NOT_SET
    name: String = NOT_SET
    suppress_emails: Optional[Boolean]= NOT_SET
    typename__: Optional[Literal['CreateProjectInput']]= 'CreateProjectInput'  # type: ignore[assignment]


@dataclass
class CreateRoleInProjectInput(Base):
    project_id: ID = NOT_SET
    role_name: String = NOT_SET
    default_access_level: Optional[RoleAccessLevelEnum]= NOT_SET
    typename__: Optional[Literal['CreateRoleInProjectInput']]= 'CreateRoleInProjectInput'  # type: ignore[assignment]


@dataclass
class CreateSchemaLibraryInput(Base):
    """
    Input parameters for the `createSchemaLibrary` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "projectId": "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDj9g_ags",
      "name": "denysPersonalLib",
      "title": "Denys' Personal Library",
      "description": "Personal library containing shot schemas"
    }
    ```
    """

    description: String = NOT_SET
    name: String = NOT_SET
    project_id: ID = NOT_SET
    title: String = NOT_SET
    typename__: Optional[Literal['CreateSchemaLibraryInput']]= 'CreateSchemaLibraryInput'  # type: ignore[assignment]


@dataclass
class CreateUpdateConfigInCollectionInput(Base):
    """
    Input parameters to create or update a config associated with a specified collection.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "collectionId": "yn2F9RNBjaBmuXqyyhcHra_L2C",
      "data": {
        "keyA": "value1",
        "keyB": "value2"
       }
    }
    ```
    """

    collection_id: ID = NOT_SET
    data: JSONObject = NOT_SET
    typename__: Optional[Literal['CreateUpdateConfigInCollectionInput']]= 'CreateUpdateConfigInCollectionInput'  # type: ignore[assignment]


@dataclass
class CreateUpdateConfigInProjectInput(Base):
    """
    Input parameters to create or update a config associated with a specified project.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "projectId": "urn:medm:project:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags",
      "data": {
        "keyA": "value1",
        "keyB": "value2"
      }
    }
    ```
    """

    data: JSONObject = NOT_SET
    project_id: ID = NOT_SET
    typename__: Optional[Literal['CreateUpdateConfigInProjectInput']]= 'CreateUpdateConfigInProjectInput'  # type: ignore[assignment]


@dataclass
class DeletePermissionPolicyInput(Base):
    """
    Input parameters for the `deletePermissionPolicy` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "roleId": "JQbdxs17yBArQ23EbI3psK_L2C::GeWJet2dJeHeaIWyelpROg_ags::ohUUPDn9rVwLEJThfDplIj_aga",
      "name": "Animation_r_w_u",
    }
    ```
    """

    name: String = NOT_SET
    role_id: ID = NOT_SET
    typename__: Optional[Literal['DeletePermissionPolicyInput']]= 'DeletePermissionPolicyInput'  # type: ignore[assignment]


@dataclass
class DeleteSchemaDisplayDataInput(Base):
    """
    Input parameters for the `deleteSchemaDisplayData` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "schemaTypeId": "autodesk.me:person-1.0.0",
    }
    """

    schema_type_id: SchemaTypeId = NOT_SET
    typename__: Optional[Literal['DeleteSchemaDisplayDataInput']]= 'DeleteSchemaDisplayDataInput'  # type: ignore[assignment]


@dataclass
class GetPersonalSpaceProjectInput(Base):
    """
    Input parameters for the `getPersonalSpaceProject` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "type": "default",
      "internalUseNew": true
    }
    ```
    """

    type: String = NOT_SET
    internal_use_new: Optional[Boolean]= NOT_SET
    typename__: Optional[Literal['GetPersonalSpaceProjectInput']]= 'GetPersonalSpaceProjectInput'  # type: ignore[assignment]


@dataclass
class GetSchemaDisplayDataInput(Base):
    """
    Input parameters for the `schemaDisplayData` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "schemaTypeId": "autodesk.me:asset-1.0.0"
    }
    ```
    """

    schema_type_id: SchemaTypeId = NOT_SET
    typename__: Optional[Literal['GetSchemaDisplayDataInput']]= 'GetSchemaDisplayDataInput'  # type: ignore[assignment]


@dataclass
class GetUploadFilePartInput(Base):
    """
    Input parameters for the `getUploadFilePart` mutation.

    #### ────────────────────────────

    **Technical details:**
       Chunking constraints:
        - **Minimum chunk size**: 5MB (5,242,880 bytes)
        - **Maximum file size**: 5TB (5,497,558,138,880 bytes)
        - **Maximum number of chunks**: 10,000 parts

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "hash": "zvwgIycD5ePCTv1fUNdeJg==",
      "asyncJobId": "urn:asyncjob:4:upload:85A2QvKcasyVu1M7vhHInM_L2C:2f56aaa7-03bd-444a-b4ab-194978c113a9:f5b496a6-5fc0-498a-bbd7-0349485fd243:urn%253Amoxion%253Av5%253A85A2QvKcasyVu1M7vhHInM_L2C%253Aurn%25253Amedm%25253Aproject%25253A85A2QvKcasyVu1M7vhHInM_L2C%25253A9Q2ZGx1JnrasKSZALTQgjw_ags%253A0027de11-12b3-08b6-204d-168b5132b826%253A1%253AGitHub_Logo%253A9972fbd4-6037-401f-9f0c-befd4b772f83%253AGitHub_Logo.png%253AGitHub_Logo.png%253AIMAGE%253ANOTWATERMARKED%253A%253A-1%253Afalse%253A3f0e337a90dd8d3d4157e435f4627a8f",
      "partNum": 4
    }
    ```
    """

    async_job_id: ID = NOT_SET
    hash: String = NOT_SET
    part_num: Int = NOT_SET
    context: Optional[JSONObject]= NOT_SET
    typename__: Optional[Literal['GetUploadFilePartInput']]= 'GetUploadFilePartInput'  # type: ignore[assignment]


@dataclass
class HardDeleteAssetConditionInput(Base):
    """
    Supplementary input parameters for the `hardDeleteAsset` mutation that allows to specify additional conditions for
    the operation to succeed. Using these conditions will help making asset hard-deletion more predictable and reliable.

    #### ────────────────────────────

    **Constraints:**
        - Must specify at least one condition;
        - All the conditions must be met for the update operation to succeed;
    """

    require_latest_numbered_version_id: Optional[ID]= NOT_SET
    require_latest_revision_id: Optional[ID]= NOT_SET
    require_parent_id: Optional[ID]= NOT_SET
    typename__: Optional[Literal['HardDeleteAssetConditionInput']]= 'HardDeleteAssetConditionInput'  # type: ignore[assignment]


@dataclass
class HardDeleteAssetInput(Base):
    id: ID = NOT_SET
    update_condition: Optional[HardDeleteAssetConditionInput]= NOT_SET
    typename__: Optional[Literal['HardDeleteAssetInput']]= 'HardDeleteAssetInput'  # type: ignore[assignment]


@dataclass
class InternalCreatePrivateProjectInput(Base):
    collection_id: ID = NOT_SET
    name: String = NOT_SET
    components: Optional[list[ComponentDataInput]]= NOT_SET
    description: Optional[String]= NOT_SET
    typename__: Optional[Literal['InternalCreatePrivateProjectInput']]= 'InternalCreatePrivateProjectInput'  # type: ignore[assignment]


@dataclass
class InternalDeleteProjectInput(Base):
    project_id: ID = NOT_SET
    typename__: Optional[Literal['InternalDeleteProjectInput']]= 'InternalDeleteProjectInput'  # type: ignore[assignment]


@dataclass
class InternalHardDeleteAssetInput(Base):
    id: ID = NOT_SET
    deletion_state: Optional[InternalAssetHardDeletionState]= NOT_SET
    typename__: Optional[Literal['InternalHardDeleteAssetInput']]= 'InternalHardDeleteAssetInput'  # type: ignore[assignment]


@dataclass
class InternalToolCreatePrivateCollectionInput(Base):
    name: String = NOT_SET
    description: Optional[String]= NOT_SET
    is_temporary: Optional[Boolean]= NOT_SET
    typename__: Optional[Literal['InternalToolCreatePrivateCollectionInput']]= 'InternalToolCreatePrivateCollectionInput'  # type: ignore[assignment]


@dataclass
class InternalUpdateProjectStateInput(Base):
    project_id: ID = NOT_SET
    target_state: ProjectState = NOT_SET
    typename__: Optional[Literal['InternalUpdateProjectStateInput']]= 'InternalUpdateProjectStateInput'  # type: ignore[assignment]


@dataclass
class OpenUploadFileInput(Base):
    """
    Input parameters for the `openUploadFile` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "uploadUri": "upload://f5b496a6-5fc0-498a-bbd7-0349485fd243",
      "urnId": urn:blob:2:fcap:85A2QvKcasyVu1M7vhHInM_L2C:32d02eee-3326-4ad8-b2f3-763129f07544::urn%253Amoxion%253Av5%253A85A2QvKcasyVu1M7vhHInM_L2C%253Aurn%25253Amedm%25253Aproject%25253A85A2QvKcasyVu1M7vhHInM_L2C%25253A9Q2ZGx1JnrasKSZALTQgjw_ags%253A00349b47-bb70-e8bb-c3d6-6fd08a58e222%253A1%253Awater_original%253A32d02eee-3326-4ad8-b2f3-763129f07544%253Awater.mp4%253Awater.mp4%253AVIDEO%253ANOTWATERMARKED%253A%253A-1%253Afalse%253A11f56ee154f7038da1edd73f298a4a11
    }
    ```
    """

    upload_uri: String = NOT_SET
    urn_id: ID = NOT_SET
    context: Optional[JSONObject]= NOT_SET
    typename__: Optional[Literal['OpenUploadFileInput']]= 'OpenUploadFileInput'  # type: ignore[assignment]


@dataclass
class PaginationInput(Base):
    """
    *`PaginationInput`* is the common input type for all the paginated MEDM queries.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "cursor": "7b226d6178496473223a7b2261737365744964",
      "limit": 15
    }
    ```
    """

    cursor: Optional[String]= NOT_SET
    limit: Optional[Int]= NOT_SET
    typename__: Optional[Literal['PaginationInput']]= 'PaginationInput'  # type: ignore[assignment]


@dataclass
class ProductActivationInput(Base):
    """
    Input type for the `activateProduct` mutation.

    #### ────────────────────────────

    **Usage:**
      ```graphql
      mutation {
        activateProduct(input: {
          appId: "2efghijklmnop:shotgrid:4qrstuvwx:qwerty" = NOT_SET
          appType: shotgrid = NOT_SET
          productType: flowdata = NOT_SET
        }) {
          jobId
          state
        }
      }
      ```
    """

    app_id: ID = NOT_SET
    app_type: AppTypeEnum = NOT_SET
    product_type: ProductTypeEnum = NOT_SET
    suppress_emails: Optional[Boolean]= NOT_SET
    typename__: Optional[Literal['ProductActivationInput']]= 'ProductActivationInput'  # type: ignore[assignment]


@dataclass
class ProjectUsageByProjectIdInput(Base):
    """
    Input parameters for the `projectUsageByProjectId` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "projectId": "urn:medm:project:dKFvEv3CIH1mKyuz4bsxfq_L2C"
    }
    ```
    """

    project_id: ID = NOT_SET
    typename__: Optional[Literal['ProjectUsageByProjectIdInput']]= 'ProjectUsageByProjectIdInput'  # type: ignore[assignment]


@dataclass
class ProjectsByCollectionIdInput(Base):
    """
    `projectsByCollectionId` query input parameters that are used to fetch a list of active projects within
    a specified collection.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "collectionId": "yn2F9RNBjaBmuXqyyhcHra_L2C",
      "pagination": {
        "limit": 50,
        "cursor": "7b226d6178496473223a7b2261737365744964"
      }
    }
    ```
    """

    collection_id: ID = NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['ProjectsByCollectionIdInput']]= 'ProjectsByCollectionIdInput'  # type: ignore[assignment]


@dataclass
class ProjectsByIdsInput(Base):
    """
    `projectsByIds` query input parameters that are used to fetch one or multiple projects by their IDs.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "ids": [
        "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDj9g_ags",
        "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:9usbdEFMm6XMha2gNKcLDP_ags",
      ]
    }
    """

    ids: list[ID] = NOT_SET
    typename__: Optional[Literal['ProjectsByIdsInput']]= 'ProjectsByIdsInput'  # type: ignore[assignment]


@dataclass
class PropertyDisplayDataInput(Base):
    """
    A supplementary input type that is used to describe the display data for a property. See the `createSchemaDisplayData` mutation for more details.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "propertyId": "name",
      "displayName": "Person's name"
    }
    ```
    """

    display_name: String = NOT_SET
    property_id: String = NOT_SET
    typename__: Optional[Literal['PropertyDisplayDataInput']]= 'PropertyDisplayDataInput'  # type: ignore[assignment]


@dataclass
class PropertyTypeInput(Base):
    """
    A supplementaty input type describing a property type used in property definitions while creating a new schema.
    See the `createSchema` mutation for more details. It's expected either `primitiveType` or `customType` field to be set, but not both.

    #### ────────────────────────────

    **Example 1: Using a built-in primitive type:**
    ```json
    {
      "primitiveType": "String"
    }
    ```

    **Example 2: Using a custom primitive type:**
    ```json
    {
      "customType": "autodesk.me:myCustomPrimitiveType-1.0.0"
    }
    ```
    #### ────────────────────────────

    **Constraints:**
     - The `primitiveType` and `customType` fields are mutually exclusive and cannot both be set simultaneously.
     - At least one of these fields must be provided; they cannot both be `null`.
    """

    custom_type: Optional[SchemaTypeId]= NOT_SET
    primitive_type: Optional[PrimitiveType]= NOT_SET
    typename__: Optional[Literal['PropertyTypeInput']]= 'PropertyTypeInput'  # type: ignore[assignment]


@dataclass
class RecoverAssetConditionInput(Base):
    """
    Supplementary input parameters for the `recoverAsset` mutation that allows to specify additional conditions for
    the operation to succeed. Using these conditions will help making asset recovery more predictable and reliable.

    #### ────────────────────────────

    **Constraints:**
        - Must specify at least one condition;
        - All the conditions must be met for the update operation to succeed;
    """

    require_latest_numbered_version_id: Optional[ID]= NOT_SET
    require_latest_revision_id: Optional[ID]= NOT_SET
    require_parent_id: Optional[ID]= NOT_SET
    typename__: Optional[Literal['RecoverAssetConditionInput']]= 'RecoverAssetConditionInput'  # type: ignore[assignment]


@dataclass
class RecoverAssetInput(Base):
    """
    Input parameters for the `recoverAsset` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "id": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea"
    }
    ```
    """

    id: ID = NOT_SET
    update_condition: Optional[RecoverAssetConditionInput]= NOT_SET
    typename__: Optional[Literal['RecoverAssetInput']]= 'RecoverAssetInput'  # type: ignore[assignment]


@dataclass
class RemoveUserFromCollectionInput(Base):
    id: ID = NOT_SET
    typename__: Optional[Literal['RemoveUserFromCollectionInput']]= 'RemoveUserFromCollectionInput'  # type: ignore[assignment]


@dataclass
class RemoveUserFromProjectInput(Base):
    id: ID = NOT_SET
    project_id: ID = NOT_SET
    typename__: Optional[Literal['RemoveUserFromProjectInput']]= 'RemoveUserFromProjectInput'  # type: ignore[assignment]


@dataclass
class RolesByProjectIdInput(Base):
    """
    `rolesByProjectId` input query parameters that are used to fetch a paginated list of roles within a
    specified project.

    #### ────────────────────────────

    **Example:**

    ```json
    {
      "projectId": "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDj9g_ags",
      "pagination": {
        "limit": 10,
        "cursor": "7b226d6178496473223a7b2261737365744964"
      }
    }
    ```
    """

    project_id: ID = NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['RolesByProjectIdInput']]= 'RolesByProjectIdInput'  # type: ignore[assignment]


@dataclass
class SchemaLibrariesByCollectionIdInput(Base):
    """
    Input parameters for the `schemaLibrariesByCollectionId` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "collectionId": "yn2F9RNBjaBmuXqyyhcHra_L2C",
      "includeReadOnlyLibraries": true,
      "pagination": { "limit": 10, "cursor": "cursor_value" }
    }
    ```
    """

    collection_id: ID = NOT_SET
    include_read_only_libraries: Optional[Boolean]= NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['SchemaLibrariesByCollectionIdInput']]= 'SchemaLibrariesByCollectionIdInput'  # type: ignore[assignment]


@dataclass
class SchemasByLibraryIdInput(Base):
    """
    Input parameters for the `schemasByLibraryId` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "projectId": "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDj9g_ags",
      "libraryId": "myPersonalLibrary",
      "pagination": { "limit": 10, "cursor": "cursor_value" },
      "includeOtherOrgs": true
    }
    ```
    """

    library_id: String = NOT_SET
    project_id: ID = NOT_SET
    include_other_orgs: Optional[Boolean]= NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['SchemasByLibraryIdInput']]= 'SchemasByLibraryIdInput'  # type: ignore[assignment]


@dataclass
class SchemasBySuperTypeInput(Base):
    """
    Input parameters for the `schemasBySuperType` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "collectionId": "yn2F9RNBjaBmuXqyyhcHra_L2C",
      "typeId": "autodesk.me:asset-1.0.0",
      "pagination": {
        "limit": 10,
        "cursor": "cursor_value"
      },
      "includeSubSubClasses": true
    }
    ```
    """

    collection_id: ID = NOT_SET
    type_id: SchemaTypeId = NOT_SET
    include_sub_sub_classes: Optional[Boolean]= NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['SchemasBySuperTypeInput']]= 'SchemasBySuperTypeInput'  # type: ignore[assignment]


@dataclass
class SchemasByTypeIdInput(Base):
    """
    Input parameters for the `schemasByTypeId` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "typeIds": ["autodesk.data:asset-1.0.0", "autodesk.me:numberedAssetVersionSnapshot-1.0.0"],
      "includeInherited": true
    }
    ```
    """

    type_ids: list[SchemaTypeId] = NOT_SET
    include_inherited: Optional[Boolean]= NOT_SET
    typename__: Optional[Literal['SchemasByTypeIdInput']]= 'SchemasByTypeIdInput'  # type: ignore[assignment]


@dataclass
class SoftDeleteAssetConditionInput(Base):
    """
    Supplementary input parameters for the `softDeleteAsset` mutation that allows to specify additional conditions for
    the operation to succeed. Using these conditions will help making asset soft-deletion more predictable and reliable.

    #### ────────────────────────────

    **Constraints:**
        - Must specify at least one condition;
        - All the conditions must be met for the update operation to succeed;
    """

    require_latest_numbered_version_id: Optional[ID]= NOT_SET
    require_latest_revision_id: Optional[ID]= NOT_SET
    require_parent_id: Optional[ID]= NOT_SET
    typename__: Optional[Literal['SoftDeleteAssetConditionInput']]= 'SoftDeleteAssetConditionInput'  # type: ignore[assignment]


@dataclass
class SoftDeleteAssetInput(Base):
    """
    Input parameters for the `softDeleteAsset` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "id": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea"
    }
    ```
    """

    id: ID = NOT_SET
    update_condition: Optional[SoftDeleteAssetConditionInput]= NOT_SET
    typename__: Optional[Literal['SoftDeleteAssetInput']]= 'SoftDeleteAssetInput'  # type: ignore[assignment]


@dataclass
class SortInput(Base):
    """
    Common sort input for sorting the results of a query
    """

    field: String = NOT_SET
    order: SortOrderEnum = NOT_SET
    typename__: Optional[Literal['SortInput']]= 'SortInput'  # type: ignore[assignment]


@dataclass
class UpdateAssetConditionInput(Base):
    """
    Supplementary input parameters for the `updateAsset` mutation that allows to specify additional conditions for
    the update operation to succeed. Using these conditions will help making asset updates more predictable and reliable.

    #### ────────────────────────────

    **Constraints:**
        - Must specify at least one condition;
        - All the conditions must be met for the update operation to succeed;
    """

    require_latest_numbered_version_id: Optional[ID]= NOT_SET
    require_latest_revision_id: Optional[ID]= NOT_SET
    require_parent_id: Optional[ID]= NOT_SET
    typename__: Optional[Literal['UpdateAssetConditionInput']]= 'UpdateAssetConditionInput'  # type: ignore[assignment]


@dataclass
class UpdateAssetParentConditionInput(Base):
    """
    Supplementary input parameters for the `updateAssetParent` mutation that allows to specify additional conditions for
    the operation to succeed. Using these conditions will help making asset parent updates more predictable and reliable.

    #### ────────────────────────────

    **Constraints:**
        - Must specify at least one condition;
        - All the conditions must be met for the update operation to succeed;
    """

    require_latest_numbered_version_id: Optional[ID]= NOT_SET
    require_latest_revision_id: Optional[ID]= NOT_SET
    require_parent_id: Optional[ID]= NOT_SET
    typename__: Optional[Literal['UpdateAssetParentConditionInput']]= 'UpdateAssetParentConditionInput'  # type: ignore[assignment]


@dataclass
class UpdateAssetParentInput(Base):
    """
    Input parameters for the `updateAssetParent` mutation.

    #### ────────────────────────────

    **Example 1: Move an asset under another asset**
    ```json
    {
      "id": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea",
      "newParent": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:R883bYp915wU6LXvuHZ28a_mea"
    }
    ```

    #### ────────────────────────────

    **Example 2: Move an asset under a project**
    ```json
    {
      "id": "urn:medm:asset:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags:uNih6SeoDE2sFwUSVebK89_mea",
      "newParent": "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags"
    }
    ```
    """

    id: ID = NOT_SET
    parent_id: ID = NOT_SET
    update_condition: Optional[UpdateAssetParentConditionInput]= NOT_SET
    typename__: Optional[Literal['UpdateAssetParentInput']]= 'UpdateAssetParentInput'  # type: ignore[assignment]


@dataclass
class UpdatePermissionPolicyInput(Base):
    """
    Input parameters for the `updatePermissionPolicy` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "roleId": "JQbdxs17yBArQ23EbI3psK_L2C::GeWJet2dJeHeaIWyelpROg_ags::ohUUPDn9rVwLEJThfDplIj_aga",
      "name": "Animation_r_w",
      "newName": "Animation_r_w_u",
      "policyAction": [PermissionActionEnum.ReadOnly, PermissionActionEnum.WriteOnly, PermissionActionEnum.UpdateOnly],
    }
    ```
    """

    name: String = NOT_SET
    role_id: ID = NOT_SET
    new_name: Optional[String]= NOT_SET
    policy_action: Optional[list[PermissionActionEnum]]= NOT_SET
    policy_location: Optional[list[String]]= NOT_SET
    typename__: Optional[Literal['UpdatePermissionPolicyInput']]= 'UpdatePermissionPolicyInput'  # type: ignore[assignment]


@dataclass
class UpdateProjectInput(Base):
    """
    Input parameters for the `updateProject` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "id": "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDj9g_ags",
      "name": "My VFX Project",
      "description": "Shots & Cuts",
      "components": [
        {
          "typeId": "autodesk.me:component.externalId-1.0.0",
          "name": "site_id",
          "data": {
            "id": "urn:shotgrid:asset:156414|new_site_id.shotgrid.autodesk.com|100"
          }
        }
      ],
      "componentsAction": "REPLACE"
    }
    ```
    """

    id: ID = NOT_SET
    components: Optional[list[ComponentDataInput]]= NOT_SET
    components_action: Optional[ListAction]= NOT_SET
    description: Optional[String]= NOT_SET
    name: Optional[String]= NOT_SET
    typename__: Optional[Literal['UpdateProjectInput']]= 'UpdateProjectInput'  # type: ignore[assignment]


@dataclass
class UpdateRoleInput(Base):
    role_id: ID = NOT_SET
    default_access_level: Optional[RoleAccessLevelEnum]= NOT_SET
    role_name: Optional[String]= NOT_SET
    status: Optional[RoleStatus]= NOT_SET
    typename__: Optional[Literal['UpdateRoleInput']]= 'UpdateRoleInput'  # type: ignore[assignment]


@dataclass
class UpdateSchemaDisplayDataInput(Base):
    """
    Input parameters for the `updateSchemaDisplayData` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "schemaTypeId": "autodesk.me:person-1.0.0",
      "displayName": "Person",
      "propertiesDisplayData": [
        {
          "propertyId": "name",
          "displayName": "Name"
        }
      ]
    }
    ```

    #### ────────────────────────────

    **Constraints:**
      - `displayName` and `propertiesDisplayData` must not be empty at the same time;
    """

    schema_type_id: SchemaTypeId = NOT_SET
    display_name: Optional[String]= NOT_SET
    properties_display_data: Optional[list[PropertyDisplayDataInput]]= NOT_SET
    typename__: Optional[Literal['UpdateSchemaDisplayDataInput']]= 'UpdateSchemaDisplayDataInput'  # type: ignore[assignment]


@dataclass
class UpdateUserInCollectionInput(Base):
    access_level: UserAccessLevelEnum = NOT_SET
    collection_id: ID = NOT_SET
    id: ID = NOT_SET
    typename__: Optional[Literal['UpdateUserInCollectionInput']]= 'UpdateUserInCollectionInput'  # type: ignore[assignment]


@dataclass
class UpdateUserInProjectInput(Base):
    access_level: UserAccessLevelEnum = NOT_SET
    id: ID = NOT_SET
    project_id: ID = NOT_SET
    role_ids: Optional[list[ID]]= NOT_SET
    typename__: Optional[Literal['UpdateUserInProjectInput']]= 'UpdateUserInProjectInput'  # type: ignore[assignment]


@dataclass
class UsersByCollectionIdInput(Base):
    collection_id: ID = NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['UsersByCollectionIdInput']]= 'UsersByCollectionIdInput'  # type: ignore[assignment]


@dataclass
class UsersByProjectIdInput(Base):
    project_id: ID = NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['UsersByProjectIdInput']]= 'UsersByProjectIdInput'  # type: ignore[assignment]


@dataclass
class UsesTargetInput(Base):
    """
    Input parameters for the `uses` list in the `CreateAssetInput` and `UpdateAssetInput` mutations.
    This will instruct MEDM Server to create `uses` (dependency) relationships between the newly
    created asset and the versions specified here.

    #### ────────────────────────────

    **Example 1: 'Use' a numbered version**
    ```json
    {
      "toVersionId": "urn:medm:assetVersion:yn2F9RNBjaBmuXqyyhcHra_L2C:q8h7X8ALWhjr7Aj64HeiWm_ags:uOlLknggmDc62LqViH3wa7_mea:ver:7",
    }
    ```

    **Example 2: 'Use' a named version**
    ```json
    {
      "toVersionId": "urn:medm:assetVersion:yn2F9RNBjaBmuXqyyhcHra_L2C:q8h7X8ALWhjr7Aj64HeiWm_ags:uOlLknggmDc62LqViH3wa7_mea:latest",
    }
    ```
    """

    to_version_id: ID = NOT_SET
    typename__: Optional[Literal['UsesTargetInput']]= 'UsesTargetInput'  # type: ignore[assignment]


@dataclass
class VersionFilterInput(Base):
    """
    Input parameters for the `versionFilter` field that is used in the `assetVersionsByAssetId` query.
    """

    type: Optional[VersionTypeFilterEnum]= NOT_SET
    typename__: Optional[Literal['VersionFilterInput']]= 'VersionFilterInput'  # type: ignore[assignment]


# A union type that represents the parent of an asset, which can be either an asset or a project.
AssetParent = Union[
    'Asset',
    'Project',
]


@dataclass
class AddUserJob(AsyncJob):
    """
    An asynchronous job that monitors the MEDM user addition to a project or a collection.
    """

    description: String = NOT_SET
    id: ID = NOT_SET
    state: String = NOT_SET
    updated_on: DateTime = NOT_SET
    created_on: DateTime = NOT_SET
    user: Optional[User]= NOT_SET
    typename__: Optional[Literal['AddUserJob']]= 'AddUserJob'  # type: ignore[assignment]


@dataclass
class AssetParentResponse(Base):
    """
    A Represents a success response from the `assetParent` query.

    #### ────────────────────────────

    **Examples:**
    Suppose we have the following asset graph:
    ```
    Spaceships (project)
        |
        |--contains--> Model_1
        |                 |
        |                 |--contains--> Shader_1
    ```

    #### ────────────────────────────

    #### Example 1: Get the parent of `Model_1`
    **Input parameters:**
    ```
    {
      "input": { assetId: Model_1.id } = NOT_SET
    }
    ```

    **Response:**
    ```
    {
      "assetParent": {
        "parent": {
          "id": Spaceships.id,
          "name": "Spaceships"
          ...
        }
      }
    }
    ```

    #### ────────────────────────────

    #### Example 2: Get the parent of `Shader_1`
    **Input parameters:**
    ```
    {
      "input": { assetId: Shader_1.id } = NOT_SET
    }
    ```

    **Response:**
    ```
    {
      "assetParent": {
        "parent": {
          "id": Model_1.id,
          "name": "Model_1"
          ...
        }
      }
    }
    ```
    """

    parent: AssetParent = NOT_SET
    typename__: Optional[Literal['AssetParentResponse']]= 'AssetParentResponse'  # type: ignore[assignment]


@dataclass
class AsyncJobsByAssetRevisionIdsResponse(Base):
    """
    Represents a success response for the `asyncJobsByAssetRevisionIds` query.
    """

    jobs: list[Union[ActivateProductJob, AddUserJob, ContainerJob, CreateProjectJob, CreateRoleJob, HardDeleteAssetAsyncJob, UploadFileJob]]= NOT_SET
    pagination: PaginationStandard = NOT_SET
    typename__: Optional[Literal['AsyncJobsByAssetRevisionIdsResponse']]= 'AsyncJobsByAssetRevisionIdsResponse'  # type: ignore[assignment]


@dataclass
class AuditLog(Base):
    """
    A shared type that holds audit log details regarding the creation or modification of a MEDM entity.
    """

    date: DateTime = NOT_SET
    service_id: Optional[ID]= NOT_SET
    user: Optional[User]= NOT_SET
    user_id: Optional[ID]= NOT_SET
    typename__: Optional[Literal['AuditLog']]= 'AuditLog'  # type: ignore[assignment]


@dataclass
class CloseUploadFileResponse(Base):
    """
    Represents a success response for the `closeUploadFile` mutation.
    """

    job: UploadFileJob = NOT_SET
    typename__: Optional[Literal['CloseUploadFileResponse']]= 'CloseUploadFileResponse'  # type: ignore[assignment]


@dataclass
class Collection(Base):
    """
    `Collection` is the main container entity in the MEDM data model. It groups various entities togehter:
     - Projects
     - Users
     - Roles
     - Schemas
     - Configuration(s)

    Additionally, each collection is associated with a Autodesk CPA Hub and can be managed on the admin
    [dashboard](https://cpa.autodesk.com/).
    """

    created: AuditLog = NOT_SET
    id: ID = NOT_SET
    modified: AuditLog = NOT_SET
    name: String = NOT_SET
    description: Optional[String]= NOT_SET
    typename__: Optional[Literal['Collection']]= 'Collection'  # type: ignore[assignment]


@dataclass
class CollectionsResponse(Base):
    """
    Represents a success response from the `collections` query.
    """

    collections: list[Collection] = NOT_SET
    pagination: PaginationStandard = NOT_SET
    typename__: Optional[Literal['CollectionsResponse']]= 'CollectionsResponse'  # type: ignore[assignment]


@dataclass
class ContainerJob(AsyncJob):
    """
    A job that contains other asynchronous jobs and track the upload processes.
    """

    description: String = NOT_SET
    id: ID = NOT_SET
    state: String = NOT_SET
    updated_on: DateTime = NOT_SET
    flow_data: JobFlowData = NOT_SET
    jobs: list[Union[ActivateProductJob, AddUserJob, ContainerJob, CreateProjectJob, CreateRoleJob, HardDeleteAssetAsyncJob, UploadFileJob]]= NOT_SET
    typename__: Optional[Literal['ContainerJob']]= 'ContainerJob'  # type: ignore[assignment]


@dataclass
class CreateCollectionInHubResponse(Base):
    """
    Represents a success response for the `createCollectionInHub` mutation.
    """

    collection: InternalCollection = NOT_SET
    typename__: Optional[Literal['CreateCollectionInHubResponse']]= 'CreateCollectionInHubResponse'  # type: ignore[assignment]


@dataclass
class CreatePermissionPolicyInRoleResponse(Base):
    """
    Represents a success response from the `createPermissionPolicyInRole` mutation.
    """

    policy: PermissionPolicy = NOT_SET
    typename__: Optional[Literal['CreatePermissionPolicyInRoleResponse']]= 'CreatePermissionPolicyInRoleResponse'  # type: ignore[assignment]


@dataclass
class CreateRoleJob(AsyncJob):
    """
    An asynchronous job that monitors the MEDM role creation process.
    """

    description: String = NOT_SET
    id: ID = NOT_SET
    state: String = NOT_SET
    updated_on: DateTime = NOT_SET
    created_on: DateTime = NOT_SET
    role: Optional[Role]= NOT_SET
    typename__: Optional[Literal['CreateRoleJob']]= 'CreateRoleJob'  # type: ignore[assignment]


@dataclass
class CreateSchemaDisplayDataResponse(Base):
    """
    Represents a success response for the `createSchemaDisplayData` mutation.
    """

    display_data: SchemaDisplayData = NOT_SET
    typename__: Optional[Literal['CreateSchemaDisplayDataResponse']]= 'CreateSchemaDisplayDataResponse'  # type: ignore[assignment]


@dataclass
class CreateSchemaLibraryResponse(Base):
    """
    Represents a success response for the `createSchemaLibrary` mutation.
    """

    schema_library: SchemaLibrary = NOT_SET
    typename__: Optional[Literal['CreateSchemaLibraryResponse']]= 'CreateSchemaLibraryResponse'  # type: ignore[assignment]


@dataclass
class CreateUpdateConfigInProjectResponse(Base):
    """
    Represents a success response for the `createUpdateConfigInProject` mutation.
    """

    config: ProjectConfig = NOT_SET
    typename__: Optional[Literal['CreateUpdateConfigInProjectResponse']]= 'CreateUpdateConfigInProjectResponse'  # type: ignore[assignment]


@dataclass
class InternalToolCreatePrivateCollectionResponse(Base):
    """
    Represents a success response from the `internalToolCreatePrivateCollection` mutation.
    """

    collection: Collection = NOT_SET
    typename__: Optional[Literal['InternalToolCreatePrivateCollectionResponse']]= (
        'InternalToolCreatePrivateCollectionResponse'
    )


@dataclass
class OpenUploadFileResponse(Base):
    """
    Represents a success response for the `openUploadFile` mutation.
    """

    job: UploadFileJob = NOT_SET
    typename__: Optional[Literal['OpenUploadFileResponse']]= 'OpenUploadFileResponse'  # type: ignore[assignment]


@dataclass
class Project(Base):
    """
    Media and Entertainment project type definition.

    #### ────────────────────────────

    **Technical details:**

      - MEDM project acts as an container entity that encompasses various assets;
      - Each MEDM project represents a root entity in the asset hierarchy;
      - There could be many projects within a single collection.

    #### ────────────────────────────

    **Example:**

    Below you can see an example of a trivial MEDM project with a few assets. "Animation" is the MEDM project that
    contains a top-level "Shots" folder with three assets.

    #### ────────────────────────────

    ```
      ┌─────────────────────────────────────────────────┐
      │                                                 │
      │                 Animation (project)             │
      │                        |                        │
      │                     contains                    │
      │                        |                        │
      │                        ▼                        │
      │                 +---------------+               │
      │                 |     Shots     |               │
      │                 +-------┬-------+               │
      │                         │                       │
      │       ┌──────────┬──────┴───────┬──────────┐    │
      │       │          │              │          │    │
      │   contains   contains      contains    (etc)    │
      │       │          │              │               │
      │       ▼          ▼              ▼               │
      │   +--------+ +--------+     +--------+          │
      │   |Shot_001| |Shot_002|     |Shot_003|          │
      │   +--------+ +--------+     +--------+          │
      │                                                 │
      └─────────────────────────────────────────────────┘
    ```
    """

    components: list[ComponentData] = NOT_SET
    created: AuditLog = NOT_SET
    has_children: Boolean = NOT_SET
    hub_id: String = NOT_SET
    hub_urn: String = NOT_SET
    id: ID = NOT_SET
    modified: AuditLog = NOT_SET
    name: String = NOT_SET
    state: ProjectState = NOT_SET
    description: Optional[String]= NOT_SET
    schema_registry_info: Optional[SchemaRegistryInfo]= NOT_SET
    typename__: Optional[Literal['Project']]= 'Project'  # type: ignore[assignment]


@dataclass
class ProjectsByCollectionIdResponse(Base):
    """
    Represents a success response from the `projectsByCollectionId` query.
    """

    pagination: PaginationStandard = NOT_SET
    projects: list[Project] = NOT_SET
    typename__: Optional[Literal['ProjectsByCollectionIdResponse']]= 'ProjectsByCollectionIdResponse'  # type: ignore[assignment]


@dataclass
class ProjectsByIdsResponse(Base):
    """
    Represents a success response from the `projectsByIds` query.
    """

    projects: list[Project] = NOT_SET
    typename__: Optional[Literal['ProjectsByIdsResponse']]= 'ProjectsByIdsResponse'  # type: ignore[assignment]


@dataclass
class PropertiesDefinition(Base):
    """
    Flow Properties Definition
    """

    name: String = NOT_SET
    context: Optional[String]= NOT_SET
    display_data: Optional[PropertyLevelDisplayData]= NOT_SET
    length: Optional[Int]= NOT_SET
    properties: Optional[list[Optional[PropertiesDefinition]]]= NOT_SET
    type: Optional[String]= NOT_SET
    value: Optional[JSONObject]= NOT_SET
    typename__: Optional[Literal['PropertiesDefinition']]= 'PropertiesDefinition'  # type: ignore[assignment]


@dataclass
class Schema(Base):
    """
    Represents a Media and Entertainment schema.
    """

    inherits: list[SchemaTypeId] = NOT_SET
    name: String = NOT_SET
    properties: list[Optional[PropertiesDefinition]]= NOT_SET
    type_id: SchemaTypeId = NOT_SET
    display_data: Optional[SchemaLevelDisplayData]= NOT_SET
    typename__: Optional[Literal['Schema']]= 'Schema'  # type: ignore[assignment]


@dataclass
class SchemaLibrariesByCollectionIdResponse(Base):
    """
    Represents a success response from the `schemaLibrariesByCollectionId` query.
    """

    pagination: PaginationStandard = NOT_SET
    libraries: Optional[list[SchemaLibrary]]= NOT_SET
    typename__: Optional[Literal['SchemaLibrariesByCollectionIdResponse']]= 'SchemaLibrariesByCollectionIdResponse'  # type: ignore[assignment]


@dataclass
class SchemasByLibraryIdResponse(Base):
    """
    Represents a success response from the `schemasByLibraryId` query.
    """

    pagination: PaginationStandard = NOT_SET
    schemas: list[Schema] = NOT_SET
    typename__: Optional[Literal['SchemasByLibraryIdResponse']]= 'SchemasByLibraryIdResponse'  # type: ignore[assignment]


@dataclass
class SchemasByTypeIdResponse(Base):
    """
    Represents a success response for the `schemasByTypeId` query.
    """

    inherited_schemas: list[Schema] = NOT_SET
    schemas: list[Schema] = NOT_SET
    typename__: Optional[Literal['SchemasByTypeIdResponse']]= 'SchemasByTypeIdResponse'  # type: ignore[assignment]


@dataclass
class UpdateProjectResponse(Base):
    """
    Represents a success response from the `updateProject` mutation.
    """

    project: Project = NOT_SET
    typename__: Optional[Literal['UpdateProjectResponse']]= 'UpdateProjectResponse'  # type: ignore[assignment]


@dataclass
class UpdateUserInCollectionResponse(Base):
    """
    Represents a success response from the `updateUserInCollection` mutation.
    """

    user: User = NOT_SET
    typename__: Optional[Literal['UpdateUserInCollectionResponse']]= 'UpdateUserInCollectionResponse'  # type: ignore[assignment]


@dataclass
class UpdateUserInProjectResponse(Base):
    """
    Represents a success response from the `updateUserInProject` mutation.
    """

    user: User = NOT_SET
    typename__: Optional[Literal['UpdateUserInProjectResponse']]= 'UpdateUserInProjectResponse'  # type: ignore[assignment]


@dataclass
class AssetRevisionsByAssetIdInput(Base):
    """
    Input parameters for the `assetRevisionsByAssetId` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "assetId": "urn:medm:asset:xtLamgbDTWb5fpoIQE4IV8_L2C:HmIvdp43Tta74T3dylklbe_ags:uNih6SeoDE2sFwUSVebK89_mea",
      "sort": {
        "field": "created.date",
        "order": "DESC"
      },
      "pagination": {
        "limit": 30,
        "cursor": "cursor_value"
      }
    }
    ```
    The query above will return the latest 30 asset revisions of the requested asset.
    """

    asset_id: ID = NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    sort: Optional[SortInput]= NOT_SET
    typename__: Optional[Literal['AssetRevisionsByAssetIdInput']]= 'AssetRevisionsByAssetIdInput'  # type: ignore[assignment]


@dataclass
class AssetVersionsByAssetIdInput(Base):
    """
    Input parameters for the `assetVersionsByAssetId` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "assetId": "urn:medm:asset:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags",
      "filter": {
        "type": "NUMBERED"
      },
      "sort": {
        "field": "created.date",
        "order": "DESC"
      },
      "pagination": {
        "limit": 30,
        "cursor": "cursor_value"
      }
    }
    ```
    The query above will return the latest 30 numbered versions of the asset.
    """

    asset_id: ID = NOT_SET
    filter: Optional[VersionFilterInput]= NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    sort: Optional[SortInput]= NOT_SET
    typename__: Optional[Literal['AssetVersionsByAssetIdInput']]= 'AssetVersionsByAssetIdInput'  # type: ignore[assignment]


@dataclass
class AssetVersionsByTraversalInput(Base):
    """
    Input parameters for the `assetVersionsByTraversal` query.

    #### ────────────────────────────

    **Example 1: Traverse the immediate `uses` links from the given version ID:**
    ```json
    {
      "startAtId": "urn:medm:assetVersion:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea:ver:1",
      "direction": "OUTGOING",
      "depth": 1
    }
    ```

    The following query will return a list of versions that are being used by the version supplied in the `startAtId` parameter.
    Traversal will explore only the top level of the `uses` hierarchy in this case.

    #### ────────────────────────────

    **Example 2: Used-by use-case:**
    ```json
    {
      "startAtId":  "urn:medm:assetVersion:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea:ver:1",
      "direction": "INCOMING",
      "depth": 1
    }
    ```

    The following query will return a list of versions that are using the version supplied in the `startAtId` parameter.
    Traversal will explore only the top level of the `uses` hierarchy in this case.

    #### ────────────────────────────

    **Example 3: Infinite depth traversal:**
    ```json
    {
      "startAtId": "urn:medm:assetVersion:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea:ver:1",
      "direction": "OUTGOING",
      "depth": 0
    }
    ```

    The following query will return a list of all the versions that are being used by the version supplied in the `startAtId` parameter.
    Traversal will explore all the levels of the `uses` hierarchy in this case.
    """

    start_at_id: ID = NOT_SET
    depth: Optional[Int]= NOT_SET
    direction: Optional[TraverseDirectionEnum]= NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['AssetVersionsByTraversalInput']]= 'AssetVersionsByTraversalInput'  # type: ignore[assignment]


@dataclass
class AssetsByProjectIdInput(Base):
    """
    Input parameters for the `assetsByProjectId` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "projectId": "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags",
      "filters": {
        "has.component.type": { $eq: "autodesk.me:components.cameraMetadata-1.0.0" },
        "attribute.deletionState": { $eq: "NOT_DELETED" },
        "components[typeId:autodesk.me:components.cameraMetadata-1.0.0].data.camera": { $eq: "Sony A7R IV" }
      },
      "sort": {
        "field": "created.date",
        "order": "DESC"
      }
    }
    ```

    The query above will:
      * Fetch assets from the project with the ID `urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags` (Provided the user has access to it);
      * Pick only assets that have a component with the type `autodesk.me:components.cameraMetadata-1.0.0`;
      * Pick only assets that are not soft deleted;
      * Filter out the assets whose `components[typeId:autodesk.me:components.cameraMetadata-1.0.0].data.camera` field is not `Sony A7R IV`;
      * Sort the assets by the creation date in descending order.
    """

    project_id: ID = NOT_SET
    filters: Optional[Filters]= NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    sort: Optional[SortInput]= NOT_SET
    typename__: Optional[Literal['AssetsByProjectIdInput']]= 'AssetsByProjectIdInput'  # type: ignore[assignment]


@dataclass
class AssetsBySearchInput(Base):
    """
    Input parameters for the `assetsBySearch` query.

    #### ────────────────────────────

    **Example 1: Search for assets by name with sorting:**
    ```json
    {
      "projectIds": ["urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags"],
      "filter": "attribute.name==SHOT_001",
      "sort": [
        {"field": "attribute.createdOn", "order": "ASC" },
      ],
      "pagination": { "limit": 10 }
    }
    ```

    The example above will return the oldest created assets whose name is `"SHOT_001"`.

    #### ────────────────────────────

    **Example 2: Search for assets by description using the fuzzy search operator:**
    ```json
    {
      "projectIds": ["urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags"],
      "filter": "attribute.description=search='Created in Maya'",
    }
    ```

    This query will return the assets whose description contains the string `"Created in Maya"`.

    #### ────────────────────────────

    **Example 3: Search for assets by the component data:**
    ```json
    {
      "projectIds": ["urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags"],
      "filter": "components[autodesk.me:components.cameraMetadata-1.0.0].camera==3D Camera",
    }
    ```

    This query will search for the assets that have the `autodesk.me:components.cameraMetadata-1.0.0` component with the `camera` field set to `3D Camera`.

    #### ────────────────────────────

    **Example 4: Search for assets by the component data using the fuzzy search operator:**
    ```json
    {
      "projectIds": ["urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags"],
      "filter": "components[autodesk.me:components.cameraMetadata-1.0.0].camera=='3D Camera'",
    }
    ```

    #### ────────────────────────────

    **Example 5: Using multiple conditions:**

    ```json
    {
      "projectIds": ["urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDjg_ags"],
      "filter": "attribute.name=='SHOT_001' AND components[autodesk.me:components.cameraMetadata-1.0.0].camera=startswith='3D Camera'",
    }
    ```
    """

    filter: Filters = NOT_SET
    project_ids: list[ID] = NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    sort: Optional[list[SortInput]]= NOT_SET
    typename__: Optional[Literal['AssetsBySearchInput']]= 'AssetsBySearchInput'  # type: ignore[assignment]


@dataclass
class AssetsByTraversalInput(Base):
    """
    `assetsByTraversal` query input parameters that are used to traverse the `contains` relationships between assets.

    #### ────────────────────────────

    **Example: Traverse the immediate nodes (assets) from the given project ID**
    ```json
    {
      "startAtId": "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDj9g_ags",
      "depth": 1,
      "direction": "OUTGOING"
    }
    ```
    """

    start_at_id: ID = NOT_SET
    depth: Optional[Int]= NOT_SET
    direction: Optional[TraverseDirectionEnum]= NOT_SET
    filters: Optional[Filters]= NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['AssetsByTraversalInput']]= 'AssetsByTraversalInput'  # type: ignore[assignment]


@dataclass
class AsyncJobsByAssetRevisionIdsInput(Base):
    """
    Input parameters for the `asyncJobsByAssetRevisionIds` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "assetRevisionIds": ["urn:medm:assetRevision:JQbdxs17yBArQ23EbI3psK_L2C:GeWJet2dJeHeaIWyelpROg_ags:PgL98oXeAUdC4puhUXGg0c_mea:rev:2"]
    }
    ```
    """

    asset_revision_ids: list[ID] = NOT_SET
    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['AsyncJobsByAssetRevisionIdsInput']]= 'AsyncJobsByAssetRevisionIdsInput'  # type: ignore[assignment]


@dataclass
class CollectionsInput(Base):
    """
    Input parameters for the `collections` query.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "pagination": { "limit": 10 }
    }
    ```
    """

    pagination: Optional[PaginationInput]= NOT_SET
    typename__: Optional[Literal['CollectionsInput']]= 'CollectionsInput'  # type: ignore[assignment]


@dataclass
class CreateAssetInput(Base):
    """
    Input parameters for the `createAsset` mutation. This will instruct MEDM Server to create a new MEDM Asset and place it
    in the specified place in the asset graph.

    By default each asset is created with a single revision, a single numbered version and a single named version (i.e., 'latest').

    #### ────────────────────────────

    **References:**
     Before creating assets, it is recommended to familiarize yourself with the M&E data model. Please refer to the following type declarationts:
       - `Project`;
       - `Asset`;
       - `NumberedAssetVersion`;
       - `NamedAssetVersion`;
       - `AssetRevision`.

    #### ────────────────────────────

    **Example 1: Asset with a single component**
    ```json
    {
      "name": "Spaceship texture",
      "description": "A set of shaders and textures for the Spaceship",
      "parentId": "urn:medm:asset:xtLamgbDTWb5fpoIQE4IV8_L2C:HmIvdp43Tta74T3dylklbe_ags:izg4Yd018Nhd2qk1jQSc92_mea",
      "components": [
        {
          "name": "main_camera",
          "typeId": "autodesk.me:components.cameraMetadata-1.0.0",
          "data": {
            "camera": "3D Camera"
          }
        }
      ]
    }
    ```
    A trivial asset creation where a brand new asset is created under the specified parent asset and has a single component.

    #### ────────────────────────────

    **Example 2: Creating a new asset with a binary component (Media Duplication)**

    ```json
    {
      "name": "Spaceship render",
      "parentId": "urn:medm:asset:xtLamgbDTWb5fpoIQE4IV8_L2C:HmIvdp43Tta74T3dylklbe_ags:izg4Yd018Nhd2qk1jQSc92_mea",
      "components": [
        {
          "name": "Spaceship_render",
          "typeId": "autodesk.me:component.binary.video-1.0.0"
          "data": {
            "data": [
              {
                "uri": "https://d1dgv2k5zpmitw.cloudfront.net/dsc-data/135658-764361528_tiny.mp4",
                "mimeType": "video/mp4",
                "path": "Spaceship.mp4"
              }
            ],
            "purpose": "thumbnail"
          },
        }
      ]
    }
    ```

    The example above creates a brand new asset under the specified parent asset, and that will also trigger
    an upload of the binary media file to the remote binary storage.

    **Important binary components note:**
    Any component that inherits from the `autodesk.me:component.binary-1.0.0` schema will trigger an upload of the binary media
    file to the remote binary storage. Some examples of binary components are:
    - `autodesk.me:component.binary.video-1.0.0`;
    - `autodesk.me:component.binary.image-1.0.0`;
    - `autodesk.me:component.binary.imageSequence-1.0.0`;
    - `autodesk.me:component.binary-1.0.0` (The super-type itself does trigger uploads as well).

    The `components` array might have more than one binary component with multiple binary blobs attached to it.

    Explore the Autodesk Schema [Registry](https://schema.autodesk.com/organization/autodesk/group/flowData) to
    learn more about the available binary component types.

    #### ────────────────────────────

    **Example 3: Creating a new asset with a binary component (Web-upload mechanism)**

    ```json
    {
      "name": "Spaceship logo",
      "parentId": "urn:medm:asset:xtLamgbDTWb5fpoIQE4IV8_L2C:HmIvdp43Tta74T3dylklbe_ags:izg4Yd018Nhd2qk1jQSc92_mea",
      "components": [
        {
          "name": "spaceship_logo",
          "data": {
              "data": [
                  {
                      "uri": "upload://f5b496a6-5fc0-498a-bbd7-0349485fd243",
                      "mimeType": "image/png",
                      "path": "spaceship.png"
                  }
              ],
              "purpose": "thumbnail"
          },
          "typeId": "autodesk.me:component.binary-1.0.0"
        }
      ]
    }
    ```

    The example above creates a brand new asset under the specified parent asset. This will _not_ trigger any upload proccess
    right away. However, the user will be able to utilize the specified `URI` to initiate the manual upload process.

    See the Web-upload APIs documentation for more details:
     * `openUploadFile` mutation;
     * `getUploadFilePart` mutation;
     * `closeUploadFile` mutation.

    It is expected that the user will store the initial value of the `uri` field.

    #### ────────────────────────────

    **Example 4: Creating a new asset with `uses` relationships**

    ```json
    {
      "name": "Spaceship model",
      "parentId": "urn:medm:asset:xtLamgbDTWb5fpoIQE4IV8_L2C:HmIvdp43Tta74T3dylklbe_ags:izg4Yd018Nhd2qk1jQSc92_mea",
      "uses": [
        {
          `// Suppose it's an version ID of the 'Spaceship_wing' asset`
          "toVersionId": "urn:medm:assetVersion:yn2F9RNBjaBmuXqyyhcHra_L2C:q8h7X8ALWhjr7Aj64HeiWm_ags:uOlLknggmDc62LqViH3wa7_mea:ver:7",
        }
      ]
    }
    ```

    Below is a diagram illustrating Example 4:

    ```
    ┌──────────────────────────────────────────────────────────────┐
    │                      Spaceship Model Asset                   │
    │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐│
    │  │  Latest  │ ──────────▶ │   V1     │ ──────────▶ │  R1    ││
    │  └──────────┘             └──────────┘             └────────┘│
    │                                                         |    │
    └─────────────────────────────────────────────────────────│────┘
                                                             uses
                                                              │
                                                              ▼
                            ┌──────────────────────────────────────────────────────────────┐
                            │                     Spaceship Wing Asset                     │
                            │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐│
                            │  │  Latest  │ ──────────▶ │   V7     │ ──────────▶ │  R10   ││
                            │  └──────────┘             └──────────┘             └────────┘│
                            └──────────────────────────────────────────────────────────────┘
    ```

    **Legend:**
    - Each large box represents an asset ("Spaceship Model" or "Spaceship Wing").
    - Inside each asset box, horizontal boxes represent versions and revisions: `Latest` named version, numbered version, revision. = NOT_SET
    - Arrows labeled "linksTo" describes the internal relationships between versions and revisions;
    - The "uses" arrow from "Spaceship Model" R1 to "Spaceship Wing" V7 create a dependency relationship between these two assets.

    See the `assetsByTraversal` query to learn more about the `uses` relationships and see more examples.
    """

    name: String = NOT_SET
    parent_id: ID = NOT_SET
    components: Optional[list[ComponentDataInput]]= NOT_SET
    context: Optional[JSONObject]= NOT_SET
    description: Optional[String]= NOT_SET
    uses: Optional[list[UsesTargetInput]]= NOT_SET
    typename__: Optional[Literal['CreateAssetInput']]= 'CreateAssetInput'  # type: ignore[assignment]


@dataclass
class CreateSchemaDisplayDataInput(Base):
    """
    Input parameters for the `createSchemaDisplayData` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "schemaTypeId": "autodesk.me:person-1.0.0",
      "displayName": "Person",
      "propertiesDisplayData": [
        {
          "propertyId": "name",
          "displayName": "Name"
        }
      ]
    }
    ```
    """

    schema_type_id: SchemaTypeId = NOT_SET
    display_name: Optional[String]= NOT_SET
    properties_display_data: Optional[list[PropertyDisplayDataInput]]= NOT_SET
    typename__: Optional[Literal['CreateSchemaDisplayDataInput']]= 'CreateSchemaDisplayDataInput'  # type: ignore[assignment]


@dataclass
class PropertiesDefinitionInput(Base):
    """
    Supplementary input parameters that are used to describe the properties of a new schema. See the `createSchema` mutation for more details.
    Additionally, consult the Autodesk Schema Service [site](https://schema.autodesk.com/organization/autodesk/group/flowData) to explore the available properties and their data shapes.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "name": "name",
      "type": {
        "primitiveType": "String"
      }
    }
    ```
    """

    name: String = NOT_SET
    context: Optional[String]= NOT_SET
    length: Optional[Int]= NOT_SET
    properties: Optional[list[Optional[PropertiesDefinitionInput]]]= NOT_SET
    type: Optional[PropertyTypeInput]= NOT_SET
    value: Optional[JSONObject]= NOT_SET
    typename__: Optional[Literal['PropertiesDefinitionInput']]= 'PropertiesDefinitionInput'  # type: ignore[assignment]


@dataclass
class UpdateAssetInput(Base):
    """
    Input parameters for the `updateAsset` mutation.

    #### ────────────────────────────

    **References:**
     - See the `Asset` type to learn more about the M&E asset composition and the complete data model;
     - See the `createAsset` mutation to learn more about the asset creation process.

    #### ────────────────────────────

    **Technical details:**
     - Each successful update operation will create a new asset revision;
     - MEDM will automatically copy the values from the previous revision if the field is not provided in the input payload.
       Data that is copied over is:
        * `name`;
        * `description`;
        * `components`;
        * `uses` relationships.

    #### ────────────────────────────

    **Example 1: Update the name and description of an asset**
    ```json
    {
      "id": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea",
      "name": "3D model of Spaceship",
      "description": "A 3D model of Spaceship built in Blender",
    }
    ```
    #### ────────────────────────────

    **Example 2: Add a binary component to an asset and kick off the binary upload process**
    ```json
    {
      "id": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea",
      "componentsAction": "add",
      "components": [
        {
          "name": "spaceship_logo",
          "typeId": "autodesk.me:component.binary-1.0.0"
          "data": {
            "data": [
              {
                "uri": "https://d1dgv2k5zpmitw.cloudfront.net/dsc-data/135658-764361528_tiny.mp4",
                "mimeType": "video/mp4",
                "path": "spaceship.mp4"
              }
            ],
            "purpose": "thumbnail"
          },
        }
      ],
    }
    ```

    #### ────────────────────────────

    **Example 3: Add a binary component to an asset and initiate the web-upload process**

    ```json
    {
      "id": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea",
      "componentsAction": "add",
      "components": [
        {
          "name": "spaceship_logo",
          "typeId": "autodesk.me:component.binary-1.0.0",
          "data": {
            "data": [
              {
                "uri": "upload://f5b496a6-5fc0-498a-bbd7-0349485fd243",
                "mimeType": "image/png",
                "path": "spaceship.png"
              }
            ],
        }
      ],
    }
    ```
    #### ────────────────────────────

    **Example 4: Update the asset and add a `uses` relationship to it**
    ```json
    {
      "id": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea",
      "uses": [
        {
          "toVersionId": "urn:medm:assetVersion:yn2F9RNBjaBmuXqyyhcHra_L2C:q8h7X8ALWhjr7Aj64HeiWm_ags:uOlLknggmDc62LqViH3wa7_mea:ver:7",
        }
      ]
    }
    ```

    **Visual representation of Example 4:**

    Before the update:
    ```
    ┌──────────────────────────────────────────────────────────────┐
    │                      Spaceship Model Asset                   │
    │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐│
    │  │  Latest  │ ──────────▶ │   V1     │ ──────────▶ │  R1    ││
    │  └──────────┘             └──────────┘             └────────┘│
    │                                                              │
    └──────────────────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────────────────┐
    │                     Spaceship Wing Asset                     │
    │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐│
    │  │  Latest  │ ──────────▶ │   V7     │ ──────────▶ │  R10   ││
    │  └──────────┘             └──────────┘             └────────┘│
    └──────────────────────────────────────────────────────────────┘
    ```

    After the update:
    ```
    ┌──────────────────────────────────────────────────────────────┐
    │                      Spaceship Model Asset                   │
    |                                                              │
    |                                                    ┌────────┐│
    |                                                    │  R1    ││
    |                                                    └────────┘│
    |                                                              |
    │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐│
    │  │  Latest  │ ──────────▶ │   V1     │ ──────────▶ │  R2    ││
    │  └──────────┘             └──────────┘             └────────┘│
    │                                                         │    │
    └─────────────────────────────────────────────────────────┘────┘
                                                              │
                                                             uses
                                                              │
                                                              ▼
                            ┌──────────────────────────────────────────────────────────────┐
                            │                     Spaceship Wing Asset                     │
                            │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐│
                            │  │  Latest  │ ──────────▶ │   V7     │ ──────────▶ │  R10   ││
                            │  └──────────┘             └──────────┘             └────────┘│
                            └──────────────────────────────────────────────────────────────┘
    ```

    #### ────────────────────────────

    **Example 5: Versioning strategy — Creating a new revision & relinking**

    ```json
    {
      "id": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea",
      "namedVersionChange": "UPDATE_LATEST",
    }
    ```

    The default versioning strategy is `UPDATE_LATEST`. That means that upon succesful update operation, MEDM Server will
    create a new revision and repoint the largest (latest) numbered version to the newly generated revision.

    **Visualisation**

    **Before the update:**
    ```
    ┌──────────────────────────────────────────────────────────────┐
    │                      Spaceship Model Asset                   │
    │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐│
    │  │  Latest  │ ──────────▶ │   V1     │ ──────────▶ │  R1    ││
    │  └──────────┘             └──────────┘             └────────┘│
    │                                                              │
    └──────────────────────────────────────────────────────────────┘
    ```

    **After the update:**
    ```
    ┌────────────────────────────────────────────────────────────────┐
    │                      Spaceship Model Asset                     │
    |                                                                │
    |                                                    ┌────────┐  │
    |                                                    │  R1    │  │
    |                                                    └────────┘  │
    |                                                                |
    │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐  │
    │  │  Latest  │ ──────────▶ │   V1     │ ──────────▶ │  R2    │  │
    │  └──────────┘             └──────────┘             └────────┘  │
    |                                                                │
    └────────────────────────────────────────────────────────────────┘
    ```

    `R2` in this case is the newly generated revision. Please note:
     - `V1` is now pointing to `R2`;
     - `R1` still exists, but is no longer the latest revision and it is not associated with any version.

    #### ────────────────────────────

    **Example 6: Versioning strategy — Creating a new numbered version & revision**

    ```json
     {
      "id": "urn:medm:asset:dKFvEv3CIH1mKyuz4bsxfq_L2C:OsZqqbZBN2b1jiqgFtsddq_ags:pAlcntaU0ST69Su0Xv0R27_mea",
      "namedVersionChange": "CREATE_NEW",
    }
    ```

    The `CREATE_NEW` strategy will tell MEDM Server to create a new numbered version and revision. Upon the
    version creation, MEDM Server will also relink the 'latest' named version to the newly created numbered version.

    **Visualisation**

    **Before the update:**
    ```
    ┌──────────────────────────────────────────────────────────────┐
    │                      Spaceship Model Asset                   │
    │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐│
    │  │  Latest  │ ──────────▶ │   V1     │ ──────────▶ │  R1    ││
    │  └──────────┘             └──────────┘             └────────┘│
    │                                                              │
    └──────────────────────────────────────────────────────────────┘
    ```

    **After the update:**
    ```
    ┌────────────────────────────────────────────────────────────────┐
    │                      Spaceship Model Asset                     │
    |                                                                │
    |                           ┌──────────┐   linksTo   ┌────────┐  |
    |                           │   V1     │ ──────────▶ │  R1    │  |
    |                           └──────────┘             └────────┘  |
    |                                                                |
    │  ┌──────────┐   linksTo   ┌──────────┐   linksTo   ┌────────┐  │
    │  │  Latest  │ ──────────▶ │   V2     │ ──────────▶ │  R2    │  │
    │  └──────────┘             └──────────┘             └────────┘  │
    |                                                                |
    └────────────────────────────────────────────────────────────────┘
    ```
    """

    id: ID = NOT_SET
    components: Optional[list[ComponentDataInput]]= NOT_SET
    components_action: Optional[ListAction]= NOT_SET
    context: Optional[JSONObject]= NOT_SET
    description: Optional[String]= NOT_SET
    name: Optional[String]= NOT_SET
    named_version_change: Optional[NamedVersionChangeEnum]= NOT_SET
    update_condition: Optional[UpdateAssetConditionInput]= NOT_SET
    uses: Optional[list[UsesTargetInput]]= NOT_SET
    typename__: Optional[Literal['UpdateAssetInput']]= 'UpdateAssetInput'  # type: ignore[assignment]


@dataclass
class AssetVersion(Base):
    """
    An interface describing the common fields for the asset versions.
    """

    asset_id: ID = NOT_SET
    created: AuditLog = NOT_SET
    id: ID = NOT_SET
    modified: AuditLog = NOT_SET
    project_id: ID = NOT_SET
    typename__: Optional[Literal['AssetVersion']]= 'AssetVersion'  # type: ignore[assignment]


@dataclass
class ActivateProductJob(AsyncJob):
    """
    Internal only.
    """

    description: String = NOT_SET
    id: ID = NOT_SET
    state: String = NOT_SET
    updated_on: DateTime = NOT_SET
    created_on: DateTime = NOT_SET
    collection: Optional[Collection]= NOT_SET
    typename__: Optional[Literal['ActivateProductJob']]= 'ActivateProductJob'  # type: ignore[assignment]


@dataclass
class AddUserByEmailToCollectionResponse(Base):
    """
    Represents a success response from the `addUserByEmailToCollection` mutation.
    """

    job: AddUserJob = NOT_SET
    typename__: Optional[Literal['AddUserByEmailToCollectionResponse']]= 'AddUserByEmailToCollectionResponse'  # type: ignore[assignment]


@dataclass
class AddUserByEmailToProjectResponse(Base):
    """
    Represents a success response from the `addUserByEmailToProject` mutation.
    """

    job: AddUserJob = NOT_SET
    typename__: Optional[Literal['AddUserByEmailToProjectResponse']]= 'AddUserByEmailToProjectResponse'  # type: ignore[assignment]


@dataclass
class Asset(Base):
    """
    Type representing a Media and Entertainment asset. MEDM asset is a the central building block in the Media and Entertainment
    domain that allows to model different types of VFX data and workflows. Some of the asset types are:
    - Shot
    - Sequence
    - Frame
    - Cut
    - Folder
    - And many more...

    #### ────────────────────────────

    **Properties:**
     - Each asset represents a node in the project asset graph. It may have 0-N child assets connected via the
       `contains` relationships.
     - Some assets may have binary components (the components of type `autodesk.me:component.binary`). Those
      components describe the metadata of the binary files that were uploaded to the remote binary storage;
     - Each M&E asset has type of `autodesk.me:asset` (or inheriting from it).

    #### ────────────────────────────

    **Deep dive:**

    Apart from the components and `contains` relationships, a M&E asset also encompasses revision and versions.

    Schematically, the asset composition can be represented as follows:

    ```
    ┌─────────────────────────────┐
    │         Shot_001            │
    │                             │
    │    ┌───────┐  LinksTo  ┌────────────┐
    │    │  V1   │──────────▶│ Revision 1 │
    │    └───────┘           └────────────┘
    │                             │
    │    ┌───────┐  LinksTo  ┌────────────┐
    │    │  V2   │──────────▶│ Revision 2 │
    │    └───────┘           └────────────┘
    │                             │
    │    ┌───────┐  LinksTo  ┌────────────┐
    │    │  V3   │──────────▶│ Revision 3 │
    │    └───────┘           └────────────┘
    │       ▲                     |
    │       │                     |
    │   ┌────────┐                |
    │   │ latest │                |
    │   └────────┘                |
    └─────────────────────────────┘
    ```
    To clarify:

    - `Shot_001` is a MEDM asset representing a shot, which currently has 5 revisions and 3 versions.
    - When a read API is used to retrieve `Shot_001`, the MEDM Server will provide data from the asset’s latest revision/version.
    - This means that, in addition to being a container for revisions and versions, the asset itself also acts as a pointer to its most
    recent revision.

    #### ────────────────────────────

    **Version & Revision management:**
      - When created, the asset has at least one revision, one numbered version and one named version; See the `AssetRevision`,
        `NumberedAssetVersion` and `NamedAssetVersion` types to learn more about these types and how they behave;
      - Subsequently, any update made to the asset will create a new revision and (if instructed) a new numbered version;
        named version will be repointed by the MEDM Server automatically.
    """

    asset_type_ids: list[SchemaTypeId] = NOT_SET
    created: AuditLog = NOT_SET
    deletion_state: AssetDeletionState = NOT_SET
    has_children: Boolean = NOT_SET
    id: ID = NOT_SET
    modified: AuditLog = NOT_SET
    name: String = NOT_SET
    numbered_version_id: ID = NOT_SET
    parent_id: ID = NOT_SET
    project_id: ID = NOT_SET
    revision_id: ID = NOT_SET
    revision_number: Int = NOT_SET
    version_number: Int = NOT_SET
    components: Optional[list[ComponentData]]= NOT_SET
    description: Optional[String]= NOT_SET
    publish_transfer_status: Optional[PublishTransferStatus]= NOT_SET
    typename__: Optional[Literal['Asset']]= 'Asset'  # type: ignore[assignment]


@dataclass
class AssetRevision(Base):
    """
    A type representing M&E asset revision. In nutshell, asset revision is a snapshot of an asset at a specific point in time.

    Each asset has at least one revision, and after each successful asset update, MEDM Server will create a new revision, forming
    an append-only immutable revision stream.

    #### ────────────────────────────

    **References:**
     - See the `NumberedAssetVersion` type to learn more about how a revision is associated with a numbered version;
     - See the `Asset` type to learn more about the M&E asset composition and the complete data model;

    #### ────────────────────────────

    **Example:**
    ```
    +------------------------------------------------------------------------------------+
    |                                                                                    |
    |                              Spaceship_model (asset)                               |
    |____________________________________________________________________________________|
    |                                      |                                             |
    |                                 Revision 1                                         |
    |                            (Initial revision)                                      |
    |                                      |                                             |
    |                                      |                                             |
    |                                 Revision 2                                         |
    |                        (add: binary_component_1)                                   |
    |                                      |                                             |
    |                                      |                                             |
    |                                 Revision 3                                         |
    |             (Rename asset name to "Spaceship_model_final")                              |
    |                                      |                                             |
    |                                      |                                             |
    |                                     ...                                            |
    |                                      |                                             |
    |                                 Revision N                                         |
    |          (Latest revision, containing the final state of the asset)                |
    |                                                                                    |
    +------------------------------------------------------------------------------------+
    ```
    #### ────────────────────────────

    **Deep dive:**

    As of now, not all the asset updates are revisioned. The following operations will generate a new revision:
     - Asset name change
     - Asset description change
     - Asset component addition
     - Asset component updating/replacing
     - Asset component removal
     - `uses` relationship creation/updating

    Operations that do *NOT* create a new revision:
     - Asset reparenting

    #### ────────────────────────────

    When the `uses` relationships are created, they always flow from the asset revision to version(s). This means that the
    """

    asset_id: ID = NOT_SET
    asset_type_ids: list[SchemaTypeId] = NOT_SET
    created: AuditLog = NOT_SET
    id: ID = NOT_SET
    is_latest: Boolean = NOT_SET
    modified: AuditLog = NOT_SET
    name: String = NOT_SET
    project_id: ID = NOT_SET
    publish_transfer_status: PublishTransferStatus = NOT_SET
    revision_number: Int = NOT_SET
    components: Optional[list[ComponentData]]= NOT_SET
    description: Optional[String]= NOT_SET
    numbered_version_id: Optional[ID]= NOT_SET
    version_number: Optional[Int]= NOT_SET
    typename__: Optional[Literal['AssetRevision']]= 'AssetRevision'  # type: ignore[assignment]


@dataclass
class AssetRevisionsByAssetIdResponse(Base):
    """
    Represents a success response from the `assetRevisionsByAssetId` query.
    """

    asset_revisions: list[AssetRevision] = NOT_SET
    pagination: PaginationStandard = NOT_SET
    typename__: Optional[Literal['AssetRevisionsByAssetIdResponse']]= 'AssetRevisionsByAssetIdResponse'  # type: ignore[assignment]


@dataclass
class AssetRevisionsByIdsResponse(Base):
    """
    Represents a success response from the `assetRevisionsByIds` query.
    """

    revisions: list[AssetRevision] = NOT_SET
    typename__: Optional[Literal['AssetRevisionsByIdsResponse']]= 'AssetRevisionsByIdsResponse'  # type: ignore[assignment]


@dataclass
class AssetVersionsByAssetIdResponse(Base):
    """
    A Represents a success response from the `assetVersionsByAssetId` query.
    """

    asset_versions: list[Union[NamedAssetVersion, NumberedAssetVersion]]= NOT_SET
    pagination: PaginationStandard = NOT_SET
    typename__: Optional[Literal['AssetVersionsByAssetIdResponse']]= 'AssetVersionsByAssetIdResponse'  # type: ignore[assignment]


@dataclass
class AssetVersionsByIdsResponse(Base):
    """
    A Represents a success response from the `assetVersionsByIds` query.
    """

    versions: list[Union[NamedAssetVersion, NumberedAssetVersion]]= NOT_SET
    typename__: Optional[Literal['AssetVersionsByIdsResponse']]= 'AssetVersionsByIdsResponse'  # type: ignore[assignment]


@dataclass
class AssetVersionsByTraversalResponse(Base):
    """
    Represents a success response from the `assetVersionsByTraversal` query.

    #### ────────────────────────────

    **Visual representation:**

    Suppose we have the following `uses` graph:
    ```
    ┌─────────────────────────────────────────┐           ┌─────────────────────────────────────────┐
    │ Scene                                   │           │ Spaceship                               │
    │                                         │           │                                         │
    │ ┌────────┐    ┌────────┐    ┌────────┐  │           │ ┌────────┐    ┌────────┐    ┌────────┐  │
    │ │ Latest │───>│   V1   │───>│  Rev1  │-─┼─── Uses ──┼>│ Latest │───>│   V1   │───>│  Rev1  │  │
    │ └────────┘    └────────┘    └────────┘  │           │ └────────┘    └────────┘    └───┬────┘  │
    │                                         │           │                                 │       │
    └─────────────────────────────────────────┘           └─────────────────────────────────┼───────┘
                                                                                            │
                                                                                            │ Uses
                                                                                            │
                                                                        ┌───────────────────│─────────────────────┐
                                                                        │ Spaceship Wing    │                     │
                                                                        │                   ▼                     │
                                                                        │ ┌────────┐    ┌────────┐    ┌────────┐  │
                                                                        │ │ Latest │───>│   V1   │───>│  Rev1  │  │
                                                                        │ └────────┘    └────────┘    └────────┘  │
                                                                        │                                         │
                                                                        └─────────────────────────────────────────┘
    ```

    If if you start at `Scene.latest` and traverse outgoing links with depth `0`, you will get the following result:

    #### ────────────────────────────

    ```
    {
      "edges": [
        {
          "fromId": "Scene.Rev1.id",
          "toId": "Spaceship.latest.id"
        },
        {
          "fromId": "Spaceship.Rev1.id",
          "toId": "Spaceship_wing.V1.id"
        }
      ],
      "versions": [
        "Scene.latest",
        "Spaceship.latest",
        "Spaceship.V1"
      ],
      "revisions": [
        "Spaceship.Rev1",
        "Scene.Rev1"
      ],
      "pagination": {
        "pageSize": 2,
        "cursor": null
      }
    }
    ```

    #### ────────────────────────────

    And the similar traversal can be done in the opposite site: Input parameters: = NOT_SET
    ```json
    {
      "startAtId": "Spaceship.V1.id",
      "direction": "INCOMING",
      "depth": 0
    }
    ```

    That will yield the following result:

    #### ────────────────────────────

    ```json
    {
      "edges": [
        {
          "fromId": "Scene.Rev1.id",
          "toId": "Spaceship.latest.id"
        },
      ],
      "versions": [
        "Spaceship.latest",
        "Scene.latest"
      ],
      "revisions": [
        "Scene.Rev1"
      ],
      "pagination": {
        "pageSize": 2,
        "cursor": null
      }
    }
    ```
    """

    edges: list[AssetVersionTraversalEdge] = NOT_SET
    pagination: PaginationStandard = NOT_SET
    revisions: list[AssetRevision] = NOT_SET
    versions: list[Union[NamedAssetVersion, NumberedAssetVersion]]= NOT_SET
    typename__: Optional[Literal['AssetVersionsByTraversalResponse']]= 'AssetVersionsByTraversalResponse'  # type: ignore[assignment]


@dataclass
class AssetsByIdsResponse(Base):
    """
    Represents a success response from the `assetsByIds` query.
    """

    assets: list[Asset] = NOT_SET
    typename__: Optional[Literal['AssetsByIdsResponse']]= 'AssetsByIdsResponse'  # type: ignore[assignment]


@dataclass
class AssetsByProjectIdResponse(Base):
    """
    Represents a success response from the `assetsByProjectId` query.
    """

    assets: list[Asset] = NOT_SET
    pagination: PaginationStandard = NOT_SET
    typename__: Optional[Literal['AssetsByProjectIdResponse']]= 'AssetsByProjectIdResponse'  # type: ignore[assignment]


@dataclass
class AssetsBySearchResponse(Base):
    """
    Represents a success response from the `assetsBySearch` query.
    """

    pagination: PaginationStandard = NOT_SET
    results: list[Asset] = NOT_SET
    total_results: Int = NOT_SET
    typename__: Optional[Literal['AssetsBySearchResponse']]= 'AssetsBySearchResponse'  # type: ignore[assignment]


@dataclass
class AssetsByTraversalResponse(Base):
    """
    A Represents a success response from the `assetsByTraversal` query.

    #### ────────────────────────────

    Suppose we have the following asset graph:

    ```
                            ┌─────────────────────┐
                            │                     │
                            │    Spaceships       │
                            │     (project)       │
                            │                     │
                            └──────────┬──────────┘
                                       │
               ┌───────────────────────┼───────────────────────┐
               │                       │                       │
            Contains                Contains                Contains
               │                       │                       │
               ▼                       ▼                       ▼
        ┌─────────────┐        ┌─────────────┐        ┌─────────────┐
        │             │        │             │        │             │
        │   Model_1   │        │   Model_2   │        │   Model_3   │
        │             │        │             │        │             │
        └──────┬──────┘        └──────┬──────┘        └──────┬──────┘
               │                      │                      │
         ┌─────┴─────┐          ┌─────┴─────┐          ┌─────┴─────┐
         │           │          │           │          │           │
      Contains    Contains   Contains    Contains   Contains    Contains
         │           │          │           │          │           │
         ▼           ▼          ▼           ▼          ▼           ▼
    ┌──────────┐ ┌──────────┐ ┌─────────┐ ┌────────┐ ┌─────────┐ ┌────────┐
    │          │ │          │ │         │ │        │ │         │ │        │
    │ Shader_1 │ │ Shader_2 │ │ Previz  │ │ Sound  │ │ Texture │ │  Rig   │
    │          │ │          │ │         │ │        │ │         │ │        │
    └──────────┘ └──────────┘ └─────────┘ └────────┘ └─────────┘ └────────┘
    ```

    Using this graph, we can run various traversals.

    #### ────────────────────────────

    #### Example 1: First-level traversal

    **Input parameters:**
    ```
    {
      "input": {
        "startAtId": Spaceships.id,
        "depth": 1,
        "direction": "OUTGOING"
      }
    }
    ```

    **Response:**
    ```
    {
      "assetsByTraversal": {
        "edges": [
          {
            "fromId": Spaceships.id,
            "toId": Model_1.id
          },
          {
            "fromId": Spaceships.id,
            "toId": Model_2.id
          },
          {
            "fromId": Spaceships.id,
            "toId": Model_3.id
          }
        ],
        "project": Spaceships,
        "assets": [Model_1, Model_2, Model_3],
        "pagination": {
          "cursor": null,
          "pageSize": 3
        }
      }
    }
    ```

    #### ────────────────────────────

    #### Example 2: Traverse all the nodes (assets) from the given project ID

    **Input parameters:**
    ```
    {
      "input": {
        "startAtId": Spaceships.id,
        "depth": 0,
        "direction": "OUTGOING"
      }
    }
    ```

    **Response:**
    ```
    {
      "assetsByTraversal": {
        "edges": [
          {
            "fromId": Spaceships.id,
            "toId": Model_1.id
          },
          {
            "fromId": Spaceships.id,
            "toId": Model_2.id
          },
          {
            "fromId": Spaceships.id,
            "toId": Model_3.id
          },
          {
            "fromId": Model_1.id,
            "toId": Shader_1.id
          },
          {
            "fromId": Model_1.id,
            "toId": Shader_2.id
          },
          {
            "fromId": Model_2.id,
            "toId": Previz.id
          },
          {
            "fromId": Model_2.id,
            "toId": Sound.id
          },
          {
            "fromId": Model_3.id,
            "toId": Texture.id
          },
          {
            "fromId": Model_3.id,
            "toId": Rig.id
          }
        ],
        "project": Spaceships,
        "assets": [Model_1, Model_2, Model_3, Shader_1, Shader_2, Previz, Animation, Texture, Rig],
        "pagination": {
          "cursor": null,
          "pageSize": 9
        }
      }
    }
    ```

    #### ────────────────────────────

    #### Example 3: Asset's path
    **Input parameters:**
    ```
    {
      "input": {
        "startAtId": Shader_1.id,
        "depth": 0,
        "direction": "INCOMING"
      }
    }
    ```

    **Response:**
    ```
    {
      "assetsByTraversal": {
        "edges": [
          {
            "fromId": Spaceships.id,
            "toId": Model_1.id
          },
          {
            "fromId": Model_1.id,
            "toId": Shader_1.id
          },
        ],
        "project": Spaceships,
        "assets": [Model_1, Shader_1],
        "pagination": {
          "cursor": null,
          "pageSize": 2
        }
      }
    }
    ```

    In the bottom-up traversal, the `edges` list will always be sorted from project to asset.
    """

    assets: list[Asset] = NOT_SET
    edges: list[AssetsByTraversalEdge] = NOT_SET
    pagination: PaginationStandard = NOT_SET
    project: Optional[Project]= NOT_SET
    typename__: Optional[Literal['AssetsByTraversalResponse']]= 'AssetsByTraversalResponse'  # type: ignore[assignment]


@dataclass
class CreateAssetResponse(Base):
    """
    Represents a success response from the `createAsset` mutation.
    """

    asset: Asset = NOT_SET
    typename__: Optional[Literal['CreateAssetResponse']]= 'CreateAssetResponse'  # type: ignore[assignment]


@dataclass
class CreateProjectJob(AsyncJob):
    """
    An asynchronous job that monitors the MEDM project creation process.
    """

    description: String = NOT_SET
    id: ID = NOT_SET
    state: String = NOT_SET
    updated_on: DateTime = NOT_SET
    created_on: DateTime = NOT_SET
    project: Optional[Project]= NOT_SET
    typename__: Optional[Literal['CreateProjectJob']]= 'CreateProjectJob'  # type: ignore[assignment]


@dataclass
class CreateProjectResponse(Base):
    """
    Represents a success response from the `createProject` mutation.
    """

    job: CreateProjectJob = NOT_SET
    typename__: Optional[Literal['CreateProjectResponse']]= 'CreateProjectResponse'  # type: ignore[assignment]


@dataclass
class CreateRoleInProjectResponse(Base):
    """
    Represents a success response from the `createRoleInProject` mutation.
    """

    job: CreateRoleJob = NOT_SET
    typename__: Optional[Literal['CreateRoleInProjectResponse']]= 'CreateRoleInProjectResponse'  # type: ignore[assignment]


@dataclass
class CreateSchemaResponse(Base):
    """
    Represents a success response for the `createSchema` mutation.
    """

    schema: Schema = NOT_SET
    typename__: Optional[Literal['CreateSchemaResponse']]= 'CreateSchemaResponse'  # type: ignore[assignment]


@dataclass
class GetPersonalSpaceProjectResponse(Base):
    """
    Represents a success response from the `getPersonalSpaceProject` mutation.
    """

    job: CreateProjectJob = NOT_SET
    typename__: Optional[Literal['GetPersonalSpaceProjectResponse']]= 'GetPersonalSpaceProjectResponse'  # type: ignore[assignment]


@dataclass
class InternalCreatePrivateProjectResponse(Base):
    """
    Represents a success response for the `internalCreatePrivateProject` mutation.
    """

    project: Project = NOT_SET
    typename__: Optional[Literal['InternalCreatePrivateProjectResponse']]= 'InternalCreatePrivateProjectResponse'  # type: ignore[assignment]


@dataclass
class NumberedAssetVersion(AssetVersion):
    """
    A numbered asset version. Represents a significant milestone in the asset's development history. Each numbered version is
    associated with a specific revision of the asset.

    #### ────────────────────────────

    **References:**
     - See the `AssetRevision` type to learn more about how a revision is associated with a numbered version;
     - See the `Asset` type to learn more about the M&E asset composition and the complete data model;
     - See the `updateAsset` mutation to learn the asset version creation process.

    #### ────────────────────────────

    **Example:**
    ```
    ┌──────────────────────────────────────────────────────────────────────────────┐
    │                                                                              │
    │                               Shot_001                                       │
    | ____________________________________________________________________________ |
    │                                                                              │
    │   ┌──────────┐            ┌──────────────┐            ┌──────────────┐       │
    │   │          │            │              │            │              │       │
    │   │  Latest  │──LinksTo──▶│     V1       │──LinksTo──▶│  Revision 1  │       │
    │   │          │            │              │            │              │       │
    │   └──────────┘            └──────────────┘            └──────────────┘       │
    │                                                                              │
    └──────────────────────────────────────────────────────────────────────────────┘
    ```

    #### ────────────────────────────

    The above diagram shows a brand new asset `Shot_001` with one *numbered version* `V1` pointing to the initial revision `Revision 1`.

    # ────────────────────────────

    **Deep dive:**
    Important details to note about numbered versions:
     - A numbered version marks an important checkpoint in the progression of an asset's development, but it does not
       hold the actual revision data. Instead, it points to the specific revision that represents the state of the asset at
       that checkpoint.
     - Largest (latest) numbered asset version is always linked to the 'latest' named asset version;
     - Numbered asset versions can be used as the target of the `uses` relationship(s). See the `assetsByTraversal` query to learn more.
    """

    asset_id: ID = NOT_SET
    created: AuditLog = NOT_SET
    id: ID = NOT_SET
    modified: AuditLog = NOT_SET
    project_id: ID = NOT_SET
    is_latest: Boolean = NOT_SET
    revision: AssetRevision = NOT_SET
    revision_id: ID = NOT_SET
    version_number: Int = NOT_SET
    typename__: Optional[Literal['NumberedAssetVersion']]= 'NumberedAssetVersion'  # type: ignore[assignment]


@dataclass
class RecoverAssetResponse(Base):
    """
    Represents a success response from the `recoverAsset` mutation.
    """

    asset: Asset = NOT_SET
    typename__: Optional[Literal['RecoverAssetResponse']]= 'RecoverAssetResponse'  # type: ignore[assignment]


@dataclass
class UpdateAssetParentResponse(Base):
    """
    Represents a success response from the `updateAssetParent` mutation.
    """

    asset: Asset = NOT_SET
    typename__: Optional[Literal['UpdateAssetParentResponse']]= 'UpdateAssetParentResponse'  # type: ignore[assignment]


@dataclass
class UpdateAssetResponse(Base):
    """
    Represents a success response from the `updateAsset` mutation.
    """

    asset: Asset = NOT_SET
    typename__: Optional[Literal['UpdateAssetResponse']]= 'UpdateAssetResponse'  # type: ignore[assignment]


@dataclass
class CreateSchemaInput(Base):
    """
    Input parameters for the `createSchema` mutation.

    #### ────────────────────────────

    **Example:**
    ```json
    {
      "projectId": "urn:medm:project:yn2F9RNBjaBmuXqyyhcHra_L2C:qTqjxwuGD8LVAImARDDj9g_ags",
      "schemaLibraryId": "denysPersonalLib",
      "name": "person",
      "description": "First version of the person schema",
      "kind": "type",
      "version": "1.0.0",
      "inherits": [ "autodesk.me:object-1.0.0" ],
      "properties": [
        {
          "name": "name",
          "type": { "primitiveType": "String" }
        },
        {
          "name": "location",
          "type": { "primitiveType": "String" }
        }
      ]
    }
    ```
    """

    kind: SchemaKind = NOT_SET
    name: String = NOT_SET
    project_id: ID = NOT_SET
    schema_library_id: ID = NOT_SET
    version: String = NOT_SET
    description: Optional[String]= NOT_SET
    inherits: Optional[list[SchemaTypeId]]= NOT_SET
    properties: Optional[list[PropertiesDefinitionInput]]= NOT_SET
    typename__: Optional[Literal['CreateSchemaInput']]= 'CreateSchemaInput'  # type: ignore[assignment]


@dataclass
class NamedAssetVersion(AssetVersion):
    """
    A named asset version. Represents a specific named version of an asset. The goal of named asset versions is to assign
    a human-readable name to a numbered asset version. Later one that versions can be utilized in the dependency (`uses`) graphs,
    nightly renders or submitted to the M&E upper staff for review.

    #### ────────────────────────────

    **References:**
     - See the `NumberedAssetVersion` type to learn more about how a numbered version is associated with a named version;
     - See the `Asset` type to learn more about the M&E asset composition and the complete data model;
     - See the `updateAsset` mutation to learn the asset version creation process.

    #### ────────────────────────────

    **Constraints:**
    As of now, MEDM only offers one named version: `latest`. This is a special named asset version that acts a pointer to the = NOT_SET
    largest (latest) numbered asset version. It gets created automatically when the asset is created and also it is automatially
    repointed upon a new numbered version creation.

    #### ────────────────────────────

    **Example:**
    ```
    ┌──────────────────────────────────────────────────────────────────────────────┐
    │                                                                              │
    │                               Shot_001                                       │
    │ ____________________________________________________________________________ │
    │                                                                              │
    |                          ┌──────────────┐           ┌──────────────┐         │
    |                          │              │           │              │         │
    |                          │     V1       │──LinksTo─▶│  Revision 1  │         │
    |                          │              │           │              │         │
    |                          └──────────────┘           └──────────────┘         │
    │                                                                              │
    │   ┌──────────┐           ┌──────────────┐            ┌──────────────┐        │
    │   │          │           │              │            │              │        │
    │   │  Latest  │──LinksTo─▶│     V2       │──LinksTo──▶│  Revision 2  │        │
    │   │          │           │              │            │              │        │
    │   └──────────┘           └──────────────┘            └──────────────┘        │
    │                                                                              │
    └──────────────────────────────────────────────────────────────────────────────┘
    ```

    #### ────────────────────────────

    The above diagram shows a brand new asset `Shot_001` with a *named version* `Latest` pointing to the numbered version `V2`,
    which in turn is linked to the revision `Revision 2`.

    Prior to this update, the asset had one numbered version `V1` pointing to the revision `Revision 1`.

    #### ────────────────────────────

    **Deep dive:**
    Important details to note about named versions:
     - Named version does not hold the actual revision data. It only points to the numbered version that points to the revision;
     - Named asset versions can be used as the target of the `uses` relationship(s). See the `assetsByTraversal` query to learn more.
    """

    asset_id: ID = NOT_SET
    created: AuditLog = NOT_SET
    id: ID = NOT_SET
    modified: AuditLog = NOT_SET
    project_id: ID = NOT_SET
    is_latest: Boolean = NOT_SET
    name: String = NOT_SET
    numbered_version: NumberedAssetVersion = NOT_SET
    numbered_version_id: ID = NOT_SET
    typename__: Optional[Literal['NamedAssetVersion']]= 'NamedAssetVersion'  # type: ignore[assignment]
