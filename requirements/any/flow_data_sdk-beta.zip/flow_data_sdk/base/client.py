"""
Base GraphQL client implementation

Defines the BaseGQLClient class for interacting with a GraphQL API,
including authentication handling, query execution, and error handling.
"""

# Only SDK to server connection code should be here.

import json
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, NoReturn, Optional
from uuid import uuid4

from ._version import SDK_PACKAGE_NAME, SDK_VERSION
from .exceptions import (
    FIELD_AUTH_HANDLER,
    FIELD_ENDPOINT,
    FIELD_QUERY,
    MSG_AUTH_FAILED,
    MSG_AUTH_HANDLER_REQUIRED,
    MSG_CONNECTION_ERROR,
    MSG_ENDPOINT_REQUIRED,
    MSG_GRAPHQL_API_ERROR,
    MSG_QUERY_REQUIRED,
    MSG_RATE_LIMIT_EXCEEDED,
    FlowConnectionError,
    GQLAPIError,
    GQLErrorCode,
    ValidationError,
    gql_api_error_from_response_errors,
)
from .types import GQLResponse

_MAX_RETRIES = 3


@dataclass
class WorkflowContext:
    """Workflow identification for observability/tracing.

    Matches the baggage format used by flow-data-v2:
        workflow.name={name}, workflow.id={id}, workflow.monitor={monitor}

    Args:
        name: Human-readable workflow name (e.g. "my-app.asset-import")
        workflow_id: Unique ID for this workflow instance (auto-generated UUID if omitted)
        monitor: Whether observability systems should actively monitor this workflow
        traceparent: Optional W3C Trace Context traceparent header value
    """

    name: str
    workflow_id: Optional[str] = None
    monitor: bool = False
    traceparent: Optional[str] = None

    def __post_init__(self):
        if self.workflow_id is None:
            self.workflow_id = uuid4().hex

    def to_baggage(self) -> str:
        monitor_str = "true" if self.monitor else "false"
        return f"workflow.name={self.name}, " f"workflow.id={self.workflow_id}, " f"workflow.monitor={monitor_str}"


class AuthenticationHandlerBase(ABC):
    """Abstract base class for authentication handlers."""

    @abstractmethod
    def get_authentication_token(self) -> str:
        """Get the authentication token for API requests.

        Returns:
            str: The authentication token
        """


class BaseGQLClient:
    """Base GraphQL client with common functionality"""

    def __init__(
        self,
        endpoint: str,
        auth_handler: AuthenticationHandlerBase,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 30,
        max_pages: Optional[int] = None,
        workflow: Optional[WorkflowContext] = None,
    ):
        """
        Initialize the GraphQL client

        Args:
            endpoint: GraphQL endpoint URL
            auth_handler: Supplies token via get_authentication_token() (called on every GQL request)
            headers: Additional headers to include in requests
            timeout: Request timeout in seconds
            max_pages: Max pages to fetch in one go for .all(); None uses operation default
            workflow: Optional workflow context for observability baggage headers
        """
        # Validate required parameters
        if not endpoint:
            raise ValidationError(MSG_ENDPOINT_REQUIRED, field=FIELD_ENDPOINT, value=endpoint)
        self.endpoint = endpoint

        if not auth_handler:
            raise ValidationError(MSG_AUTH_HANDLER_REQUIRED, field=FIELD_AUTH_HANDLER, value=auth_handler)
        self.auth_handler = auth_handler
        self.timeout = timeout
        if max_pages is not None and (not isinstance(max_pages, int) or max_pages <= 0):
            raise ValidationError(
                "max_pages must be a positive integer or None",
                field="max_pages",
                value=max_pages,
            )
        self.max_pages = max_pages  # None => operation uses _MAX_PAGES

        # Build headers (Authorization is set on every GQL call in execute_query)
        self.headers = headers or {}

        # SDK identification header (always sent)
        self.headers["x-medm-sdk"] = f"{SDK_PACKAGE_NAME}:{SDK_VERSION}"

        # Workflow baggage headers (when caller provides workflow context)
        if workflow:
            self.headers["baggage"] = workflow.to_baggage()
            if workflow.traceparent:
                self.headers["traceparent"] = workflow.traceparent

    def _do_request(self, query: str, variables: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Send the GraphQL request over HTTP, retrying on network errors."""
        payload = json.dumps({"query": query, "variables": variables or {}}).encode()
        req = urllib.request.Request(
            url=self.endpoint,
            data=payload,
            headers={**self.headers, "Content-Type": "application/json"},
            method="POST",
        )
        last_exc: urllib.error.URLError = urllib.error.URLError("All retries failed")
        for _ in range(_MAX_RETRIES):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    return json.loads(response.read())  # type: ignore[no-any-return]
            except urllib.error.HTTPError:
                raise  # HTTP errors are not retried
            except urllib.error.URLError as e:
                last_exc = e
        raise last_exc

    def execute_query(self, query: str, variables: Optional[Dict[str, Any]] = None) -> GQLResponse:
        """
        Execute a GraphQL query

        Args:
            query: GraphQL query string
            variables: Query variables

        Returns:
            GQLResponse object
        """
        # Get token on every GQL call so auth_handler can refresh (e.g. short-lived tokens)
        token = self.auth_handler.get_authentication_token()
        if token:
            self.headers["Authorization"] = f"Bearer {token}"

        try:
            body = self._do_request(query, variables)
        except (GQLAPIError, FlowConnectionError, ValidationError):
            raise
        except Exception as e:  # pylint: disable=broad-exception-caught
            self._handle_error(e)

        # GraphQL errors arrive as HTTP 200 with an "errors" key in the body
        if "errors" in body:
            errors = body["errors"]
            if not errors:
                raise GQLAPIError(MSG_GRAPHQL_API_ERROR)
            raise gql_api_error_from_response_errors(errors)

        return GQLResponse(data=body.get("data"))

    def _handle_error(self, error: Exception) -> NoReturn:
        """Convert any transport/HTTP exception into an SDK exception.

        Handles HTTP errors (urllib.error.HTTPError), network/timeout errors
        (urllib.error.URLError), and falls back to GQLAPIError. Uses HTTP status
        code when available; never parses message text.
        """
        if isinstance(error, urllib.error.HTTPError):
            status_code = error.code
            if status_code == 401:
                raise GQLAPIError(
                    MSG_AUTH_FAILED,
                    error_code=GQLErrorCode.UNAUTHORIZED.value,
                ) from error
            if status_code == 429:
                raise GQLAPIError(
                    MSG_RATE_LIMIT_EXCEEDED,
                    error_code=GQLErrorCode.QUOTA_LIMIT_REACHED.value,
                ) from error
            if 500 <= status_code < 600:
                raise FlowConnectionError(MSG_CONNECTION_ERROR) from error
            # Other 4xx errors
            raise GQLAPIError(MSG_GRAPHQL_API_ERROR) from error

        if isinstance(error, urllib.error.URLError):
            raise FlowConnectionError(MSG_CONNECTION_ERROR) from error

        raise GQLAPIError(MSG_GRAPHQL_API_ERROR) from error

    def execute_raw_query(self, query: str, variables: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Execute a raw GraphQL query

        This method allows you to execute custom GraphQL queries that are not
        covered by the built-in service methods.

        Args:
            query: GraphQL query string
            variables: Query variables (optional)

        Returns:
            Raw response data
        """
        if not query or not isinstance(query, str):
            raise ValidationError(MSG_QUERY_REQUIRED, field=FIELD_QUERY, value=query)

        response = self.execute_query(query, variables)
        return response.data or {}
