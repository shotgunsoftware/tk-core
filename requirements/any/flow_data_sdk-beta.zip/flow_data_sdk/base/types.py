"""
Type definitions for the base GraphQL client
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union

# Common types
JSONValue = Union[str, int, float, bool, None, Dict[str, Any], List[Any]]
JSONDict = Dict[str, JSONValue]


@dataclass
class GQLResponse:
    """GraphQL response wrapper"""

    data: Optional[JSONDict] = None
    errors: Optional[List[Dict[str, Any]]] = None
    extensions: Optional[JSONDict] = None
