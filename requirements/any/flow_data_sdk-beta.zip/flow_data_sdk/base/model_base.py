"""
Base model classes for the Flow Data SDK.

This file is manually maintained and provides the Base class and NOT_SET singleton
that all generated models inherit from. The generator copies this file to tmp_build
during SDK generation.
"""

from __future__ import annotations

from dataclasses import fields, is_dataclass
from enum import Enum
from types import UnionType
from typing import Any, List, Sequence, Union, get_args, get_origin, get_type_hints


def snake_to_camel(snake_str: str) -> str:
    """
    Convert snake_case to camelCase.
    """
    components = snake_str.split("_")
    return components[0] + "".join(word.capitalize() for word in components[1:])


class NotSetType:
    """Sentinel type for NOT_SET values."""

    def __repr__(self) -> str:
        return "NOT_SET"

    def __bool__(self) -> bool:
        return False


# Create the singleton instance
NOT_SET = NotSetType()

# For type annotations - this is what you should use
NotSet = NotSetType  # Type alias pointing to the class itself


class Base:
    """Base class for all GraphQL model dataclasses."""

    @classmethod
    def _resolve_subclass(cls, typename: str) -> type[Base] | None:
        """
        Resolve a subclass by __typename, searching direct subclasses recursively.
        Returns the matching subclass or None if not found.
        """
        if cls.__name__ == typename and is_dataclass(cls):
            return cls
        for subclass in cls.__subclasses__():
            found = subclass._resolve_subclass(typename)
            if found is not None:
                return found
        return None

    @classmethod
    def from_dict(cls, data: dict) -> Base:
        """
        Recursively initialize a dataclass from a dictionary, handling nested dataclasses and lists.
        Handles both snake_case Python field names and camelCase GraphQL JSON keys.
        When __typename is present and differs from cls, delegates to the matching subclass.
        """
        # from_dict only applies dict data to dataclass fields; non-dataclass cannot consume data
        if not is_dataclass(cls):
            raise TypeError("from_dict can only be used with dataclass types; data would be ignored")

        if not data:
            return cls()

        # Check __typename to instantiate the correct subclass for interface types
        typename = (data.get("__typename") or "").strip() if isinstance(data.get("__typename"), str) else ""
        if typename and typename != cls.__name__:
            subclass = cls._resolve_subclass(typename)
            if subclass is not None and issubclass(subclass, cls):
                return subclass.from_dict(data)

        field_values = {}
        dataclass_fields = {f.name: f for f in fields(cls)}

        # Get type hints to resolve forward references
        try:
            type_hints = get_type_hints(cls)
        except (NameError, AttributeError):
            # Fall back to using field.type if get_type_hints fails
            type_hints = {f.name: f.type for f in fields(cls)}

        # Iterate through each field in the dataclass to map dictionary values
        for field_name, field_def in dataclass_fields.items():
            # Step 1: Try exact field name match first (snake_case in Python)
            # This supports backward compatibility and direct Python-to-Python serialization
            # where the dictionary keys already match the field names exactly
            if field_name in data:
                # Get the field's type annotation for proper value conversion
                field_type = type_hints.get(field_name, field_def.type)
                # Convert and assign the value using the field's type information
                field_values[field_name] = cls._convert_field_value(data[field_name], field_type)
            else:
                # Step 2: Try camelCase version of the field name
                # GraphQL JSON responses use camelCase (e.g., "firstName"), while Python
                # dataclass fields use snake_case (e.g., "first_name"). Convert the Python
                # field name to camelCase to match GraphQL JSON keys.
                camel_case_name = snake_to_camel(field_name)
                if camel_case_name in data:
                    # Found a match in camelCase, convert and assign the value
                    field_type = type_hints.get(field_name, field_def.type)
                    field_values[field_name] = cls._convert_field_value(data[camel_case_name], field_type)
                # If neither exact match nor camelCase match is found, the field will
                # use its default value (if defined) or be omitted from field_values

        return cls(**field_values)

    @classmethod
    def _resolve_union_by_typename(cls, value: Any, types: Sequence[type]) -> Any:
        """
        If *value* is a dict with a GraphQL ``__typename``, find the matching union
        member and convert.  Returns ``NOT_SET`` when no typename is present so the
        caller can fall back to trial-conversion.
        Raises TypeError when a typename is present but matches no member.
        """
        if not isinstance(value, dict):
            return NOT_SET
        raw = value.get("__typename")
        name = (raw or "").strip() if isinstance(raw, str) else ""
        if not name:
            return NOT_SET
        for member_type in types:
            if getattr(member_type, "__name__", None) == name:
                return cls._convert_field_value(value, member_type)
        type_names = [getattr(t, "__name__", t) for t in types]
        raise TypeError(f"__typename {name!r} is not a member of Union[{', '.join(str(n) for n in type_names)}]")

    @classmethod
    def _convert_union_field_value(cls, value: Any, args: tuple[type, ...]) -> Any:
        """
        Convert a value for a Union type (e.g. AssetParent = Asset | Project).
        Optional[T] is unwrapped; then __typename is used if present to try that type first,
        else each member is tried in order. Raises if no member accepts the value.
        """
        if not args:
            raise TypeError("Union type has no member types")

        # Optional[T] is exactly Union[T, None]. Unwrap and convert so _convert_field_value
        # handles None and the single type T (no "try each member" iteration).
        if len(args) == 2 and type(None) in args:
            actual_type = next(t for t in args if t is not type(None))
            return cls._convert_field_value(value, actual_type)

        types = list(args)
        resolved = cls._resolve_union_by_typename(value, types)
        if resolved is not NOT_SET:
            return resolved

        for member_type in types:
            try:
                return cls._convert_field_value(value, member_type)
            except (TypeError, ValueError):
                continue
        type_names = [getattr(member_type, "__name__", member_type) for member_type in args]
        raise TypeError(f"Value {value!r} does not match any Union member type: {type_names}")

    @classmethod
    def _convert_enum_field_value(cls, value: Any, field_type: type[Enum]) -> Enum:
        """
        Convert a value for an Enum type. Accepts an existing enum member or a string (e.g. from GQL).
        """
        if isinstance(value, field_type):
            return value
        if isinstance(value, str):
            return field_type(value)
        name = getattr(field_type, "__name__", field_type)
        raise TypeError(f"Expected {name} or str, got {type(value).__name__}: {value!r}")

    @classmethod
    def _convert_primitive_field_value(cls, value: Any, field_type: type) -> Any:
        """
        Validate and coerce a value for a primitive (non-dataclass, non-generic) type.
        JSON/GraphQL represents all numbers as a single type, so int is coerced to float.
        """
        if field_type is float and isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        if not isinstance(value, field_type):
            raise TypeError(
                f"Expected {getattr(field_type, '__name__', field_type)}, got {type(value).__name__}: {value!r}"
            )
        return value

    @classmethod
    def _convert_field_value(cls, value: Any, field_type: type) -> Any:
        """
        Convert a value to match the expected field type, handling nested dataclasses.
        """
        if value is None:
            return None

        # Handle Optional types
        origin = get_origin(field_type)
        args = get_args(field_type)

        if origin is Union or origin is UnionType:
            return cls._convert_union_field_value(value, args)

        # Handle List types
        if origin is list or origin is List:
            result = value
            if isinstance(value, list) and args:
                item_type = args[0]
                result = [cls._convert_field_value(item, item_type) for item in value]
            return result

        # Handle dataclass types - need to check if it's a class and a dataclass
        result = value
        if isinstance(field_type, type) and is_dataclass(field_type) and isinstance(value, dict):
            result = field_type.from_dict(value)  # type: ignore[attr-defined]
            return result
        # Handle Enum (API often returns enum values as strings, e.g. 'ACTIVE', 'NOT_DELETED')
        if isinstance(field_type, type) and issubclass(field_type, Enum):
            return cls._convert_enum_field_value(value, field_type)
        # Primitive/concrete types: validate and coerce value to match type
        if isinstance(field_type, type) and get_origin(field_type) is None and not is_dataclass(field_type):
            return cls._convert_primitive_field_value(value, field_type)
        return result

    def to_dict(self, suppress_typename: bool = False, use_camel_case: bool = True) -> dict:
        """
        Recursively convert the dataclass instance to a dictionary, handling nested dataclasses and lists.

        Args:
            suppress_typename: If True, exclude the typename__ field from the output
            use_camel_case: If True, convert snake_case field names to camelCase (for GraphQL)
        """
        result = {}
        # fields() accepts both instances and classes, but mypy only understands classes
        for field in fields(self):  # type: ignore[arg-type]
            if suppress_typename and field.name == "typename__":
                continue

            value = getattr(self, field.name)
            if value == NOT_SET:
                continue

            # Use camelCase for GraphQL serialization, snake_case otherwise
            key_name = snake_to_camel(field.name) if use_camel_case else field.name

            if is_dataclass(value) and hasattr(value, "to_dict"):
                # Type narrowing: is_dataclass + hasattr ensures value has to_dict method
                result[key_name] = value.to_dict(
                    suppress_typename=suppress_typename, use_camel_case=use_camel_case
                )  # type: ignore[union-attr]
            elif isinstance(value, list):
                result[key_name] = []
                for item in value:
                    if is_dataclass(item) and hasattr(item, "to_dict"):
                        # Type narrowing: is_dataclass + hasattr ensures item has to_dict method
                        result[key_name].append(
                            item.to_dict(
                                suppress_typename=suppress_typename, use_camel_case=use_camel_case
                            )  # type: ignore[union-attr]
                        )
                    else:
                        result[key_name].append(item)
            elif isinstance(value, Enum):
                result[key_name] = value.value
            else:
                result[key_name] = value
        return result
