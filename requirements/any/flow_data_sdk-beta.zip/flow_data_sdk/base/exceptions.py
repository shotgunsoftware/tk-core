"""
Custom exceptions for the base GraphQL client
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

# Message prefixes and validation messages/fields (used by client and tests).
# Real GQL errors use server message + extensions; these are for SDK validation
# and for prefixing transport/generic exceptions in _handle_error.
MSG_AUTH_FAILED = "Authentication failed"
MSG_RATE_LIMIT_EXCEEDED = "Rate limit exceeded"
MSG_CONNECTION_ERROR = "Connection error"
MSG_GRAPHQL_API_ERROR = "GraphQL API error"
MSG_SETUP_FAILED = "Failed to setup GraphQL client"
FIELD_ENDPOINT = "endpoint"
FIELD_AUTH_HANDLER = "auth_handler"
FIELD_QUERY = "query"
MSG_ENDPOINT_REQUIRED = "endpoint is required"
MSG_AUTH_HANDLER_REQUIRED = "auth_handler is required"
MSG_QUERY_REQUIRED = "query must be a non-empty string"


class GQLErrorCode(str, Enum):
    """GraphQL/MEDM error codes returned in extensions.code.

    Matches GraphQL error codes.
    """

    ACCESS_DENIED = "ACCESS_DENIED"
    ADMIN_API_ERROR = "ADMIN_API_ERROR"
    AGGREGATE_ERROR = "AGGREGATE_ERROR"
    AUTHENTICATION_ERROR = "AUTHENTICATION_ERROR"
    BAD_COLLECTION_ID = "BAD_COLLECTION_ID"
    BAD_USER_INPUT = "BAD_USER_INPUT"
    CONFIG_ERROR = "CONFIG_ERROR"
    CONFLICT = "CONFLICT"
    INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR"
    MALFORMED_ID = "MALFORMED_ID"
    NOT_FOUND = "NOT_FOUND"
    NOT_IMPLEMENTED = "NOT_IMPLEMENTED"
    OPERATION_NOT_ALLOWED = "OPERATION_NOT_ALLOWED"
    QUOTA_LIMIT_REACHED = "QUOTA_LIMIT_REACHED"
    UNAUTHORIZED = "UNAUTHORIZED"
    VERSION_ERROR = "VERSION_ERROR"


@dataclass
class GQLErrorDetails:
    """Structured error details from GraphQL responses.

    Attributes:
        message: Human-readable error message.
        extensions: Full extensions dict from the error (code, requestId,
            traceId, etc.). Use extensions.get("code") for per-error code.
    """

    message: str
    extensions: Dict[str, Any]


def _normalize_error_code(raw_code: Any) -> str:
    """Return GQLErrorCode value for raw_code.

    Raises:
        ValueError: If raw_code is None, not string-like, or does not match any GQLErrorCode.
    """
    if raw_code is None:
        raise ValueError("Missing error code in extensions")
    if not isinstance(raw_code, (str, int)):
        raise ValueError(f"Error code must be a string or int, got {type(raw_code).__name__}: {raw_code!r}")
    code_str = str(raw_code).strip()
    try:
        return GQLErrorCode(code_str).value
    except ValueError as e:
        raise ValueError(f"Unknown GraphQL error code: {raw_code!r}.") from e


def _process_one_response_error(
    err: Dict[str, Any],
) -> Tuple[GQLErrorDetails, Optional[str], Optional[str], Optional[str]]:
    """Parse one GraphQL error dict into details, code, request_id, and trace_id."""
    msg = err.get("message", "")
    exts = err.get("extensions") or {}
    if not isinstance(exts, dict):
        exts = {}
    try:
        code = _normalize_error_code(exts.get("code"))
    except ValueError:
        code = None
    request_id = exts.get("requestId") or exts.get("request_id")
    trace_id = exts.get("traceId") or exts.get("trace_id")
    details = GQLErrorDetails(message=msg, extensions=dict(exts))
    return details, str(code) if code else None, request_id, trace_id


def gql_api_error_from_response_errors(errors: List[Dict[str, Any]]) -> "GQLAPIError":
    """Build GQLAPIError from GraphQL response errors array.

    E.g. MEDM GraphQL Error. Expects each error to have message
    and extensions with error code. Extracts error_code, request_id and
    trace_id from the first error's extensions if present.
    If code is missing or unknown for an error, error_code stays None; all errors
    are still collected in error_details. Callers (client, operation) ensure
    errors is non-empty before calling.
    """
    # empty errors list
    if not errors:
        return GQLAPIError(MSG_GRAPHQL_API_ERROR)

    details_list: List[GQLErrorDetails] = []
    request_id: Optional[str] = None
    trace_id: Optional[str] = None
    error_code: Optional[str] = None

    for err in errors:
        details, code, rid, tid = _process_one_response_error(err)
        details_list.append(details)
        if not error_code and code:
            error_code = code
        if not request_id and rid:
            request_id = rid
        if not trace_id and tid:
            trace_id = tid

    primary_message = details_list[0].message if details_list else MSG_GRAPHQL_API_ERROR
    return GQLAPIError(
        primary_message,
        error_code=error_code,
        error_details=details_list,
        request_id=request_id,
        trace_id=trace_id,
    )


class GQLAPIError(Exception):
    """Raised when the GraphQL API returns an error.

    Attributes:
        message: Primary error message.
        error_code: GraphQL error code from the first error
            (e.g. BAD_USER_INPUT, NOT_FOUND, UNAUTHORIZED). May be None if
            code is missing or unknown (fallback path).
        error_details: Per-error details (message, extensions).
        request_id: Request ID from the first error's extensions, if present.
        trace_id: Trace ID from the first error's extensions, if present.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        error_details: Optional[List[GQLErrorDetails]] = None,
        request_id: Optional[str] = None,
        trace_id: Optional[str] = None,
    ):  # pylint: disable=too-many-arguments,too-many-positional-arguments
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.error_details = error_details or []
        self.request_id = request_id
        self.trace_id = trace_id


class FlowConnectionError(Exception):
    """Raised when there's a connection/transport issue (e.g. unreachable endpoint, timeout)."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class ValidationError(Exception):
    """Raised when SDK input validation fails (e.g. missing/invalid arguments)."""

    def __init__(self, message: str, field: Optional[str] = None, value: Any = None):
        super().__init__(message)
        self.message = message
        self.field = field
        self.value = value
