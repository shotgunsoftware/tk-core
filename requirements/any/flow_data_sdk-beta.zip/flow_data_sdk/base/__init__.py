"""
Base classes for the Flow Data SDK
"""

from . import model_g as model  # type: ignore[attr-defined]
from . import operation

__all__ = ["model", "operation"]
