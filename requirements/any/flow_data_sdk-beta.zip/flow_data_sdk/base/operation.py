"""
Base operation implementation for GraphQL operations.
Defines the OperationBase class for creating and managing GraphQL operations,
including query/mutation construction, variable handling, pagination, and response parsing.

Please extend this class for operations in the services module.
"""

# Only pydantic model to GQL operation code should be here.
from abc import ABC
from enum import Enum
from typing import ClassVar, Generic, Optional, Type, TypeVar

from . import model_g as model  # type: ignore[attr-defined]
from .client import BaseGQLClient
from .exceptions import GQLAPIError, gql_api_error_from_response_errors
from .types import GQLResponse

T = TypeVar("T", bound=model.Base)

PAGINATION_DEFAULT = """
    pagination {
        cursor
        pageSize
      }
"""
# Default max pages for .all(); overridden by client.max_pages when set
_MAX_PAGES = 5  # Maximum number of pages to fetch in one go, can be adjusted as needed


class OperationType(Enum):
    """Enumeration of GraphQL operation types."""

    QUERY = "query"
    MUTATION = "mutation"


class FieldIterator:
    """Iterator for a specific field in operation results."""

    def __init__(self, operation: "OperationBase", field_name: str):
        self._operation = operation
        self._field_name = field_name
        self._current_index = 0

    def __iter__(self):
        """Reset iterator state and return self."""
        self._current_index = 0
        return self

    def __next__(self):
        """Return next item from the field."""
        # Ensure we have initial data
        if not self._operation._has_been_called:  # pylint: disable=protected-access
            self._operation.call()

        # Get the field data from the operation
        field_data = getattr(self._operation, self._field_name, None)

        # Handle NOT_SET or None
        if field_data is model.NOT_SET or field_data is None:
            raise StopIteration

        # Check if we have more items
        if isinstance(field_data, list) and self._current_index < len(field_data):
            item = field_data[self._current_index]
            self._current_index += 1
            return item

        # Try to get next page if pagination is available
        if (
            self._operation._operation_has_pagination  # pylint: disable=protected-access
            and self._current_index >= len(field_data)
            and self._operation._next() is not None  # pylint: disable=protected-access
        ):
            # After getting next page, try again
            field_data = getattr(self._operation, self._field_name, None)
            if isinstance(field_data, list) and self._current_index < len(field_data):
                item = field_data[self._current_index]
                self._current_index += 1
                return item

        # No more items
        raise StopIteration


class OperationBase(ABC, Generic[T]):  # pylint: disable=too-many-instance-attributes
    """Base class for GraphQL operations with common functionality."""

    _response_model_class: ClassVar[Optional[Type[T]]] = None  # type: ignore[misc]
    _DEFAULT_SELECTION_GQL: str = ""

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Automatically set the response model class when subclass is created
        for base in cls.__orig_bases__:  # type: ignore[attr-defined,no-member]  # pylint: disable=no-member
            if hasattr(base, "__args__"):
                cls._response_model_class = base.__args__[0]
                break

    def __init__(  # pylint: disable=too-many-arguments
        self,
        *,
        client: BaseGQLClient,
        operation_type: OperationType,
        operation_name: str,
        variables_prefix: str,
        variables: model.Base,
        fields_str: str,
    ):
        self._client: BaseGQLClient = client
        self._operation_type: OperationType = operation_type
        self._operation_name = operation_name
        self._variables_prefix: str = variables_prefix

        self.operation_variables: model.Base = variables
        self.operation_fields: str = fields_str

        self._response_raw: model.NotSetType | GQLResponse = model.NOT_SET
        self._response_parsed: Optional[T] = None
        self._response_next_pagination: Optional[model.PaginationStandard] = None
        self._has_been_called = False
        self._operation_has_pagination = hasattr(self._response_model_class, "pagination")

    @property
    def operation_var_dict(self) -> dict:
        """Get the variables as a dictionary for the GraphQL operation."""
        return {self._variables_prefix: self.operation_variables.to_dict(suppress_typename=True)}

    @property
    def operation_fields_str(self) -> str:
        """Get the GraphQL query string for the operation."""
        pagination = PAGINATION_DEFAULT if self._operation_has_pagination else ""
        op_type = self._operation_type.value
        op_name = self._operation_name
        var_prefix = self._variables_prefix
        typename = getattr(self.operation_variables, "typename__", "")
        if self._response_model_class is None:
            raise ValueError("Response model class is not set for this operation")
        response_typename = getattr(self._response_model_class, "typename__", "")
        return f"""
            {op_type} {op_name}(${var_prefix}: {typename}!) {{
                {op_name}({var_prefix}: ${var_prefix}) {{
                    ... on {response_typename} {{
                        {self.operation_fields}
                        {pagination}
                    }}
                }}
            }}
            """

    def _check_response_errors(self, response: GQLResponse) -> None:
        """If response contains errors, raise GQLAPIError built from them."""
        response_errors = getattr(response, "errors", None)
        if response_errors and isinstance(response_errors, list) and len(response_errors) > 0:
            raise gql_api_error_from_response_errors(response_errors)

    # TODO: Refactor this method into several smaller methods to reduce complexity  # pylint: disable=fixme
    # Consider extracting: pagination setup, response parsing, and attribute merging logic
    def _call(self, pagination_cursor: Optional[str] = None) -> model.Base:  # pylint: disable=too-many-branches
        """Parse the Asset Graph gql response using the template's 'response_model' class.

        Arguments:
            data {dict} -- the json data returned from the Asset Graph call.

        Returns:
            T -- the response data as an instance of the 'response_model'

        Errors:

        """
        if pagination_cursor:
            # Check if operation_variables has a pagination attribute defined in its class
            # This is a dynamic attribute that may not exist in all input models
            if not hasattr(self.operation_variables, "pagination"):
                raise AttributeError(
                    f"Operation variables of type {type(self.operation_variables).__name__} "
                    "does not have a 'pagination' attribute. Pagination is only supported "
                    "for operations whose input model includes a pagination field."
                )
            pagination = getattr(self.operation_variables, "pagination", None)
            if not pagination:
                pagination = model.PaginationInput()
                # Note: Using setattr() here is intentional - the pagination attribute
                # exists in the class definition but may be None. This allows us to
                # dynamically set it when needed for pagination cursors.
                setattr(self.operation_variables, "pagination", pagination)
            # Note: Using setattr() for pagination.cursor and pagination.limit is intentional.
            # These attributes are defined in PaginationInput but may be None initially.
            setattr(pagination, "cursor", pagination_cursor)
            if not getattr(pagination, "limit", None):
                setattr(pagination, "limit", 100)

        self._response_raw = self._client.execute_query(
            query=self.operation_fields_str, variables=self.operation_var_dict
        )

        self._check_response_errors(self._response_raw)

        if self._response_raw.data is None:
            raise GQLAPIError("GraphQL response has no data")

        # At this point, we know self._response_raw.data is not None
        # Extract the operation-specific data from the response
        response_data = self._response_raw.data
        response_to_parse = response_data.get(self._operation_name)
        if response_to_parse is None:
            response_to_parse = {}

        if self._response_model_class is None:
            raise ValueError("Response model class is not set for this operation")

        # Ensure response_to_parse is a dict for from_dict
        if not isinstance(response_to_parse, dict):
            raise ValueError(f"Expected dict for response data, got {type(response_to_parse)}")

        self._response_parsed = self._response_model_class.from_dict(  # type: ignore[attr-defined,assignment]
            response_to_parse
        )
        for attr in vars(self._response_parsed):
            parsed_value = getattr(self._response_parsed, attr)
            if hasattr(self, attr):
                current_value = getattr(self, attr)
                if current_value == model.NOT_SET:
                    setattr(self, attr, parsed_value)
                elif isinstance(current_value, list) and isinstance(parsed_value, list):
                    current_value.extend(parsed_value)
                elif isinstance(current_value, dict) and isinstance(parsed_value, dict):
                    current_value.update(parsed_value)
                else:  # overwrite existing value
                    setattr(self, attr, parsed_value)

        self._response_next_pagination = getattr(self._response_parsed, "pagination", None)
        self._has_been_called = True
        return self._response_parsed  # type: ignore[return-value]

    def _next(self) -> Optional[model.Base]:
        """Get the next page of results if available."""

        # print("Fetching next page...")
        if self._operation_type != OperationType.QUERY:
            raise ValueError("Next and All operations are only available for queries.")

        if not self._has_been_called:
            return self._call()
        if not self._operation_has_pagination:
            raise ValueError("Next operation is only available for queries with pagination.")
        if self._response_next_pagination is not None:
            if self._response_next_pagination.cursor is not None:
                # Pass cursor directly to _call without mutating self.operation_variables
                # Convert NotSetType to string if needed for mypy
                pagination_cursor = (
                    str(self._response_next_pagination.cursor)
                    if self._response_next_pagination.cursor is not model.NOT_SET
                    else None
                )
                if pagination_cursor:
                    return self._call(pagination_cursor=pagination_cursor)
                return None  # There is no next page
            return None  # There is no next page
        return None  # There is no next page

    def _all(self):
        """Get all pages of results.

        Fetches up to client.max_pages pages (or _MAX_PAGES if client has no
        max_pages). The first page may already have been fetched by a prior
        .call(); page count starts from 1 in that case so the limit is respected.
        """
        if self._operation_type != OperationType.QUERY:
            raise ValueError("All operation is only available for queries.")
        if not self._operation_has_pagination:
            raise ValueError("All operation is only available for queries with pagination.")

        max_pages = getattr(self._client, "max_pages", _MAX_PAGES) or _MAX_PAGES
        # Count starts at 1 if we already have the first page (from a prior .call())
        count = 1 if self._has_been_called else 0

        pagination = (
            getattr(self.operation_variables, "pagination", None)
            if hasattr(self.operation_variables, "pagination")
            else None
        )
        if pagination is not None:
            setattr(pagination, "cursor", None)

        while count < max_pages and self._next() is not None:
            count += 1

    def _iterator_for_field(self, field_name: str) -> FieldIterator:
        """Get an iterator for a specific field in the operation results."""
        return FieldIterator(self, field_name)
