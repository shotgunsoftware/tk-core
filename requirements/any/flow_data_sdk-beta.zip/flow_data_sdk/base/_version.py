SDK_PACKAGE_NAME = "flow-data-sdk"

try:
    from importlib.metadata import PackageNotFoundError
    from importlib.metadata import version as _version

    SDK_VERSION = _version(SDK_PACKAGE_NAME)
except (ImportError, PackageNotFoundError):
    SDK_VERSION = "local_dev"
