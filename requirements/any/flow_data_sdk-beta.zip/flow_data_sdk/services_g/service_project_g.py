# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

from flow_data_sdk.base.client import BaseGQLClient
from flow_data_sdk.base.operation import OperationBase, OperationType
from typing import List, Optional
from .default_selection_g import selection_project_g as selection
from flow_data_sdk.base.model_g import (
    CreateProjectInput, 
	CreateProjectResponse, 
	GetPersonalSpaceProjectInput, 
	GetPersonalSpaceProjectResponse, 
	Project, 
	ProjectsByCollectionIdInput, 
	ProjectsByCollectionIdResponse, 
	ProjectsByIdsInput, 
	ProjectsByIdsResponse, 
	UpdateProjectInput, 
	UpdateProjectResponse
)
from flow_data_sdk.base.model_base import NotSetType


class OperationProjectsByCollectionId(OperationBase[ProjectsByCollectionIdResponse],ProjectsByCollectionIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: ProjectsByCollectionIdInput,
        fields_str: str = selection.PROJECTS_BY_COLLECTION_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="projectsByCollectionId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def projects_iterator(self) -> "list[Project]":
        """Get iterator for projects field."""
        return self._iterator_for_field('projects')  # type: ignore[return-value]
        

    def call(self) -> "ProjectsByCollectionIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "ProjectsByCollectionIdResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationProjectsByIds(OperationBase[ProjectsByIdsResponse],ProjectsByIdsResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: ProjectsByIdsInput,
        fields_str: str = selection.PROJECTS_BY_IDS,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="projectsByIds",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "ProjectsByIdsResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationCreateProject(OperationBase[CreateProjectResponse],CreateProjectResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CreateProjectInput,
        fields_str: str = selection.CREATE_PROJECT,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="createProject",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "CreateProjectResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationGetPersonalSpaceProject(OperationBase[GetPersonalSpaceProjectResponse],GetPersonalSpaceProjectResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: GetPersonalSpaceProjectInput,
        fields_str: str = selection.GET_PERSONAL_SPACE_PROJECT,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="getPersonalSpaceProject",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "GetPersonalSpaceProjectResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationUpdateProject(OperationBase[UpdateProjectResponse],UpdateProjectResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: UpdateProjectInput,
        fields_str: str = selection.UPDATE_PROJECT,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="updateProject",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "UpdateProjectResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class ServiceProject:
    def __init__(self, client: BaseGQLClient):
        self._client = client


    def projects_by_collection_id(
        self,
        variables: ProjectsByCollectionIdInput,
        fields_str: str = selection.PROJECTS_BY_COLLECTION_ID,
    ) -> OperationProjectsByCollectionId:
        """
        Retrieves a paginated list of _active_ projects within a specified collection.
        
        #### ────────────────────────────
        
        **Technical details:**
          - By default, the newer projects are returned first. I.e., projects are sorted by
            the creation date in descending order;
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested collection does not exist;
        """
        return OperationProjectsByCollectionId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def projects_by_ids(
        self,
        variables: ProjectsByIdsInput,
        fields_str: str = selection.PROJECTS_BY_IDS,
    ) -> OperationProjectsByIds:
        """
        Retrieves one or multiple projects by their IDs
        
        #### ────────────────────────────
        
        **Technical details:**
          - This query does not support a partial success response . Therefore, a user requests three projects by IDs
            and one of the projects does not exist, the entire request will fail with a `NOT_FOUND` error;
          - Duplicate IDs will be automatically omitted by the server;
          - The projects are returned in the same order as the IDs were provided.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** One or multiple requested projects were not found;
        """
        return OperationProjectsByIds(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def create_project(
        self,
        variables: CreateProjectInput,
        fields_str: str = selection.CREATE_PROJECT,
    ) -> OperationCreateProject:
        """
        Create a new project in a given collection in an asynchronous manner. The project will also be created in the CPA Hub associated with the collection.
        The result of this mutation is an asynchronous job that consumers are expected to poll for completion status via the `asyncJobsById` query.
        
        #### ────────────────────────────
        
        **Technical details:**
          - Only Hub admins can create new projects;
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested collection does not exist;
        """
        return OperationCreateProject(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def get_personal_space_project(
        self,
        variables: GetPersonalSpaceProjectInput,
        fields_str: str = selection.GET_PERSONAL_SPACE_PROJECT,
    ) -> OperationGetPersonalSpaceProject:
        """
        Gets a personal space project for the user.
        If the project already exists, the project field will be available.
        If the project does not exist, initiates its creation and returns an asyncJob which gives its creation status.
        This mutation can also be polled to check the status of the project creation.
        Note: The asyncJob is owned by the Provisioning process and cannot be used by the caller.
        Retrives a personal space project for the requestor. A personal project is a private project that can be used to store asset data.
        
        Multiple scenarios are possible
         - If the project already exists, it will be returned in the `project` field of the async job response;
         - If the project does not exist, MEDM Server will initiate its creation and return an `asyncJob` to track the creation process.
        
        #### ────────────────────────────
        
        **Technical details:**
          - This mutation may be polled to check the status of the project creation process.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`CONFIG_ERROR:`** The required configuration for personal space projects is missing;
        """
        return OperationGetPersonalSpaceProject(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def update_project(
        self,
        variables: UpdateProjectInput,
        fields_str: str = selection.UPDATE_PROJECT,
    ) -> OperationUpdateProject:
        """
        Update an existing MEDM project to modify its properties (name, description, components, etc.).
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested project does not exist;
        """
        return OperationUpdateProject(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )

