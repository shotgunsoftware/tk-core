# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

from flow_data_sdk.base.client import BaseGQLClient
from flow_data_sdk.base.operation import OperationBase, OperationType
from typing import List, Optional
from .default_selection_g import selection_binary_g as selection
from flow_data_sdk.base.model_g import (
    BinaryComponentUrlsByUrnsInput, 
	BinaryComponentUrlsByUrnsResponse, 
	CloseUploadFileInput, 
	CloseUploadFileResponse, 
	GetUploadFilePartInput, 
	GetUploadFilePartResponse, 
	OpenUploadFileInput, 
	OpenUploadFileResponse
)
from flow_data_sdk.base.model_base import NotSetType


class OperationBinaryComponentUrlsByUrns(OperationBase[BinaryComponentUrlsByUrnsResponse],BinaryComponentUrlsByUrnsResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: BinaryComponentUrlsByUrnsInput,
        fields_str: str = selection.BINARY_COMPONENT_URLS_BY_URNS,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="binaryComponentUrlsByUrns",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "BinaryComponentUrlsByUrnsResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationOpenUploadFile(OperationBase[OpenUploadFileResponse],OpenUploadFileResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: OpenUploadFileInput,
        fields_str: str = selection.OPEN_UPLOAD_FILE,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="openUploadFile",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "OpenUploadFileResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationGetUploadFilePart(OperationBase[GetUploadFilePartResponse],GetUploadFilePartResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: GetUploadFilePartInput,
        fields_str: str = selection.GET_UPLOAD_FILE_PART,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="getUploadFilePart",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "GetUploadFilePartResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationCloseUploadFile(OperationBase[CloseUploadFileResponse],CloseUploadFileResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CloseUploadFileInput,
        fields_str: str = selection.CLOSE_UPLOAD_FILE,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="closeUploadFile",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "CloseUploadFileResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class ServiceBinary:
    def __init__(self, client: BaseGQLClient):
        self._client = client


    def binary_component_urls_by_urns(
        self,
        variables: BinaryComponentUrlsByUrnsInput,
        fields_str: str = selection.BINARY_COMPONENT_URLS_BY_URNS,
    ) -> OperationBinaryComponentUrlsByUrns:
        """
        Retrieves a URL representation of the given binary blob URNs. With these URLs you can download the contents of the binary components.
        
        **Technical details:**
          - The respone `urls` field maintains the order of the requested URNs;
          - If any of the requested URNs cannot be processed, the entire request will fail;
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** One or multiple requested binary blob URNs do not exist;
        """
        return OperationBinaryComponentUrlsByUrns(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def open_upload_file(
        self,
        variables: OpenUploadFileInput,
        fields_str: str = selection.OPEN_UPLOAD_FILE,
    ) -> OperationOpenUploadFile:
        """
        Initiates an asynchronous process for uploading a file in multiple parts, similar to opening a file for writing.
        Returns an `UploadFileJob` containing a job ID, which is required for subsequent upload steps and monitoring the upload status.
        
        #### ────────────────────────────
        
        **Technical details:**
          - Previously failed upload can be restarted via the `openUploadFile` mutation;
        """
        return OperationOpenUploadFile(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def get_upload_file_part(
        self,
        variables: GetUploadFilePartInput,
        fields_str: str = selection.GET_UPLOAD_FILE_PART,
    ) -> OperationGetUploadFilePart:
        """
        Retrieves upload information for a specific part of the multipart upload for the single file upload.
        
        This mutation is used during the multipart upload process to get the signed URL and other details needed to upload a specific part of a file.
        Each part is validated with an MD5 checksum to ensure data integrity.
        
        Returns upload details including the signed URL where the part data should be sent to.
        """
        return OperationGetUploadFilePart(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def close_upload_file(
        self,
        variables: CloseUploadFileInput,
        fields_str: str = selection.CLOSE_UPLOAD_FILE,
    ) -> OperationCloseUploadFile:
        """
        Completes or aborts a multipart upload operation.
        
        This mutation finalizes a multipart upload by either completing it successfully or marking it as failed. When completing successfully, all uploaded parts are
        assembled into the final file using the provided ETags.
        
        For successful completion, the ETags from each uploaded part must be provided.
        """
        return OperationCloseUploadFile(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )

