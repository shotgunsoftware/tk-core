# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

from flow_data_sdk.base.client import BaseGQLClient
from flow_data_sdk.base.operation import OperationBase, OperationType
from typing import List, Optional
from .default_selection_g import selection_job_g as selection
from flow_data_sdk.base.model_g import (
    ActivateProductJob, 
	AddUserJob, 
	AsyncJobsByAssetRevisionIdsInput, 
	AsyncJobsByAssetRevisionIdsResponse, 
	AsyncJobsByIdsInput, 
	AsyncJobsByIdsResponse, 
	ContainerJob, 
	CreateProjectJob, 
	CreateRoleJob, 
	HardDeleteAssetAsyncJob, 
	UploadFileJob
)
from flow_data_sdk.base.model_base import NotSetType


class OperationAsyncJobsByIds(OperationBase[AsyncJobsByIdsResponse],AsyncJobsByIdsResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AsyncJobsByIdsInput,
        fields_str: str = selection.ASYNC_JOBS_BY_IDS,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="asyncJobsByIds",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "AsyncJobsByIdsResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationAsyncJobsByAssetRevisionIds(OperationBase[AsyncJobsByAssetRevisionIdsResponse],AsyncJobsByAssetRevisionIdsResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AsyncJobsByAssetRevisionIdsInput,
        fields_str: str = selection.ASYNC_JOBS_BY_ASSET_REVISION_IDS,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="asyncJobsByAssetRevisionIds",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def jobs_iterator(self) -> "list[ActivateProductJob | AddUserJob | ContainerJob | CreateProjectJob | CreateRoleJob | HardDeleteAssetAsyncJob | UploadFileJob]":
        """Get iterator for jobs field."""
        return self._iterator_for_field('jobs')  # type: ignore[return-value]
        

    def call(self) -> "AsyncJobsByAssetRevisionIdsResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "AsyncJobsByAssetRevisionIdsResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class ServiceJob:
    def __init__(self, client: BaseGQLClient):
        self._client = client


    def async_jobs_by_ids(
        self,
        variables: AsyncJobsByIdsInput,
        fields_str: str = selection.ASYNC_JOBS_BY_IDS,
    ) -> OperationAsyncJobsByIds:
        """
        Retrieves one or multiple async jobs by their IDs
        
        #### ────────────────────────────
        
        **Technical details:**
          - This query does not support partial-success responses. Therefore, if one or more of the requested async jobs do not exist, the entire request will fail with a `NOT_FOUND` error;
          - The async jobs are returned in the same order as the IDs were provided;
          - Duplicate IDs will be automatically omitted by the server (i.e., the response will not contain the same async job twice);
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** One or multiple requested async jobs do not exist;
        """
        return OperationAsyncJobsByIds(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def async_jobs_by_asset_revision_ids(
        self,
        variables: AsyncJobsByAssetRevisionIdsInput,
        fields_str: str = selection.ASYNC_JOBS_BY_ASSET_REVISION_IDS,
    ) -> OperationAsyncJobsByAssetRevisionIds:
        """
        Retrieves a paginated list of `AsyncJob`s associated with the given asset revision IDs.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** One or multiple requested asset revision IDs do not exist;
        """
        return OperationAsyncJobsByAssetRevisionIds(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )

