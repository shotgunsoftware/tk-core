# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

from flow_data_sdk.base.client import BaseGQLClient
from flow_data_sdk.base.operation import OperationBase, OperationType
from typing import List, Optional
from .default_selection_g import selection_collection_g as selection
from flow_data_sdk.base.model_g import (
    Collection, 
	CollectionsInput, 
	CollectionsResponse
)
from flow_data_sdk.base.model_base import NotSetType


class OperationCollections(OperationBase[CollectionsResponse],CollectionsResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CollectionsInput,
        fields_str: str = selection.COLLECTIONS,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="collections",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def collections_iterator(self) -> "list[Collection]":
        """Get iterator for collections field."""
        return self._iterator_for_field('collections')  # type: ignore[return-value]
        

    def call(self) -> "CollectionsResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "CollectionsResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class ServiceCollection:
    def __init__(self, client: BaseGQLClient):
        self._client = client


    def collections(
        self,
        variables: CollectionsInput,
        fields_str: str = selection.COLLECTIONS,
    ) -> OperationCollections:
        """
        Retrieves a paginated list of collections available to the current user.
        
        #### ────────────────────────────
        
        **Technical details:**
          - Each collection is associated with the respective CPA Hub.
        """
        return OperationCollections(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )

