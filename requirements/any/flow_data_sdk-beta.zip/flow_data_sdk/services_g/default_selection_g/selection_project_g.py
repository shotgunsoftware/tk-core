# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

PROJECTS_BY_COLLECTION_ID = """
pagination {
    cursor
    pageSize
}
projects {
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    description
    hasChildren
    hubId
    hubUrn
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    schemaRegistryInfo {
        groupId
        organizationId
    }
    state
}
"""



PROJECTS_BY_IDS = """
projects {
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    description
    hasChildren
    hubId
    hubUrn
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    schemaRegistryInfo {
        groupId
        organizationId
    }
    state
}
"""



CREATE_PROJECT = """
job {
    createdOn
    description
    id
    project {
        components {
            data
            name
            parentTypeIds
            typeId
        }
        created {
            date
            serviceId
            user {
                accessLevel
                accountId
                email
                firstName
                id
                lastModifiedOn
                lastName
                roles {
                    defaultAccessLevel
                    id
                    policies {
                        action
                        location
                        name
                    }
                    roleName
                    status
                }
                status
                userName
            }
            userId
        }
        description
        hasChildren
        hubId
        hubUrn
        id
        modified {
            date
            serviceId
            user {
                accessLevel
                accountId
                email
                firstName
                id
                lastModifiedOn
                lastName
                roles {
                    defaultAccessLevel
                    id
                    policies {
                        action
                        location
                        name
                    }
                    roleName
                    status
                }
                status
                userName
            }
            userId
        }
        name
        schemaRegistryInfo {
            groupId
            organizationId
        }
        state
    }
    state
    updatedOn
}
"""



GET_PERSONAL_SPACE_PROJECT = """
job {
    createdOn
    description
    id
    project {
        components {
            data
            name
            parentTypeIds
            typeId
        }
        created {
            date
            serviceId
            user {
                accessLevel
                accountId
                email
                firstName
                id
                lastModifiedOn
                lastName
                roles {
                    defaultAccessLevel
                    id
                    policies {
                        action
                        location
                        name
                    }
                    roleName
                    status
                }
                status
                userName
            }
            userId
        }
        description
        hasChildren
        hubId
        hubUrn
        id
        modified {
            date
            serviceId
            user {
                accessLevel
                accountId
                email
                firstName
                id
                lastModifiedOn
                lastName
                roles {
                    defaultAccessLevel
                    id
                    policies {
                        action
                        location
                        name
                    }
                    roleName
                    status
                }
                status
                userName
            }
            userId
        }
        name
        schemaRegistryInfo {
            groupId
            organizationId
        }
        state
    }
    state
    updatedOn
}
"""



UPDATE_PROJECT = """
project {
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    description
    hasChildren
    hubId
    hubUrn
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    schemaRegistryInfo {
        groupId
        organizationId
    }
    state
}
"""

