# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

ASSETS_BY_TRAVERSAL = """
assets {
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    deletionState
    description
    hasChildren
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    parentId
    projectId
    publishTransferStatus
    revisionId
    revisionNumber
    versionNumber
}
edges {
    fromId
    toId
}
pagination {
    cursor
    pageSize
}
project {
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    description
    hasChildren
    hubId
    hubUrn
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    schemaRegistryInfo {
        groupId
        organizationId
    }
    state
}
"""



ASSET_PARENT = """
parent {
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    deletionState
    description
    hasChildren
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    parentId
    projectId
    publishTransferStatus
    revisionId
    revisionNumber
    versionNumber
}
"""



ASSETS_BY_IDS = """
assets {
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    deletionState
    description
    hasChildren
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    parentId
    projectId
    publishTransferStatus
    revisionId
    revisionNumber
    versionNumber
}
"""



ASSETS_BY_SEARCH = """
pagination {
    cursor
    pageSize
}
results {
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    deletionState
    description
    hasChildren
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    parentId
    projectId
    publishTransferStatus
    revisionId
    revisionNumber
    versionNumber
}
totalResults
"""



ASSETS_BY_PROJECT_ID = """
assets {
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    deletionState
    description
    hasChildren
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    parentId
    projectId
    publishTransferStatus
    revisionId
    revisionNumber
    versionNumber
}
pagination {
    cursor
    pageSize
}
"""



ASSET_VERSIONS_BY_IDS = """
versions {
    __typename
    assetId
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    projectId
    ... on NumberedAssetVersion {
        isLatest
        revision {
            assetId
            assetTypeIds
            components {
                data
                name
                parentTypeIds
                typeId
            }
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            description
            id
            isLatest
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            name
            numberedVersionId
            projectId
            publishTransferStatus
            revisionNumber
            versionNumber
        }
        revisionId
        versionNumber
    }
    ... on NamedAssetVersion {
        isLatest
        name
        numberedVersion {
            assetId
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            id
            isLatest
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            projectId
            revision {
                assetId
                assetTypeIds
                components {
                    data
                    name
                    parentTypeIds
                    typeId
                }
                created {
                    date
                    serviceId
                    user {
                        accessLevel
                        accountId
                        email
                        firstName
                        id
                        lastModifiedOn
                        lastName
                        roles {
                            defaultAccessLevel
                            id
                            roleName
                            status
                        }
                        status
                        userName
                    }
                    userId
                }
                description
                id
                isLatest
                modified {
                    date
                    serviceId
                    user {
                        accessLevel
                        accountId
                        email
                        firstName
                        id
                        lastModifiedOn
                        lastName
                        roles {
                            defaultAccessLevel
                            id
                            roleName
                            status
                        }
                        status
                        userName
                    }
                    userId
                }
                name
                numberedVersionId
                projectId
                publishTransferStatus
                revisionNumber
                versionNumber
            }
            revisionId
            versionNumber
        }
        numberedVersionId
    }
}
"""



ASSET_VERSIONS_BY_ASSET_ID = """
assetVersions {
    __typename
    assetId
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    projectId
    ... on NumberedAssetVersion {
        isLatest
        revision {
            assetId
            assetTypeIds
            components {
                data
                name
                parentTypeIds
                typeId
            }
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            description
            id
            isLatest
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            name
            numberedVersionId
            projectId
            publishTransferStatus
            revisionNumber
            versionNumber
        }
        revisionId
        versionNumber
    }
    ... on NamedAssetVersion {
        isLatest
        name
        numberedVersion {
            assetId
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            id
            isLatest
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            projectId
            revision {
                assetId
                assetTypeIds
                components {
                    data
                    name
                    parentTypeIds
                    typeId
                }
                created {
                    date
                    serviceId
                    user {
                        accessLevel
                        accountId
                        email
                        firstName
                        id
                        lastModifiedOn
                        lastName
                        roles {
                            defaultAccessLevel
                            id
                            roleName
                            status
                        }
                        status
                        userName
                    }
                    userId
                }
                description
                id
                isLatest
                modified {
                    date
                    serviceId
                    user {
                        accessLevel
                        accountId
                        email
                        firstName
                        id
                        lastModifiedOn
                        lastName
                        roles {
                            defaultAccessLevel
                            id
                            roleName
                            status
                        }
                        status
                        userName
                    }
                    userId
                }
                name
                numberedVersionId
                projectId
                publishTransferStatus
                revisionNumber
                versionNumber
            }
            revisionId
            versionNumber
        }
        numberedVersionId
    }
}
pagination {
    cursor
    pageSize
}
"""



ASSET_VERSIONS_BY_TRAVERSAL = """
edges {
    fromId
    toId
}
pagination {
    cursor
    pageSize
}
revisions {
    assetId
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    description
    id
    isLatest
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    projectId
    publishTransferStatus
    revisionNumber
    versionNumber
}
versions {
    __typename
    assetId
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    projectId
    ... on NumberedAssetVersion {
        isLatest
        revision {
            assetId
            assetTypeIds
            components {
                data
                name
                parentTypeIds
                typeId
            }
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            description
            id
            isLatest
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            name
            numberedVersionId
            projectId
            publishTransferStatus
            revisionNumber
            versionNumber
        }
        revisionId
        versionNumber
    }
    ... on NamedAssetVersion {
        isLatest
        name
        numberedVersion {
            assetId
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            id
            isLatest
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            projectId
            revision {
                assetId
                assetTypeIds
                components {
                    data
                    name
                    parentTypeIds
                    typeId
                }
                created {
                    date
                    serviceId
                    user {
                        accessLevel
                        accountId
                        email
                        firstName
                        id
                        lastModifiedOn
                        lastName
                        roles {
                            defaultAccessLevel
                            id
                            roleName
                            status
                        }
                        status
                        userName
                    }
                    userId
                }
                description
                id
                isLatest
                modified {
                    date
                    serviceId
                    user {
                        accessLevel
                        accountId
                        email
                        firstName
                        id
                        lastModifiedOn
                        lastName
                        roles {
                            defaultAccessLevel
                            id
                            roleName
                            status
                        }
                        status
                        userName
                    }
                    userId
                }
                name
                numberedVersionId
                projectId
                publishTransferStatus
                revisionNumber
                versionNumber
            }
            revisionId
            versionNumber
        }
        numberedVersionId
    }
}
"""



CREATE_ASSET = """
asset {
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    deletionState
    description
    hasChildren
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    parentId
    projectId
    publishTransferStatus
    revisionId
    revisionNumber
    versionNumber
}
"""



UPDATE_ASSET = """
asset {
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    deletionState
    description
    hasChildren
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    parentId
    projectId
    publishTransferStatus
    revisionId
    revisionNumber
    versionNumber
}
"""



UPDATE_ASSET_PARENT = """
asset {
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    deletionState
    description
    hasChildren
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    parentId
    projectId
    publishTransferStatus
    revisionId
    revisionNumber
    versionNumber
}
"""



SOFT_DELETE_ASSET = """
message
"""



HARD_DELETE_ASSET = """
job {
    description
    id
    state
    updatedOn
}
"""



RECOVER_ASSET = """
asset {
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    deletionState
    description
    hasChildren
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    parentId
    projectId
    publishTransferStatus
    revisionId
    revisionNumber
    versionNumber
}
"""

