# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

SCHEMAS_BY_TYPE_ID = """
inheritedSchemas {
    displayData {
        displayName
    }
    inherits
    name
    properties {
        context
        displayData {
            displayName
        }
        length
        name
        properties {
            context
            displayData {
                displayName
            }
            length
            name
            properties {
                context
                displayData {
                    displayName
                }
                length
                name
                properties {
                    context
                    displayData {
                        displayName
                    }
                    length
                    name
                    properties {
                        context
                        displayData {
                            displayName
                        }
                        length
                        name
                        properties {
                            context
                            length
                            name
                            type
                            value
                        }
                        type
                        value
                    }
                    type
                    value
                }
                type
                value
            }
            type
            value
        }
        type
        value
    }
    typeId
}
schemas {
    displayData {
        displayName
    }
    inherits
    name
    properties {
        context
        displayData {
            displayName
        }
        length
        name
        properties {
            context
            displayData {
                displayName
            }
            length
            name
            properties {
                context
                displayData {
                    displayName
                }
                length
                name
                properties {
                    context
                    displayData {
                        displayName
                    }
                    length
                    name
                    properties {
                        context
                        displayData {
                            displayName
                        }
                        length
                        name
                        properties {
                            context
                            length
                            name
                            type
                            value
                        }
                        type
                        value
                    }
                    type
                    value
                }
                type
                value
            }
            type
            value
        }
        type
        value
    }
    typeId
}
"""



SCHEMAS_BY_LIBRARY_ID = """
pagination {
    cursor
    pageSize
}
schemas {
    displayData {
        displayName
    }
    inherits
    name
    properties {
        context
        displayData {
            displayName
        }
        length
        name
        properties {
            context
            displayData {
                displayName
            }
            length
            name
            properties {
                context
                displayData {
                    displayName
                }
                length
                name
                properties {
                    context
                    displayData {
                        displayName
                    }
                    length
                    name
                    properties {
                        context
                        displayData {
                            displayName
                        }
                        length
                        name
                        properties {
                            context
                            length
                            name
                            type
                            value
                        }
                        type
                        value
                    }
                    type
                    value
                }
                type
                value
            }
            type
            value
        }
        type
        value
    }
    typeId
}
"""



SCHEMA_LIBRARIES_BY_COLLECTION_ID = """
libraries {
    createTime
    createdBy
    description
    lastModifiedBy
    lastModifiedTime
    name
    title
}
pagination {
    cursor
    pageSize
}
"""



SCHEMAS_BY_SUPER_TYPE = """
pagination {
    cursor
    pageSize
}
schemaTypes
"""



SCHEMA_DISPLAY_DATA = """
schemaDisplayData {
    displayName
    propertiesDisplayData {
        displayName
        propertyId
    }
    schemaTypeId
}
"""



CREATE_SCHEMA_LIBRARY = """
schemaLibrary {
    createTime
    createdBy
    description
    lastModifiedBy
    lastModifiedTime
    name
    title
}
"""



CREATE_SCHEMA = """
schema {
    displayData {
        displayName
    }
    inherits
    name
    properties {
        context
        displayData {
            displayName
        }
        length
        name
        properties {
            context
            displayData {
                displayName
            }
            length
            name
            properties {
                context
                displayData {
                    displayName
                }
                length
                name
                properties {
                    context
                    displayData {
                        displayName
                    }
                    length
                    name
                    properties {
                        context
                        displayData {
                            displayName
                        }
                        length
                        name
                        properties {
                            context
                            length
                            name
                            type
                            value
                        }
                        type
                        value
                    }
                    type
                    value
                }
                type
                value
            }
            type
            value
        }
        type
        value
    }
    typeId
}
"""



CREATE_SCHEMA_DISPLAY_DATA = """
displayData {
    displayName
    propertiesDisplayData {
        displayName
        propertyId
    }
    schemaTypeId
}
"""



UPDATE_SCHEMA_DISPLAY_DATA = """
displayData {
    displayName
    propertiesDisplayData {
        displayName
        propertyId
    }
    schemaTypeId
}
"""



DELETE_SCHEMA_DISPLAY_DATA = """
message
"""

