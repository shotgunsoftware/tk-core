# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

ASYNC_JOBS_BY_IDS = """
jobs {
    __typename
    description
    id
    state
    updatedOn
    ... on AddUserJob {
        createdOn
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
    }
    ... on ContainerJob {
        flowData {
            collectionId
        }
        jobs {
            description
            id
            state
            updatedOn
        }
    }
    ... on CreateRoleJob {
        createdOn
        role {
            defaultAccessLevel
            id
            policies {
                action
                location
                name
            }
            roleName
            status
        }
    }
    ... on ActivateProductJob {
        collection {
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            description
            id
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            name
        }
        createdOn
    }
    ... on CreateProjectJob {
        createdOn
        project {
            components {
                data
                name
                parentTypeIds
                typeId
            }
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            description
            hasChildren
            hubId
            hubUrn
            id
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            name
            schemaRegistryInfo {
                groupId
                organizationId
            }
            state
        }
    }
}
"""



ASYNC_JOBS_BY_ASSET_REVISION_IDS = """
jobs {
    __typename
    description
    id
    state
    updatedOn
    ... on AddUserJob {
        createdOn
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
    }
    ... on ContainerJob {
        flowData {
            collectionId
        }
        jobs {
            description
            id
            state
            updatedOn
        }
    }
    ... on CreateRoleJob {
        createdOn
        role {
            defaultAccessLevel
            id
            policies {
                action
                location
                name
            }
            roleName
            status
        }
    }
    ... on ActivateProductJob {
        collection {
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            description
            id
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            name
        }
        createdOn
    }
    ... on CreateProjectJob {
        createdOn
        project {
            components {
                data
                name
                parentTypeIds
                typeId
            }
            created {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            description
            hasChildren
            hubId
            hubUrn
            id
            modified {
                date
                serviceId
                user {
                    accessLevel
                    accountId
                    email
                    firstName
                    id
                    lastModifiedOn
                    lastName
                    roles {
                        defaultAccessLevel
                        id
                        policies {
                            action
                            location
                            name
                        }
                        roleName
                        status
                    }
                    status
                    userName
                }
                userId
            }
            name
            schemaRegistryInfo {
                groupId
                organizationId
            }
            state
        }
    }
}
pagination {
    cursor
    pageSize
}
"""

