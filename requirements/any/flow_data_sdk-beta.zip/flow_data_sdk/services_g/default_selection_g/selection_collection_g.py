# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

COLLECTIONS = """
collections {
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    description
    id
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
}
pagination {
    cursor
    pageSize
}
"""

