# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

ASSET_REVISIONS_BY_IDS = """
revisions {
    assetId
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    description
    id
    isLatest
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    projectId
    publishTransferStatus
    revisionNumber
    versionNumber
}
"""



ASSET_REVISIONS_BY_ASSET_ID = """
assetRevisions {
    assetId
    assetTypeIds
    components {
        data
        name
        parentTypeIds
        typeId
    }
    created {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    description
    id
    isLatest
    modified {
        date
        serviceId
        user {
            accessLevel
            accountId
            email
            firstName
            id
            lastModifiedOn
            lastName
            roles {
                defaultAccessLevel
                id
                policies {
                    action
                    location
                    name
                }
                roleName
                status
            }
            status
            userName
        }
        userId
    }
    name
    numberedVersionId
    projectId
    publishTransferStatus
    revisionNumber
    versionNumber
}
pagination {
    cursor
    pageSize
}
"""

