# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

ROLES_BY_PROJECT_ID = """
pagination {
    cursor
    pageSize
}
roles {
    defaultAccessLevel
    id
    policies {
        action
        location
        name
    }
    roleName
    status
}
"""



CREATE_PERMISSION_POLICY_IN_ROLE = """
policy {
    action
    location
    name
}
"""



UPDATE_PERMISSION_POLICY = """
policy {
    action
    location
    name
}
"""



DELETE_PERMISSION_POLICY = """
message
success
"""

