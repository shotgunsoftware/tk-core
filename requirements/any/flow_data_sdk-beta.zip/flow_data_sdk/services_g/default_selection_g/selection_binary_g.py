# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

BINARY_COMPONENT_URLS_BY_URNS = """
urls {
    url
    urn
}
"""



OPEN_UPLOAD_FILE = """
job {
    description
    id
    state
    updatedOn
}
"""



GET_UPLOAD_FILE_PART = """
numBytes
sendUrl
uploadFileAsyncJobId
"""



CLOSE_UPLOAD_FILE = """
job {
    description
    id
    state
    updatedOn
}
"""

