# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

CONFIG_BY_COLLECTION_ID = """
collectionId
data
"""



CONFIG_BY_PROJECT_ID = """
data
projectId
"""



CREATE_UPDATE_CONFIG_IN_COLLECTION = """
config {
    collectionId
    data
}
"""



CREATE_UPDATE_CONFIG_IN_PROJECT = """
config {
    data
    projectId
}
"""

