# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

from flow_data_sdk.base.client import BaseGQLClient
from flow_data_sdk.base.operation import OperationBase, OperationType
from typing import List, Optional
from .default_selection_g import selection_role_g as selection
from flow_data_sdk.base.model_g import (
    CreatePermissionPolicyInRoleInput, 
	CreatePermissionPolicyInRoleResponse, 
	DeletePermissionPolicyInput, 
	DeletePermissionPolicyResponse, 
	Role, 
	RolesByProjectIdInput, 
	RolesByProjectIdResponse, 
	UpdatePermissionPolicyInput, 
	UpdatePermissionPolicyResponse
)
from flow_data_sdk.base.model_base import NotSetType


class OperationRolesByProjectId(OperationBase[RolesByProjectIdResponse],RolesByProjectIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: RolesByProjectIdInput,
        fields_str: str = selection.ROLES_BY_PROJECT_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="rolesByProjectId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def roles_iterator(self) -> "list[Role]":
        """Get iterator for roles field."""
        return self._iterator_for_field('roles')  # type: ignore[return-value]
        

    def call(self) -> "RolesByProjectIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "RolesByProjectIdResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationCreatePermissionPolicyInRole(OperationBase[CreatePermissionPolicyInRoleResponse],CreatePermissionPolicyInRoleResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CreatePermissionPolicyInRoleInput,
        fields_str: str = selection.CREATE_PERMISSION_POLICY_IN_ROLE,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="createPermissionPolicyInRole",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "CreatePermissionPolicyInRoleResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationUpdatePermissionPolicy(OperationBase[UpdatePermissionPolicyResponse],UpdatePermissionPolicyResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: UpdatePermissionPolicyInput,
        fields_str: str = selection.UPDATE_PERMISSION_POLICY,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="updatePermissionPolicy",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "UpdatePermissionPolicyResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationDeletePermissionPolicy(OperationBase[DeletePermissionPolicyResponse],DeletePermissionPolicyResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: DeletePermissionPolicyInput,
        fields_str: str = selection.DELETE_PERMISSION_POLICY,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="deletePermissionPolicy",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "DeletePermissionPolicyResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class ServiceRole:
    def __init__(self, client: BaseGQLClient):
        self._client = client


    def roles_by_project_id(
        self,
        variables: RolesByProjectIdInput,
        fields_str: str = selection.ROLES_BY_PROJECT_ID,
    ) -> OperationRolesByProjectId:
        """
        Returns a paginated list of roles within a specified project.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested project does not exist;
        """
        return OperationRolesByProjectId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def create_permission_policy_in_role(
        self,
        variables: CreatePermissionPolicyInRoleInput,
        fields_str: str = selection.CREATE_PERMISSION_POLICY_IN_ROLE,
    ) -> OperationCreatePermissionPolicyInRole:
        """
        Add a new permissions policy to an existing role.
        
        #### ────────────────────────────
        
        **Technical details:**
          - The operation guarantees consistent results when run simultaneously by multiple clients. I.e., in an event of concurrent role
            modifications, only one request will succeed and the other ones will fail with a `ConflictError`.
        
        **Error states:**
          - **`NOT_FOUND:`**
            - The requested role does not exist;
            - At least one of the requested locations does not exist;
          - **`CONFLICT:`** The requested role has been updated or deleted by another request before this one was processed;
        
        #### ────────────────────────────
        """
        return OperationCreatePermissionPolicyInRole(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def update_permission_policy(
        self,
        variables: UpdatePermissionPolicyInput,
        fields_str: str = selection.UPDATE_PERMISSION_POLICY,
    ) -> OperationUpdatePermissionPolicy:
        """
        Update an existing permission policy.
        
        #### ────────────────────────────
        
        **Technical details:**
          - The operation guarantees consistent results when run simultaneously by multiple clients. I.e., in an event of concurrent role
            modifications, only one request will succeed and the other ones will fail with a `ConflictError`.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`**
            - The requested role does not exist;
            - The requested policy does not exist;
            - At least one of the requested locations does not exist;
          - **`CONFLICT:`**
            - The requested role has been updated or deleted by another request before this one was processed;
            - The requested policy is currently processing another request;
        """
        return OperationUpdatePermissionPolicy(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def delete_permission_policy(
        self,
        variables: DeletePermissionPolicyInput,
        fields_str: str = selection.DELETE_PERMISSION_POLICY,
    ) -> OperationDeletePermissionPolicy:
        """
        Delete an existing permission policy.
        
        #### ────────────────────────────
        
        **Technical details:**
          - The operation guarantees consistent results when run simultaneously by multiple clients. I.e., in an event of concurrent role
            modifications, only one request will succeed and the other ones will fail with a `ConflictError`.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`**
            - The requested role does not exist;
            - The requested policy does not exist;
          - **`CONFLICT:`**
            - The requested role or policy has been updated or deleted by another request before this one was processed;
            - The requested policy is currently processing another request;
        """
        return OperationDeletePermissionPolicy(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )

