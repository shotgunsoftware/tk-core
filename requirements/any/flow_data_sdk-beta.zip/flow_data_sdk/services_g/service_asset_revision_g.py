# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

from flow_data_sdk.base.client import BaseGQLClient
from flow_data_sdk.base.operation import OperationBase, OperationType
from typing import List, Optional
from .default_selection_g import selection_asset_revision_g as selection
from flow_data_sdk.base.model_g import (
    AssetRevision, 
	AssetRevisionsByAssetIdInput, 
	AssetRevisionsByAssetIdResponse, 
	AssetRevisionsByIdsInput, 
	AssetRevisionsByIdsResponse
)
from flow_data_sdk.base.model_base import NotSetType


class OperationAssetRevisionsByIds(OperationBase[AssetRevisionsByIdsResponse],AssetRevisionsByIdsResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetRevisionsByIdsInput,
        fields_str: str = selection.ASSET_REVISIONS_BY_IDS,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetRevisionsByIds",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "AssetRevisionsByIdsResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationAssetRevisionsByAssetId(OperationBase[AssetRevisionsByAssetIdResponse],AssetRevisionsByAssetIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetRevisionsByAssetIdInput,
        fields_str: str = selection.ASSET_REVISIONS_BY_ASSET_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetRevisionsByAssetId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def asset_revisions_iterator(self) -> "list[AssetRevision]":
        """Get iterator for asset_revisions field."""
        return self._iterator_for_field('asset_revisions')  # type: ignore[return-value]
        

    def call(self) -> "AssetRevisionsByAssetIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "AssetRevisionsByAssetIdResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class ServiceAssetRevision:
    def __init__(self, client: BaseGQLClient):
        self._client = client


    def asset_revisions_by_ids(
        self,
        variables: AssetRevisionsByIdsInput,
        fields_str: str = selection.ASSET_REVISIONS_BY_IDS,
    ) -> OperationAssetRevisionsByIds:
        """
        Retrieves one or more asset revisions by their IDs.
        
        #### ────────────────────────────
        
        **Technical details:**
          - This query does not support a partial success response . Therefore, a user requests three revisions by IDs and one of the revisions
            does not exist, the entire request will fail with a `NOT_FOUND` error;
          - The revisions are returned in the same order as the IDs were provided;
          - Duplicate IDs will be automatically omitted by the server (i.e., the response will not contain the same revision twice);
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** One or multiple requested revisions do not exist;
        """
        return OperationAssetRevisionsByIds(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def asset_revisions_by_asset_id(
        self,
        variables: AssetRevisionsByAssetIdInput,
        fields_str: str = selection.ASSET_REVISIONS_BY_ASSET_ID,
    ) -> OperationAssetRevisionsByAssetId:
        """
        Retrieves a paginated list of asset revisions belonging to the specified asset.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested asset does not exist;
        """
        return OperationAssetRevisionsByAssetId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )

