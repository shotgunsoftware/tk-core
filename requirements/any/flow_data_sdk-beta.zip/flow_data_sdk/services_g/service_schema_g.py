# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

from flow_data_sdk.base.client import BaseGQLClient
from flow_data_sdk.base.operation import OperationBase, OperationType
from typing import List, Optional
from .default_selection_g import selection_schema_g as selection
from flow_data_sdk.base.model_g import (
    CreateSchemaDisplayDataInput, 
	CreateSchemaDisplayDataResponse, 
	CreateSchemaInput, 
	CreateSchemaLibraryInput, 
	CreateSchemaLibraryResponse, 
	CreateSchemaResponse, 
	DeleteSchemaDisplayDataInput, 
	DeleteSchemaDisplayDataResponse, 
	GetSchemaDisplayDataInput, 
	Schema, 
	SchemaDisplayDataResponse, 
	SchemaLibrariesByCollectionIdInput, 
	SchemaLibrariesByCollectionIdResponse, 
	SchemaLibrary, 
	SchemaTypeId, 
	SchemasByLibraryIdInput, 
	SchemasByLibraryIdResponse, 
	SchemasBySuperTypeInput, 
	SchemasBySuperTypeResponse, 
	SchemasByTypeIdInput, 
	SchemasByTypeIdResponse, 
	UpdateSchemaDisplayDataInput, 
	UpdateSchemaDisplayDataResponse
)
from flow_data_sdk.base.model_base import NotSetType


class OperationSchemasByTypeId(OperationBase[SchemasByTypeIdResponse],SchemasByTypeIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: SchemasByTypeIdInput,
        fields_str: str = selection.SCHEMAS_BY_TYPE_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="schemasByTypeId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "SchemasByTypeIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationSchemasByLibraryId(OperationBase[SchemasByLibraryIdResponse],SchemasByLibraryIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: SchemasByLibraryIdInput,
        fields_str: str = selection.SCHEMAS_BY_LIBRARY_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="schemasByLibraryId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def schemas_iterator(self) -> "list[Schema]":
        """Get iterator for schemas field."""
        return self._iterator_for_field('schemas')  # type: ignore[return-value]
        

    def call(self) -> "SchemasByLibraryIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "SchemasByLibraryIdResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationSchemaLibrariesByCollectionId(OperationBase[SchemaLibrariesByCollectionIdResponse],SchemaLibrariesByCollectionIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: SchemaLibrariesByCollectionIdInput,
        fields_str: str = selection.SCHEMA_LIBRARIES_BY_COLLECTION_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="schemaLibrariesByCollectionId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def libraries_iterator(self) -> "list[SchemaLibrary] | None":
        """Get iterator for libraries field."""
        return self._iterator_for_field('libraries')  # type: ignore[return-value]
        

    def call(self) -> "SchemaLibrariesByCollectionIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "SchemaLibrariesByCollectionIdResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationSchemasBySuperType(OperationBase[SchemasBySuperTypeResponse],SchemasBySuperTypeResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: SchemasBySuperTypeInput,
        fields_str: str = selection.SCHEMAS_BY_SUPER_TYPE,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="schemasBySuperType",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def schema_types_iterator(self) -> "list[SchemaTypeId]":
        """Get iterator for schema_types field."""
        return self._iterator_for_field('schema_types')  # type: ignore[return-value]
        

    def call(self) -> "SchemasBySuperTypeResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "SchemasBySuperTypeResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationSchemaDisplayData(OperationBase[SchemaDisplayDataResponse],SchemaDisplayDataResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: GetSchemaDisplayDataInput,
        fields_str: str = selection.SCHEMA_DISPLAY_DATA,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="schemaDisplayData",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "SchemaDisplayDataResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationCreateSchemaLibrary(OperationBase[CreateSchemaLibraryResponse],CreateSchemaLibraryResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CreateSchemaLibraryInput,
        fields_str: str = selection.CREATE_SCHEMA_LIBRARY,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="createSchemaLibrary",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "CreateSchemaLibraryResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationCreateSchema(OperationBase[CreateSchemaResponse],CreateSchemaResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CreateSchemaInput,
        fields_str: str = selection.CREATE_SCHEMA,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="createSchema",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "CreateSchemaResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationCreateSchemaDisplayData(OperationBase[CreateSchemaDisplayDataResponse],CreateSchemaDisplayDataResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CreateSchemaDisplayDataInput,
        fields_str: str = selection.CREATE_SCHEMA_DISPLAY_DATA,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="createSchemaDisplayData",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "CreateSchemaDisplayDataResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationUpdateSchemaDisplayData(OperationBase[UpdateSchemaDisplayDataResponse],UpdateSchemaDisplayDataResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: UpdateSchemaDisplayDataInput,
        fields_str: str = selection.UPDATE_SCHEMA_DISPLAY_DATA,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="updateSchemaDisplayData",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "UpdateSchemaDisplayDataResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationDeleteSchemaDisplayData(OperationBase[DeleteSchemaDisplayDataResponse],DeleteSchemaDisplayDataResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: DeleteSchemaDisplayDataInput,
        fields_str: str = selection.DELETE_SCHEMA_DISPLAY_DATA,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="deleteSchemaDisplayData",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "DeleteSchemaDisplayDataResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class ServiceSchema:
    def __init__(self, client: BaseGQLClient):
        self._client = client


    def schemas_by_type_id(
        self,
        variables: SchemasByTypeIdInput,
        fields_str: str = selection.SCHEMAS_BY_TYPE_ID,
    ) -> OperationSchemasByTypeId:
        """
        Retrieves schema information by their type IDs.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** One or multiple requested schema type IDs do not exist;
        """
        return OperationSchemasByTypeId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def schemas_by_library_id(
        self,
        variables: SchemasByLibraryIdInput,
        fields_str: str = selection.SCHEMAS_BY_LIBRARY_ID,
    ) -> OperationSchemasByLibraryId:
        """
        Retrieves a paginated list of schemas in a given library.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested library or project does not exist;
        """
        return OperationSchemasByLibraryId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def schema_libraries_by_collection_id(
        self,
        variables: SchemaLibrariesByCollectionIdInput,
        fields_str: str = selection.SCHEMA_LIBRARIES_BY_COLLECTION_ID,
    ) -> OperationSchemaLibrariesByCollectionId:
        """
        Retrieves a paginated list of schema libraries available to a user in a specific collection.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested collection does not exist;
        """
        return OperationSchemaLibrariesByCollectionId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def schemas_by_super_type(
        self,
        variables: SchemasBySuperTypeInput,
        fields_str: str = selection.SCHEMAS_BY_SUPER_TYPE,
    ) -> OperationSchemasBySuperType:
        """
        Retrieves a paginated list of schema types that inherit (directly or indirectly) from a given type ID.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested type ID or collection does not exist;
        """
        return OperationSchemasBySuperType(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def schema_display_data(
        self,
        variables: GetSchemaDisplayDataInput,
        fields_str: str = selection.SCHEMA_DISPLAY_DATA,
    ) -> OperationSchemaDisplayData:
        """
        Retrieves the display data for a given schema type ID. Display data is an ar
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested schema type ID does not exist;
        """
        return OperationSchemaDisplayData(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def create_schema_library(
        self,
        variables: CreateSchemaLibraryInput,
        fields_str: str = selection.CREATE_SCHEMA_LIBRARY,
    ) -> OperationCreateSchemaLibrary:
        """
        Create a new schema library. A schema library is basically a container under which schemas can be created.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested project does not exist;
        """
        return OperationCreateSchemaLibrary(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def create_schema(
        self,
        variables: CreateSchemaInput,
        fields_str: str = selection.CREATE_SCHEMA,
    ) -> OperationCreateSchema:
        """
        Create a new schema of any kind in the specified schema library.
        
        #### ────────────────────────────
        
          - **`NOT_FOUND:`** The requested project does not exist;
        """
        return OperationCreateSchema(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def create_schema_display_data(
        self,
        variables: CreateSchemaDisplayDataInput,
        fields_str: str = selection.CREATE_SCHEMA_DISPLAY_DATA,
    ) -> OperationCreateSchemaDisplayData:
        """
        Create a custom display data for a given schema type ID. Display data is used to provide a human-friendly name and description for a schema type
        and its properties.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested schema type does not exist;
        """
        return OperationCreateSchemaDisplayData(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def update_schema_display_data(
        self,
        variables: UpdateSchemaDisplayDataInput,
        fields_str: str = selection.UPDATE_SCHEMA_DISPLAY_DATA,
    ) -> OperationUpdateSchemaDisplayData:
        """
        Update a custom display data for a given schema type ID. Display data is used to provide a human-friendly name and description for a schema type
        and its properties.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested schema type does not exist or does not have the requested display data to update;
        """
        return OperationUpdateSchemaDisplayData(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def delete_schema_display_data(
        self,
        variables: DeleteSchemaDisplayDataInput,
        fields_str: str = selection.DELETE_SCHEMA_DISPLAY_DATA,
    ) -> OperationDeleteSchemaDisplayData:
        """
        Delete all custom display data for a given schema type ID.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested schema type does not exist;
        """
        return OperationDeleteSchemaDisplayData(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )

