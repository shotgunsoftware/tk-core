# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

from flow_data_sdk.base.client import BaseGQLClient
from flow_data_sdk.base.operation import OperationBase, OperationType
from typing import List, Optional
from .default_selection_g import selection_asset_g as selection
from flow_data_sdk.base.model_g import (
    Asset, 
	AssetParentInput, 
	AssetParentResponse, 
	AssetRevision, 
	AssetVersionTraversalEdge, 
	AssetVersionsByAssetIdInput, 
	AssetVersionsByAssetIdResponse, 
	AssetVersionsByIdsInput, 
	AssetVersionsByIdsResponse, 
	AssetVersionsByTraversalInput, 
	AssetVersionsByTraversalResponse, 
	AssetsByIdsInput, 
	AssetsByIdsResponse, 
	AssetsByProjectIdInput, 
	AssetsByProjectIdResponse, 
	AssetsBySearchInput, 
	AssetsBySearchResponse, 
	AssetsByTraversalEdge, 
	AssetsByTraversalInput, 
	AssetsByTraversalResponse, 
	CreateAssetInput, 
	CreateAssetResponse, 
	HardDeleteAssetInput, 
	HardDeleteAssetResponse, 
	NamedAssetVersion, 
	NumberedAssetVersion, 
	RecoverAssetInput, 
	RecoverAssetResponse, 
	SoftDeleteAssetInput, 
	SoftDeleteAssetResponse, 
	UpdateAssetInput, 
	UpdateAssetParentInput, 
	UpdateAssetParentResponse, 
	UpdateAssetResponse
)
from flow_data_sdk.base.model_base import NotSetType


class OperationAssetsByTraversal(OperationBase[AssetsByTraversalResponse],AssetsByTraversalResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetsByTraversalInput,
        fields_str: str = selection.ASSETS_BY_TRAVERSAL,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetsByTraversal",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def assets_iterator(self) -> "list[Asset]":
        """Get iterator for assets field."""
        return self._iterator_for_field('assets')  # type: ignore[return-value]
        

    @property
    def edges_iterator(self) -> "list[AssetsByTraversalEdge]":
        """Get iterator for edges field."""
        return self._iterator_for_field('edges')  # type: ignore[return-value]
        

    def call(self) -> "AssetsByTraversalResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "AssetsByTraversalResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationAssetParent(OperationBase[AssetParentResponse],AssetParentResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetParentInput,
        fields_str: str = selection.ASSET_PARENT,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetParent",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "AssetParentResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationAssetsByIds(OperationBase[AssetsByIdsResponse],AssetsByIdsResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetsByIdsInput,
        fields_str: str = selection.ASSETS_BY_IDS,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetsByIds",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "AssetsByIdsResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationAssetsBySearch(OperationBase[AssetsBySearchResponse],AssetsBySearchResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetsBySearchInput,
        fields_str: str = selection.ASSETS_BY_SEARCH,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetsBySearch",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def results_iterator(self) -> "list[Asset]":
        """Get iterator for results field."""
        return self._iterator_for_field('results')  # type: ignore[return-value]
        

    def call(self) -> "AssetsBySearchResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "AssetsBySearchResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationAssetsByProjectId(OperationBase[AssetsByProjectIdResponse],AssetsByProjectIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetsByProjectIdInput,
        fields_str: str = selection.ASSETS_BY_PROJECT_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetsByProjectId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def assets_iterator(self) -> "list[Asset]":
        """Get iterator for assets field."""
        return self._iterator_for_field('assets')  # type: ignore[return-value]
        

    def call(self) -> "AssetsByProjectIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "AssetsByProjectIdResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationAssetVersionsByIds(OperationBase[AssetVersionsByIdsResponse],AssetVersionsByIdsResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetVersionsByIdsInput,
        fields_str: str = selection.ASSET_VERSIONS_BY_IDS,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetVersionsByIds",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "AssetVersionsByIdsResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationAssetVersionsByAssetId(OperationBase[AssetVersionsByAssetIdResponse],AssetVersionsByAssetIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetVersionsByAssetIdInput,
        fields_str: str = selection.ASSET_VERSIONS_BY_ASSET_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetVersionsByAssetId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def asset_versions_iterator(self) -> "list[NamedAssetVersion | NumberedAssetVersion]":
        """Get iterator for asset_versions field."""
        return self._iterator_for_field('asset_versions')  # type: ignore[return-value]
        

    def call(self) -> "AssetVersionsByAssetIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "AssetVersionsByAssetIdResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationAssetVersionsByTraversal(OperationBase[AssetVersionsByTraversalResponse],AssetVersionsByTraversalResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: AssetVersionsByTraversalInput,
        fields_str: str = selection.ASSET_VERSIONS_BY_TRAVERSAL,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="assetVersionsByTraversal",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    @property
    def edges_iterator(self) -> "list[AssetVersionTraversalEdge]":
        """Get iterator for edges field."""
        return self._iterator_for_field('edges')  # type: ignore[return-value]
        

    @property
    def revisions_iterator(self) -> "list[AssetRevision]":
        """Get iterator for revisions field."""
        return self._iterator_for_field('revisions')  # type: ignore[return-value]
        

    @property
    def versions_iterator(self) -> "list[NamedAssetVersion | NumberedAssetVersion]":
        """Get iterator for versions field."""
        return self._iterator_for_field('versions')  # type: ignore[return-value]
        

    def call(self) -> "AssetVersionsByTraversalResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

    def next(self) -> "AssetVersionsByTraversalResponse":
        """Execute the next page  operation and return the parsed response."""
        return self._next()  # type: ignore[return-value]
        

    def all(self):
        """Get all  across all pages."""
        return self._all()
        

class OperationCreateAsset(OperationBase[CreateAssetResponse],CreateAssetResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CreateAssetInput,
        fields_str: str = selection.CREATE_ASSET,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="createAsset",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "CreateAssetResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationUpdateAsset(OperationBase[UpdateAssetResponse],UpdateAssetResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: UpdateAssetInput,
        fields_str: str = selection.UPDATE_ASSET,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="updateAsset",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "UpdateAssetResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationUpdateAssetParent(OperationBase[UpdateAssetParentResponse],UpdateAssetParentResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: UpdateAssetParentInput,
        fields_str: str = selection.UPDATE_ASSET_PARENT,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="updateAssetParent",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "UpdateAssetParentResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationSoftDeleteAsset(OperationBase[SoftDeleteAssetResponse],SoftDeleteAssetResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: SoftDeleteAssetInput,
        fields_str: str = selection.SOFT_DELETE_ASSET,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="softDeleteAsset",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "SoftDeleteAssetResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationHardDeleteAsset(OperationBase[HardDeleteAssetResponse],HardDeleteAssetResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: HardDeleteAssetInput,
        fields_str: str = selection.HARD_DELETE_ASSET,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="hardDeleteAsset",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "HardDeleteAssetResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationRecoverAsset(OperationBase[RecoverAssetResponse],RecoverAssetResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: RecoverAssetInput,
        fields_str: str = selection.RECOVER_ASSET,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="recoverAsset",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "RecoverAssetResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class ServiceAsset:
    def __init__(self, client: BaseGQLClient):
        self._client = client


    def assets_by_traversal(
        self,
        variables: AssetsByTraversalInput,
        fields_str: str = selection.ASSETS_BY_TRAVERSAL,
    ) -> OperationAssetsByTraversal:
        """
        Traverses the `contains` relationships between assets. Returns the response as a paginated list of edges that are reachable
        from the starting entity.
        
        Additionally, the response includes assets and (optionally) a project that are referenced
        in the `edges` list.
        
        #### ────────────────────────────
        
        **Technical details:**
         - The `edges` list is constructed in a Breadth-First Search (BFS) fashion;
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The `startAtId` entity does not exist;
        """
        return OperationAssetsByTraversal(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def asset_parent(
        self,
        variables: AssetParentInput,
        fields_str: str = selection.ASSET_PARENT,
    ) -> OperationAssetParent:
        """
        Returns the parent of an asset. The parent can be either another asset or a project.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested asset does not exist;
        """
        return OperationAssetParent(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def assets_by_ids(
        self,
        variables: AssetsByIdsInput,
        fields_str: str = selection.ASSETS_BY_IDS,
    ) -> OperationAssetsByIds:
        """
        Retrieves one or more assets by their IDs.
        
        #### ────────────────────────────
        
        **Technical details:**
          - This query does not support a partial success response . Therefore, a user requests three assets by IDs and one of the assets
            does not exist, the entire request will fail with a `NOT_FOUND` error;
          - Duplicate IDs will be automatically omitted by the server (i.e., the response will not contain the same asset twice);
          - The assets are returned in the same order as the IDs were provided;
          - This query will retreive both active and soft-deleted assets.
        
        **Error states:**
          - **`NOT_FOUND:`** One or multiple requested assets do not exist;
        """
        return OperationAssetsByIds(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def assets_by_search(
        self,
        variables: AssetsBySearchInput,
        fields_str: str = selection.ASSETS_BY_SEARCH,
    ) -> OperationAssetsBySearch:
        """
        Retrieves a paginated list of assets that match the search criteria.
        
        #### ────────────────────────────
        
        **Technical details:**
          - Newly created assets must be indexed before they are searchable; API consumers need to wait at least *`30`* *seconds* before
            the assets are returned in the search results.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested project(s) do not exist;
        """
        return OperationAssetsBySearch(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def assets_by_project_id(
        self,
        variables: AssetsByProjectIdInput,
        fields_str: str = selection.ASSETS_BY_PROJECT_ID,
    ) -> OperationAssetsByProjectId:
        """
        Returns a paginated list of assets for a given project. This query lists all assets in the project directly,
        ignoring any `contains` relationships. Therefore, the response of this query does not represent a valid graph structure.
        
        #### ────────────────────────────
        
        **Technical details:**
          - The server will apply the filters to the assets before returning the results. That also means that the response might contain
            fewer assets than the requested page size, the caller is responsible for handling this case and keep exploring the cursor if one is available.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested project does not exist;
        """
        return OperationAssetsByProjectId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def asset_versions_by_ids(
        self,
        variables: AssetVersionsByIdsInput,
        fields_str: str = selection.ASSET_VERSIONS_BY_IDS,
    ) -> OperationAssetVersionsByIds:
        """
        Retrieves one or multiple asset versions by their IDs.
        
        #### ────────────────────────────
        
        **Technical details:**
          - This query does not support a partial success response . Therefore, a user requests three versions by IDs and one of the versions
            does not exist, the entire request will fail with a `NOT_FOUND` error;
          - The versions are returned in the same order as the IDs were provided;
          - Duplicate IDs will be automatically omitted by the server (i.e., the response will not contain the same version twice);
        
        **Error states:**
          - **`NOT_FOUND:`** One or multiple requested versions do not exist;
        """
        return OperationAssetVersionsByIds(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def asset_versions_by_asset_id(
        self,
        variables: AssetVersionsByAssetIdInput,
        fields_str: str = selection.ASSET_VERSIONS_BY_ASSET_ID,
    ) -> OperationAssetVersionsByAssetId:
        """
        Retrieves a paginated list of versions belonging to the specified asset.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested asset does not exist;
        """
        return OperationAssetVersionsByAssetId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def asset_versions_by_traversal(
        self,
        variables: AssetVersionsByTraversalInput,
        fields_str: str = selection.ASSET_VERSIONS_BY_TRAVERSAL,
    ) -> OperationAssetVersionsByTraversal:
        """
        Traverses the `uses` relationships betweeen assets and their versions. Returns the resposnes as a paginated list of edges that
        are reachable from the starting version.
        
        Additionally, the response includes versions and revisions that are referenced in the `edges` list.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The version to start the traversal from does not exist;
        #### ────────────────────────────
        """
        return OperationAssetVersionsByTraversal(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def create_asset(
        self,
        variables: CreateAssetInput,
        fields_str: str = selection.CREATE_ASSET,
    ) -> OperationCreateAsset:
        """
        Create a new asset under specified parent (project or another asset). Once created, the asset will _always_ have:
          - An asset revision;
          - A numbered version linked to the revision;
          - A special named version linked to the numbered version (i.e., 'latest');
          - A `contains` relationship that connects the asset to its parent.
        
        #### ────────────────────────────
        
        **Technical details:**
          - If the supplied `components` payload has at least one binary component, this operation will trigger the binary upload process. The respective
            upload async job can be retrieved via the `asyncJobsByAssetRevisionIds` query.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`**
            - The requested `parentId` does not exist;
            - One or multiple `versionIds` from the `uses` field do not exist;
        """
        return OperationCreateAsset(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def update_asset(
        self,
        variables: UpdateAssetInput,
        fields_str: str = selection.UPDATE_ASSET,
    ) -> OperationUpdateAsset:
        """
        Update an existing asset by its ID to modify its properties (name, description, components, etc.). Asset update operations always
        performs an asset update by creating a new asset revision and, optionally, a new numbered version. For more information about the
        update process and its possible results, refer to the `UpdateAssetInput` documentation.
        
        #### ────────────────────────────
        
        **Technical details:**
          - The operation guarantees consistent results when run simultaneously by multiple clients. I.e., in an event of concurrent asset
            modifications (update, reparenting, or soft-deletion), only one request will succeed and the other ones will fail with a `ConflictError`;
          - If the supplied `components` payload has at least one binary component, this operation will trigger the binary upload process. The respective
            upload async job can be retrieved via the `asyncJobsByAssetRevisionIds` query.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested asset does not exist;
          - **`CONFLICT:`** The requested asset has been updated or soft-deleted by another request before this one was processed;
        """
        return OperationUpdateAsset(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def update_asset_parent(
        self,
        variables: UpdateAssetParentInput,
        fields_str: str = selection.UPDATE_ASSET_PARENT,
    ) -> OperationUpdateAssetParent:
        """
        Modifies the existing asset graph composition by moving the specified asset under another asset or the current project.
        
        #### ────────────────────────────
        
        **Technical details:**
          - The operation guarantees consistent results when run simultaneously by multiple clients. I.e., in an event of concurrent asset
            modifications (update, reparenting, or soft-deletion), only one request will succeed and the other ones will fail with a `ConflictError`;
          - Reparenting does not affect the asset itself (No new asset revision is created), only its parent `contains` relationship;
          - Reparenting asset to already existing parent is no-op (But this can still be detected by the `updateCondition` field);
        
        **Notes:**
          - Explore the documentation for the `Asset` type to learn more about the asset graph composition and how it works.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`**
            - The asset being moved does not exist;
            - The new parent does not exist;
          - **`CONFLICT:`** The requested asset has been modified by another request before this one was processed;
        """
        return OperationUpdateAssetParent(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def soft_delete_asset(
        self,
        variables: SoftDeleteAssetInput,
        fields_str: str = selection.SOFT_DELETE_ASSET,
    ) -> OperationSoftDeleteAsset:
        """
        Marks an existing asset as soft-deleted. This essentialy sets the asset's `deletionState` attribute to `SoftDeleted`.
        That said, all the binaries, components, relationships, and other asset metadata remain intact.
        
        #### ────────────────────────────
        
        **Technical details:**
          - The operation guarantees consistent results when run simultaneously by multiple clients. I.e., in an event of concurrent asset
            modifications (update, reparenting, or soft-deletion), only one request will succeed and the other ones will fail with a `ConflictError`;
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested asset does not exist;
          - **`CONFLICT:`** The requested asset has been updated or soft-deleted by another request before this one was processed;
        """
        return OperationSoftDeleteAsset(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def hard_delete_asset(
        self,
        variables: HardDeleteAssetInput,
        fields_str: str = selection.HARD_DELETE_ASSET,
    ) -> OperationHardDeleteAsset:
        """
        Triggers the hard deletion process for specified asset. This operation is a multi-step process which permanently removes the asset from the system,
        including all its data:
          - Binaries (if any);
          - Components;
          - Relationships;
          - Versions and revisions;
          - Permissions;
          - Asset metadata.
        
        
        
        #### ────────────────────────────
        
        **Technical details:**
          - The operation guarantees consistent results when run simultaneously by multiple clients. I.e., in an event of concurrent asset
            modifications (update, reparenting, or hard-deletion, etc.), only one request will succeed and the other ones will fail with a `ConflictError`;
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested asset does not exist;
          - **`OPERATION_NOT_ALLOWED:`** The requested asset is soft-deleted;
          - **`OPERATION_NOT_ALLOWED:`** The requested asset deletion was already initiated;
        """
        return OperationHardDeleteAsset(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def recover_asset(
        self,
        variables: RecoverAssetInput,
        fields_str: str = selection.RECOVER_ASSET,
    ) -> OperationRecoverAsset:
        """
        Recovers a soft-deleted asset. This operation restores the asset to its original state before it was soft-deleted.
        
        #### ────────────────────────────
        
        **Technical details:**
          - The operation guarantees consistent results when run simultaneously by multiple clients. I.e., in an event of concurrent asset
            modifications (update, reparenting, or hard-deletion, etc.), only one request will succeed and the other ones will fail with a `ConflictError`;
        
        #### ────────────────────────────
        
        **Error states:**
          - **`OPERATION_NOT_ALLOWED:`**
            - The requested asset has a soft-deleted parent. Cascade recovery is not supported. Therefore, if the asset to recover has a soft-deleted parent,
              the recovery will fail with the error.
            - The requested asset is not soft-deleted. Only soft-deleted assets can be recovered.
          - **`NOT_FOUND:`** The requested asset does not exist;
          - **`CONFLICT:`** The requested asset has been updated or hard-deleted by another request before this one was processed;
        """
        return OperationRecoverAsset(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )

