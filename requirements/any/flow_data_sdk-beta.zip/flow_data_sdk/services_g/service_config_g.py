# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

from flow_data_sdk.base.client import BaseGQLClient
from flow_data_sdk.base.operation import OperationBase, OperationType
from typing import List, Optional
from .default_selection_g import selection_config_g as selection
from flow_data_sdk.base.model_g import (
    ConfigByCollectionIdInput, 
	ConfigByCollectionIdResponse, 
	ConfigByProjectIdInput, 
	ConfigByProjectIdResponse, 
	CreateUpdateConfigInCollectionInput, 
	CreateUpdateConfigInCollectionResponse, 
	CreateUpdateConfigInProjectInput, 
	CreateUpdateConfigInProjectResponse
)
from flow_data_sdk.base.model_base import NotSetType


class OperationConfigByCollectionId(OperationBase[ConfigByCollectionIdResponse],ConfigByCollectionIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: ConfigByCollectionIdInput,
        fields_str: str = selection.CONFIG_BY_COLLECTION_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="configByCollectionId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "ConfigByCollectionIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationConfigByProjectId(OperationBase[ConfigByProjectIdResponse],ConfigByProjectIdResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: ConfigByProjectIdInput,
        fields_str: str = selection.CONFIG_BY_PROJECT_ID,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.QUERY,
            operation_name="configByProjectId",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "ConfigByProjectIdResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationCreateUpdateConfigInCollection(OperationBase[CreateUpdateConfigInCollectionResponse],CreateUpdateConfigInCollectionResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CreateUpdateConfigInCollectionInput,
        fields_str: str = selection.CREATE_UPDATE_CONFIG_IN_COLLECTION,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="createUpdateConfigInCollection",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "CreateUpdateConfigInCollectionResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class OperationCreateUpdateConfigInProject(OperationBase[CreateUpdateConfigInProjectResponse],CreateUpdateConfigInProjectResponse):
    def __init__(
        self,
        client: BaseGQLClient,
        variables: CreateUpdateConfigInProjectInput,
        fields_str: str = selection.CREATE_UPDATE_CONFIG_IN_PROJECT,
    ):
        super().__init__(
            client=client,
            operation_type= OperationType.MUTATION,
            operation_name="createUpdateConfigInProject",
            variables_prefix="input",
            variables=variables,
            fields_str=fields_str,
        )
        

    def call(self) -> "CreateUpdateConfigInProjectResponse":
        """Execute the operation and return the parsed response."""
        return self._call()  # type: ignore[return-value]
        

class ServiceConfig:
    def __init__(self, client: BaseGQLClient):
        self._client = client


    def config_by_collection_id(
        self,
        variables: ConfigByCollectionIdInput,
        fields_str: str = selection.CONFIG_BY_COLLECTION_ID,
    ) -> OperationConfigByCollectionId:
        """
        Retreives a collection configuration. Collection configuration is a set of key-value pairs that are stored on the collection level,
        and are accessible to all projects in the collection.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested collection does not exist;
        """
        return OperationConfigByCollectionId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def config_by_project_id(
        self,
        variables: ConfigByProjectIdInput,
        fields_str: str = selection.CONFIG_BY_PROJECT_ID,
    ) -> OperationConfigByProjectId:
        """
        Retreives a project configuration. Project configuration is a set of key-value pairs that are stored on the project level.
        The project configuration may be merged with the collection configuration to retrieve a combined configuration.
        
        **Technical details:**
          - While merging the project configuration with the collection configuration, the project properties will take precedence over
           the collection properties. This allows to override the default values set on the collection level.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested project does not exist;
        """
        return OperationConfigByProjectId(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def create_update_config_in_collection(
        self,
        variables: CreateUpdateConfigInCollectionInput,
        fields_str: str = selection.CREATE_UPDATE_CONFIG_IN_COLLECTION,
    ) -> OperationCreateUpdateConfigInCollection:
        """
        Creates a new config associated with a specified collection. If the config already exists, it will be updated.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested collection does not exist;
        """
        return OperationCreateUpdateConfigInCollection(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )


    def create_update_config_in_project(
        self,
        variables: CreateUpdateConfigInProjectInput,
        fields_str: str = selection.CREATE_UPDATE_CONFIG_IN_PROJECT,
    ) -> OperationCreateUpdateConfigInProject:
        """
        Creates a new config associated with a specified project. If the config already exists, it will be updated.
        
        #### ────────────────────────────
        
        **Error states:**
          - **`NOT_FOUND:`** The requested project does not exist;
        """
        return OperationCreateUpdateConfigInProject(
            client=self._client,
            variables=variables,
            fields_str=fields_str,
        )

