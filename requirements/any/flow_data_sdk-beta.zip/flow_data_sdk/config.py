"""
Configuration constants for Flow Data SDK.

These are default values that can be overridden via environment variables.
"""

# Default authentication base URL
DEFAULT_AUTH_BASE_URL = "https://developer.api.autodesk.com/"

# Default GraphQL endpoint URL
DEFAULT_ENDPOINT = "https://api.aps.usa.autodesk.com/medm/v2/graphql"
