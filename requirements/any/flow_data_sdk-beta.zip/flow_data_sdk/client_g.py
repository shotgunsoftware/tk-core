# This file is auto-generated. Do not edit manually.
# Generated on: 2026-03-19 14:11:46

"""
Main Flow Data SDK client

This is the primary interface for interacting with the GraphQL API.
It provides access to all services (collections, projects, assets, asset versions) and
handles authentication and configuration.
"""

# The main purpose of this module is to group the various services
# together. For all connection code please see base/client.py.
from typing import Dict, Optional

from .base.client import AuthenticationHandlerBase, BaseGQLClient
from .services_g import *

class GQLClient(BaseGQLClient):
    """
    Main GraphQL SDK client
    """

    def __init__(
        self,
        endpoint: str,
        auth_handler: AuthenticationHandlerBase,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 30,
        max_pages: Optional[int] = None,
        **kwargs,
    ):
        """
        Initialize the Flow Data SDK client

        Args:
            endpoint: GraphQL endpoint URL
            auth_handler: Supplies token via get_authentication_token()
            headers: Additional headers to include in requests (optional)
            timeout: Request timeout in seconds (default: 30)
            max_pages: Max pages to fetch in one go for .all(); None uses operation default
            **kwargs: Additional configuration options
        """

        # Initialize the base GraphQL client

        super().__init__(
            endpoint=endpoint,
            auth_handler=auth_handler,
            headers=headers,
            timeout=timeout,
            max_pages=max_pages,
        )
        self.service_project:ServiceProject = ServiceProject(self)
        self.service_role:ServiceRole = ServiceRole(self)
        self.service_asset:ServiceAsset = ServiceAsset(self)
        self.service_asset_revision:ServiceAssetRevision = ServiceAssetRevision(self)
        self.service_collection:ServiceCollection = ServiceCollection(self)
        self.service_schema:ServiceSchema = ServiceSchema(self)
        self.service_binary:ServiceBinary = ServiceBinary(self)
        self.service_job:ServiceJob = ServiceJob(self)
        self.service_config:ServiceConfig = ServiceConfig(self)

