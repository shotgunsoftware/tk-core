"""
Copyright (c) 2012 Shotgun Software, Inc
----------------------------------------------------

"""

from . import tk_multi_about