### Toolkit zero configuration setup

For documentation, please see the [github wiki](https://github.com/shotgunsoftware/tk-config-basic/wiki/Documentation).


