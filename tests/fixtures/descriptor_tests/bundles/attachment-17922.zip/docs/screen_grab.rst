Screen Capture Widget
#############################################

The screen capture widgets makes it easy to take screenshots.
Similar to pressing CMD+SHIFT+4/CMD+SHIFT+3 on the mac, this widget implements
several different ways in which the screen can be captured, either via
a cross hair style selection or by grabbing the entire screen.

.. currentmodule:: screen_grab

.. autofunction:: get_desktop_pixmap
.. autofunction:: screen_capture
.. autofunction:: screen_capture_file
