Spinner Widget
######################################


A simple animated progress spinner that can be used to indicate
that something is loading.

.. currentmodule:: spinner_widget

.. autoclass:: SpinnerWidget
    :show-inheritance:
    :inherited-members:
    :members:
    :exclude-members: closeEvent, hideEvent, paintEvent, showEvent
